from pathlib import Path
f = Path("cluster/test_power.py")
s = f.read_text()
o = """def test_part1_current():"""
n = '''def test_windows_file_time_based():
    # time-based: each window's VCD cut and its bounds in ns (the cuts' 10ps unit, X76), exact
    assert power.cut_ns(796750) == "7967.50" and power.cut_ns(1054705) == "10547.05" and power.cut_ns(99) == "0.99"
    w = power.windows(LOG, MARKS)
    vcds = {power.window_name(x): Path(f"/k/{power.window_name(x)}.vcd") for x in w}
    lines = power.windows_file(w, vcds, times=True).splitlines()
    assert len(lines) == len(w) and all(len(ln.split()) == 4 for ln in lines), lines
    name, f, t0, t1 = lines[0].split()
    assert (name, f) == ("1_dma_in", "/k/1_dma_in.vcd")
    assert float(t0) == w[0]["cut_t0"] / 100 and float(t1) == w[0]["cut_t1"] / 100, (lines[0], w[0])
    ts = power.time_site()
    assert (ts.pwr_dir, ts.pt_dir, ts.analysis, ts.power_csv) == ("pwr_time", "pt_time", "time_based", None)
    assert ts.power_reports == power.POWER_REPORTS_TIME != power.POWER_REPORTS
    fs = power.forge_site()
    assert (fs.pwr_dir, fs.pt_dir, fs.analysis) == ("pwr", "pt", "averaged") and fs.power_csv == power.POWER_CSV


def test_part1_current():'''
assert s.count(o) == 1
s = s.replace(o, n, 1)
o = """def test_quiet_do_file_and_own_ref():"""
n = '''def test_pack_time_based_beside_averaged():
    # --time-based packs pwr_time/ and pt_time/ and its own report zip; pwr/, pt/ and power_reports/ stay as they are
    (power.ROOT / "tmp").mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=power.ROOT / "tmp") as d:
        d = Path(d)
        old = cl_mod.RUN_ZIPS, power.POWER_REPORTS, power.POWER_REPORTS_TIME
        cl_mod.RUN_ZIPS, power.POWER_REPORTS, power.POWER_REPORTS_TIME = d / "runs", d / "avg", d / "time"
        try:
            run_zip = cl_mod.RUN_ZIPS / "p.zip"
            before = {"pwr/windows.json": b"[1]\\n", "pwr/5_run/w.saif": b"avg", "pt/pt_check.json": b"{}\\n",
                      "rtl/check.json": b"{}\\n"}
            power.arc.write(run_zip, before)
            work = d / "work"
            (work / "pwr_time" / "5_run").mkdir(parents=True)
            (work / "pwr_time" / "5_run" / "w.saif").write_text("time")
            (work / "pwr_time" / "windows.json").write_text("[2]\\n")
            power.pack(work, "p", {"status": "PASS"}, "pwr_time")
            pt = d / "pt"
            (pt / "reports" / "5_run").mkdir(parents=True)
            for f in power.REPORT_FILES:
                (pt / "reports" / "5_run" / f).write_text(f)
            power.pack2(pt, "p", {"status": "PASS"}, [{"mark": 5, "kind": "run"}], run_zip, power.time_site())
            got = power.arc.read_all(run_zip)
            assert {k: got[k] for k in before} == before, got
            assert got["pwr_time/5_run/w.saif"] == b"time" and "pwr_time/check.json" in got
            assert "pt_time/pt_check.json" in got
            assert power.arc.read((d / "time" / "p.zip"), "windows.json") == b"[2]\\n"
            assert not (d / "avg").exists()
        finally:
            cl_mod.RUN_ZIPS, power.POWER_REPORTS, power.POWER_REPORTS_TIME = old


def test_quiet_do_file_and_own_ref():'''
assert s.count(o) == 1
s = s.replace(o, n, 1)
f.write_text(s)
