from pathlib import Path
f = Path("sim/scripts/pt_power.tcl")
s = f.read_text()
reps = [
("""#   PWR_WINDOWS  cluster: a file, one `<name> <saif path>` per line
""", """#   PWR_WINDOWS  cluster: a file, one `<name> <saif path>` per line; in time_based analysis
#                `<name> <vcd path> <t0_ns> <t1_ns>`: read_vcd -strip_path PWR_STRIP -time {t0 t1} in place
#                of read_saif (cluster/power.py --time-based, one VCD cut per window)
#   PWR_ANALYSIS power_analysis_mode: averaged (default) or time_based (cluster mode only)
"""),
("""set power_enable_analysis true
set power_analysis_mode averaged
""", """set analysis   [expr {[info exists ::env(PWR_ANALYSIS)] ? $::env(PWR_ANALYSIS) : "averaged"}]
if {$analysis ni {averaged time_based} || ($analysis eq "time_based" && $mode ne "cluster")} {
    puts "pt_power.tcl: PWR_ANALYSIS must be averaged, or time_based in cluster mode, not '$analysis' (mode $mode)"
    exit 2
}
set power_enable_analysis true
set power_analysis_mode $analysis
"""),
("""        lassign $wline name saif
        set wout [file join $out $name]
        file mkdir $wout
        set t0 [clock milliseconds]
        reset_switching_activity
        read_saif -strip_path $::env(PWR_STRIP) $saif
""", """        lassign $wline name act w0 w1
        set wout [file join $out $name]
        file mkdir $wout
        set t0 [clock milliseconds]
        reset_switching_activity
        if {$analysis eq "time_based"} {
            read_vcd -strip_path $::env(PWR_STRIP) -time [list $w0 $w1] $act
        } else {
            read_saif -strip_path $::env(PWR_STRIP) $act
        }
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:200]
    s = s.replace(o, n)
f.write_text(s)
