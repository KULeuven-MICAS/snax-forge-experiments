"""Step 5: bank_counts.json per window kind, and the SAIF's bank accesses against SNAX-GVSoC's bank counters.

    pixi run python bank_cmp.py SFE_ROOT

Per point and window kind: reads, writes, counted nJ, PT nJ, PT over counted. Then per point the SAIF's reads +
writes over the program window (every window of bank_counts.json) against ge/<point>.json's banks' reads + writes over
the windows of the same marks; every window beyond 1 % listed.
"""

import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "report"))
import model_fit as mf  # noqa: E402  ge_path: ge/csyn2/, ge/ge1/, ge/
res = root / "results" / "cluster" / "nangate45"
bc = json.loads((res / "bank_counts.json").read_text())

print("### Per window kind\n")
print("| point | kind | windows | reads | writes | counted nJ | PT nJ | PT / counted |")
print("|---|---|---:|---:|---:|---:|---:|---:|")
for pt, v in bc["points"].items():
    kinds: dict[str, dict] = {}
    for name, w in v["windows"].items():
        k = name.split("_", 1)[1]
        t = kinds.setdefault(k, {"n": 0, "reads": 0, "writes": 0, "counted_nj": 0.0, "pt_nj": 0.0})
        t["n"] += 1
        for f in ("reads", "writes", "counted_nj", "pt_nj"):
            t[f] += w[f]
    for k, t in kinds.items():
        r = t["pt_nj"] / t["counted_nj"] if t["counted_nj"] else float("nan")
        print(f"| `{pt}` | {k} | {t['n']} | {t['reads']} | {t['writes']} | {t['counted_nj']:.3f} | {t['pt_nj']:.3f} | "
              f"{r:.3f} |")

print("\n### Against SNAX-GVSoC's bank counters (reads + writes)\n")
print("| point | SAIF reads + writes | SNAX-GVSoC reads + writes | diff | % | windows beyond 1 % |")
print("|---|---:|---:|---:|---:|---|")
beyond_all = []
src = {}
for pt, v in bc["points"].items():
    gf = res / "ge" / f"{pt}.json"
    gf = gf if gf.is_file() else mf.ge_path("nangate45", pt)   # dot3: GE1's run, the program its SAIFs are of
    ge = json.loads(gf.read_text())
    src[pt] = str(gf.relative_to(res / "ge"))
    gw = {w["mark"]: w for w in ge["windows"]}
    s_tot = g_tot = 0
    beyond = []
    for name, w in v["windows"].items():
        mark = int(name.split("_", 1)[0])
        s = w["reads"] + w["writes"]
        g = sum(b["reads"] + b["writes"] for b in gw[mark]["counters"]["banks"]) if mark in gw else None
        if g is None:
            beyond.append(f"{name}: no SNAX-GVSoC window")
            continue
        s_tot += s
        g_tot += g
        if abs(s - g) > 0.01 * max(g, 1):
            beyond.append(f"{name} {s} / {g} ({100 * (s - g) / g if g else float('inf'):+.1f} %)")
    pct = 100 * (s_tot - g_tot) / g_tot if g_tot else float("nan")
    print(f"| `{pt}` | {s_tot} | {g_tot} | {s_tot - g_tot:+d} | {pct:+.2f} | {'; '.join(beyond) or 'none'} |")
    beyond_all += [(pt, b) for b in beyond]
print(f"\n{len(beyond_all)} windows beyond 1 %; SNAX-GVSoC runs read: "
      + ", ".join(f"{p} {s}" for p, s in src.items() if "/" in s))
