from pathlib import Path
f = Path("cluster/test_cluster.py")
s = f.read_text()
old1 = """            sha = cl.hashlib.sha256(b"quiet").hexdigest()
"""
new1 = """            (cl.FORGE / "recipes" / "polybench").mkdir(parents=True)
            (cl.FORGE / "recipes" / "polybench" / "mvt_v5.json").write_text("{}")
            sha = cl.hashlib.sha256(b"quiet").hexdigest()
"""
old2 = """            shutil_rm = cl.shutil.rmtree
            shutil_rm(cl.FORGE)
"""
new2 = """            shutil_rm = cl.shutil.rmtree
            shutil_rm(cl.FORGE / "out")
"""
old3 = """            shutil_rm(cl.FORGE)
            (cl.GE_DIR"""
new3 = """            shutil_rm(cl.FORGE / "out")
            (cl.GE_DIR"""
for o, n in ((old1, new1), (old2, new2), (old3, new3)):
    assert s.count(o) == 1, o
    s = s.replace(o, n)
f.write_text(s)
