from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
reps = [
# saif_jobs: keep the cuts
("""def saif_jobs(vcd: Path, wins: list[dict], pdir: Path, res: dict, instance: str = TB_TOP) -> None:
    \"\"\"Steps 6 and 7: one cut pass, vcd2saif per window (at most j jobs, no more cuts on disk than jobs), the checks;
    instance is the wrapper's in the testbench (vcd2saif -instance).\"\"\"
""", """def saif_jobs(vcd: Path, wins: list[dict], pdir: Path, res: dict, instance: str = TB_TOP,
              keep: Path | None = None) -> None:
    \"\"\"Steps 6 and 7: one cut pass, vcd2saif per window (at most j jobs, no more cuts on disk than jobs), the checks;
    instance is the wrapper's in the testbench (vcd2saif -instance). With keep (--time-based), each cut is moved to
    keep/<window>.vcd after its vcd2saif instead of deleted, for PT's time-based session.\"\"\"
"""),
("""        finally:
            cuts[n].unlink(missing_ok=True)        # each cut at once
""", """        finally:
            if keep is not None and cuts[n].is_file():
                cuts[n].replace(keep / f"{n}.vcd")
            cuts[n].unlink(missing_ok=True)        # each cut at once
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o
    s = s.replace(o, n)
f.write_text(s)
