from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
reps = [
("""def hier_top(text: str) -> tuple[float, float, float, float]:
    \"\"\"report_power -hierarchy's first row, the top: (internal, switching, leakage, total).\"\"\"
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if ln.startswith("-----"):
            m = re.match(rf"^(\\S+)\\s+({NUM})\\s+({NUM})\\s+({NUM})\\s+({NUM})", lines[i + 1])
            if m:
                return tuple(float(x) for x in m.groups()[1:])
            break
    raise pwr.Fail("power_hierarchy.rpt: no top row")
""", """def hier_top(text: str) -> tuple[float, float, float, float]:
    \"\"\"report_power -hierarchy's first row, the top: (internal, switching, leakage, total). A time-based report has
    no total column (peak power and time follow the leakage): its total is the sum of the three.\"\"\"
    timed = "Report : Time Based Power" in text
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if ln.startswith("-----"):
            m = re.match(rf"^(\\S+)\\s+({NUM})\\s+({NUM})\\s+({NUM})\\s+({NUM})", lines[i + 1])
            if m:
                v = tuple(float(x) for x in m.groups()[1:])
                return (*v[:3], sum(v[:3])) if timed else v
            break
    raise pwr.Fail("power_hierarchy.rpt: no top row")
"""),
("""def summary2(point: str, res: dict) -> str:""", """def recheck_time(p: dict, pre: dict) -> int:
    \"\"\"--time-based --recheck: part 2's checks again from what the time-based run packed (the report zip, pt_time/'s
    not-annotated lists, pwr_time/'s SAIFs), with no Questa and no PT; both pt_check.json are rewritten.\"\"\"
    point, site = p["point"], time_site()
    run_zip, rep_zip = site.run_zips / f"{point}.zip", site.power_reports / f"{point}.zip"
    old = json.loads(arc.read(run_zip, f"{site.pt_dir}/pt_check.json"))
    p1 = json.loads(arc.read(run_zip, f"{site.pwr_dir}/check.json"))
    if old.get("netlist", {}).get("sha256") != pre["netlist_sha"] or p1.get("quiet_elf_sha256") != pre["quiet_sha"]:
        raise SystemExit(f"{run_zip.name}: the time-based run is not of this netlist and quiet ELF")
    work = site.tmp / point
    shutil.rmtree(work, ignore_errors=True)
    rep = work / "reports"
    try:
        for name, data in arc.read_all(rep_zip).items():
            (rep / name).parent.mkdir(parents=True, exist_ok=True)
            (rep / name).write_bytes(data)
        wl = wire_load(cl._text(rep / "wire_load.rpt"))
        tx = {n: i.get("tx_nets") for n, i in (p1.get("saif") or {}).items()}
        for w in p1["windows"]:
            n = window_name(w)
            wdir = rep / n
            (wdir / "not_annotated.rpt").write_bytes(arc.read(run_zip, f"{site.pt_dir}/{n}/not_annotated.rpt"))
            saif = work / f"{n}.saif"
            saif.write_bytes(arc.read(run_zip, f"{site.pwr_dir}/{n}/w.saif"))
            try:
                c, e = check_window(wdir, saif, w, wl)
                want = ((p1.get("saif") or {}).get(n) or {}).get("entries")
                c["saif_entries"] = {"parsed": c["annotation"]["saif_entries"], "part1": want,
                                     "status": "PASS" if want == c["annotation"]["saif_entries"] else "FAIL"}
                bad = [k for k, v in c.items() if v["status"] != "PASS"]
            except pwr.Fail as ex:
                c, e, bad = {"parse": {"status": "FAIL", "why": str(ex)}}, {}, ["parse"]
            saif.unlink()
            prev = old["windows"].get(n, {})
            old["windows"][n] = {**prev, "status": "PASS" if not bad else "FAIL", "checks": c, "energy": e,
                                 "cycles": w["cycles"], "tx_nets": tx.get(n)}
            print(f"  {n:<20s} {'ok' if not bad else 'failed: ' + ', '.join(bad)}: e_dyn {e.get('e_dyn_pj', 0):.1f} "
                  f"pJ/cycle, e_win {e.get('e_win_pj', 0) / 1000:.2f} nJ", flush=True)
        bad = [n for n, v in old["windows"].items() if v["status"] != "PASS"]
        was = old.get("status")
        old["status"], old["failed"] = ("PASS" if not bad else "FAIL"), (", ".join(bad) or None)
        old.setdefault("rechecked", []).append({"date": dt.datetime.now().isoformat(timespec="seconds"), "was": was,
                                                "why": "the checks again from the packed reports (no PT)"})
        members = arc.read_all(rep_zip)
        members["pt_check.json"] = (json.dumps({k: v for k, v in old.items() if k != "report_zip"}, indent=2,
                                               default=str) + "\\n").encode()
        arc.write(rep_zip, members)
        old["report_zip"] = {"zip": str(rep_zip.relative_to(ROOT)), "bytes": rep_zip.stat().st_size,
                             "members": len(members)}
        rz = arc.read_all(run_zip)
        rz[f"{site.pt_dir}/pt_check.json"] = (json.dumps(old, indent=2, default=str) + "\\n").encode()
        arc.write(run_zip, rz)
    finally:
        shutil.rmtree(work, ignore_errors=True)
        if site.tmp.is_dir() and not any(site.tmp.iterdir()):
            site.tmp.rmdir()
    print(summary2(point, old) + f" (rechecked; was {was})", flush=True)
    return 0 if old["status"] == "PASS" else 1


def summary2(point: str, res: dict) -> str:"""),
("""    if getattr(args, "time_based", False):
        return main_time(p, images, args, pre)
""", """    if getattr(args, "time_based", False):
        if getattr(args, "recheck", False):
            return recheck_time(p, pre)
        return main_time(p, images, args, pre)
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:120]
    s = s.replace(o, n)
f.write_text(s)
f = Path("cluster/cluster.py")
s = f.read_text()
o = """                        "cuts into pt_time/ and power_reports_time/; the averaged results are left as they are")
"""
n = o + """    w.add_argument("--recheck", action="store_true",
                   help="with --time-based: part 2's checks again from what it packed, with no Questa and no PT")
"""
assert s.count(o) == 1
f.write_text(s.replace(o, n))
