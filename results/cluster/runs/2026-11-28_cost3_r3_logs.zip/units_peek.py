import sys
sys.path.insert(0, "arc")
import arc
for z in ("power_reports", "power_reports_time"):
    print(z, arc.read_text(f"results/cluster/nangate45/{z}/mvt_column_cg.zip", "6_run/units.rpt").strip().splitlines()[-3:])
