import json, sys
sys.path.insert(0, "arc")
import arc
z = "results/cluster/nangate45/power_reports_time/mvt_column_cg.zip"
p = arc.read_text(z, "6_run/power.rpt")
h = arc.read_text(z, "6_run/power_hierarchy.rpt")
print(p[:3000]); print("=====HIER"); print("\n".join(h.splitlines()[:16]))
c = json.loads(arc.read(z, "pt_check.json"))
print("=====", json.dumps(c["windows"]["6_run"]["checks"]["hierarchy_total"]))
