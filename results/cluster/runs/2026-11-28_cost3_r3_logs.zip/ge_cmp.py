"""Step 4: each new ge/<point>.json against ge/csyn2/<point>.json.

    pixi run python ge_cmp.py SFE_ROOT

Stops (exit 1) when a window's mark, kind, cycles or counters differ, or the new prices lack r_strm, floor or e_l2.
Prints per point the program window's six parts (the windows between boot and check) before and after, in nJ.
"""

import json
import sys
from pathlib import Path

PARTS = ("datapath", "control", "streamers", "crossbar", "memory", "dma")
ge = Path(sys.argv[1]) / "results" / "cluster" / "nangate45" / "ge"
stop = []
rows = []
names = sorted(p.stem for p in (ge / "csyn2").glob("*.json"))
for n in names:
    old = json.loads((ge / "csyn2" / f"{n}.json").read_text())
    new_f = ge / f"{n}.json"
    if not new_f.is_file():
        stop.append(f"{n}: no new ge/{n}.json")
        continue
    new = json.loads(new_f.read_text())
    ow, nw = old["windows"], new["windows"]
    if [(w["mark"], w["kind"], w["cycles"]) for w in ow] != [(w["mark"], w["kind"], w["cycles"]) for w in nw]:
        stop.append(f"{n}: windows differ: {[(w['mark'], w['cycles']) for w in ow]} / "
                    f"{[(w['mark'], w['cycles']) for w in nw]}")
    for a, b in zip(ow, nw):
        if a["counters"] != b["counters"]:
            ks = sorted(k for k in set(a["counters"]) | set(b["counters"]) if a["counters"].get(k) != b["counters"].get(k))
            stop.append(f"{n}: window {a['mark']} {a['kind']}: counters differ in {ks}")
    pr = new["prices"]
    miss = [k for k in ("r_strm", "floor", "e_l2") if k not in pr]
    if miss:
        stop.append(f"{n}: new prices lack {miss}")
    prog = [w for w in nw if w["kind"] not in ("boot", "check")]
    marks = {w["mark"] for w in prog}

    def parts(ws):
        return {p: sum(w["energy"]["parts"].get(p, 0.0) for w in ws if w["mark"] in marks) for p in PARTS}

    rows.append((n, len(prog), sum(w["cycles"] for w in prog), parts(ow), parts(nw),
                 {k: pr.get(k) for k in ("r_strm", "r_xbar", "e_l2")}, pr.get("floor")))

print("| point | windows | cycles | " + " | ".join(f"{p} before / after" for p in PARTS) + " | total before / after | change |")
print("|---|---:|---:|" + "---:|" * (len(PARTS) + 2))
for n, k, c, b, a, _, _ in rows:
    tb, ta = sum(b.values()), sum(a.values())
    cells = " | ".join(f"{b[p]:.3f} / {a[p]:.3f}" for p in PARTS)
    print(f"| `{n}` | {k} | {c} | {cells} | {tb:.3f} / {ta:.3f} | {100 * (ta - tb) / tb:+.1f} % |")
terms = {json.dumps(t, sort_keys=True) + " " + json.dumps(f, sort_keys=True) for *_, t, f in rows}
print(f"\nprices' new terms (distinct across the {len(rows)} points: {len(terms)}):")
for t in sorted(terms):
    print(f"- {t}")
if stop:
    print("\nSTOP:\n" + "\n".join(f"- {x}" for x in stop))
    sys.exit(1)
print(f"\n{len(rows)} points: every window's mark, kind, cycles and counters equal; r_strm, floor, e_l2 present")
