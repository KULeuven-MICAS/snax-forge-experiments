from pathlib import Path
f = Path("tmp/cost3-r3/time_cmp.py")
s = f.read_text()
o = """res = root / "results" / "cluster" / "nangate45"
"""
n = """res = root / "results" / "cluster" / "nangate45"
import re  # noqa: E402
_N = r"([-+0-9.eE]+)"
_ROW_T = re.compile(rf"^( *)(\\S+)(?: \\((\\S+)\\))?\\s+{_N}\\s+{_N}\\s+{_N}\\s+(?:{_N}|N/A)\\s+\\S+\\s+\\S+\\s*$")


def parse_hier(text: str) -> list[dict]:
    \"\"\"cluster_energy.parse_hierarchy, and for a time-based report (Int, Switch, Leak, Peak Power, Peak Time,
    Glitch; no total) the same rows by the same depth rules, total = Int + Switch.\"\"\"
    if "Report : Time Based Power" not in text:
        return ce.parse_hierarchy(text)
    rows, stack = [], []
    for ln in text.splitlines():
        m = _ROW_T.match(ln)
        if not m:
            continue
        depth = len(m.group(1)) // 2
        name, design = m.group(2), m.group(3) or m.group(2)
        if not rows and depth != 0:
            continue
        while stack and stack[-1][0] >= depth:
            stack.pop()
        stack.append((depth, name))
        rows.append({"path": "/".join(x for _, x in stack[1:]), "design": design,
                     "total": float(m.group(4)) + float(m.group(5)), "int": float(m.group(4)),
                     "sw": float(m.group(5)), "leak": float(m.group(6))})
    return rows
"""
assert s.count(o) == 1
s = s.replace(o, n, 1)
s = s.replace("ce.window_groups(ce.parse_hierarchy(arc.read_text(za,", "ce.window_groups(parse_hier(arc.read_text(za,")
s = s.replace("ce.window_groups(ce.parse_hierarchy(arc.read_text(zt,", "ce.window_groups(parse_hier(arc.read_text(zt,")
o2 = """    if not ga or not gt:"""
n2 = """    nt = len(parse_hier(arc.read_text(zt, f"{n}/power_hierarchy.rpt")))
    na = len(ce.parse_hierarchy(arc.read_text(za, f"{n}/power_hierarchy.rpt")))
    if nt != na:
        sys.exit(f"{n}: {nt} hierarchy rows parsed time-based, {na} averaged")
    if not ga or not gt:"""
assert s.count(o2) == 1
s = s.replace(o2, n2)
f.write_text(s)
