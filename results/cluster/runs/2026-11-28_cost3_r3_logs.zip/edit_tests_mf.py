from pathlib import Path
f = Path("report/test_model_fit.py")
s = f.read_text()
o = '''

if __name__ == "__main__":'''
n = '''

def test_ge_order():
    """The runs as priced before the terms: CSYN2's tier A, GE1's dot3, else ge/ itself; a missing point fails."""
    import json  # noqa: PLC0415
    import tempfile  # noqa: PLC0415
    assert mf.GE_ORDER == ("csyn2", "ge1", "")
    assert mf.ge_path("nangate45", "mvt_column_cg").parent.name == "csyn2"
    assert mf.ge_path("nangate45", "dot3_w8_cg").parent.name == "ge1"
    with tempfile.TemporaryDirectory() as d:
        old, mf.ROOT = mf.ROOT, Path(d)
        try:
            ge = Path(d) / "results" / "cluster" / "nangate45" / "ge"
            for sub in ("", "ge1", "csyn2"):
                (ge / sub).mkdir(parents=True, exist_ok=True)
                (ge / sub / "p.json").write_text(json.dumps({"from": sub}))
                assert mf._ge("nangate45", "p") == {"from": sub}   # each folder added wins over the ones before
            try:
                mf.ge_path("nangate45", "q")
                raise AssertionError("no error for a missing point")
            except FileNotFoundError as e:
                assert "csyn2/" in str(e) and "ge1/" in str(e), e
        finally:
            mf.ROOT = old


if __name__ == "__main__":'''
assert s.count(o) == 1
f.write_text(s.replace(o, n))

f = Path("report/test_ablation.py")
s = f.read_text()
o = '''def test_committed_is_the_energy_run():'''
n = '''def test_run_column_only_beside_the_base():
    """run is ge/<point>.json's program window when it is a run priced with the terms beside the base, else empty."""
    import tempfile  # noqa: PLC0415
    run = {"prices": {"r_strm": 0.1}, "windows": [{"mark": 1, "energy": {"parts": {"memory": 2.0, "dma": 1.0}}},
                                                  {"mark": 9, "energy": {"parts": {"memory": 5.0}}}]}
    with tempfile.TemporaryDirectory() as d:
        old = ab.ROOT, mf.ROOT
        ab.ROOT = mf.ROOT = Path(d)
        try:
            ge = Path(d) / "results" / "cluster" / "nangate45" / "ge"
            (ge / "csyn2").mkdir(parents=True)
            (ge / "p.json").write_text(json.dumps(run))
            assert ab.rerun_nj("nangate45", "p", {1}) is None          # ge/p.json is the base itself
            (ge / "csyn2" / "p.json").write_text(json.dumps({**run, "prices": {}}))
            assert ab.rerun_nj("nangate45", "p", {1}) == 3.0           # beside CSYN2's: the program window's parts
            assert ab.base_ge("nangate45", "p")["prices"] == {}
            (ge / "p.json").write_text(json.dumps({**run, "prices": {}}))
            assert ab.rerun_nj("nangate45", "p", {1}) is None          # not priced with the terms
            (ge / "p.json").unlink()
            assert ab.rerun_nj("nangate45", "p", {1}) is None          # no run
        finally:
            ab.ROOT, mf.ROOT = old


def test_committed_is_the_energy_run():'''
assert s.count(o) == 1
f.write_text(s.replace(o, n))
