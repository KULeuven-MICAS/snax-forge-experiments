from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
reps = [
("""def main(p: dict, images: dict, args) -> int:
    signal.signal(signal.SIGTERM, cl._sigterm)
    pre = preflight(p, images, args)
""", """CUTS = ROOT / "tmp" / "cluster_time"               # --time-based: each window's VCD cut, between part 1 and part 2


def main_time(p: dict, images: dict, args, pre: dict) -> int:
    \"\"\"--time-based: part 1 again into pwr_time/ with every window's cut kept in CUTS/<point>/, then PT in
    time-based mode on the cuts (time_site); the cuts are deleted at the end, also on a failure. The averaged
    results (pwr/, pt/, power_pt.csv, power_reports/) are not touched.\"\"\"
    point = p["point"]
    keep = CUTS / point
    shutil.rmtree(keep, ignore_errors=True)
    keep.mkdir(parents=True)
    try:
        print(f"cluster pwr {point} --time-based: part 1 into pwr_time/, the cuts kept in {keep}", flush=True)
        res1 = part1(p, images, args, pre, sub="pwr_time", keep=keep)
        print(summary(point, res1) + f" (pack {res1.get('pack_s', 0):.0f} s)", flush=True)
        if res1["status"] != "PASS":
            if res1.get("failed_tail"):
                print(f"  last {TAIL} lines of {res1.get('failed_log')}:\\n{res1['failed_tail']}", flush=True)
            return 1
        vcds = {window_name(w): keep / f"{window_name(w)}.vcd" for w in res1["windows"]}
        print(f"cluster pwr {point} --time-based (part 2): PT time-based on {len(vcds)} cuts "
              f"({sum(v.stat().st_size for v in vcds.values() if v.is_file()) / 1e6:.1f} MB)", flush=True)
        res2 = part2(p, pre, args, res1, time_site(), vcds)
        print(summary2(point, res2) + f" (pack {res2.get('pack_s', 0):.0f} s)", flush=True)
        if res2["status"] != "PASS" and res2.get("failed_tail"):
            print(f"  last {TAIL} lines of {res2.get('failed_log')}:\\n{res2['failed_tail']}", flush=True)
        return 0 if res2["status"] == "PASS" else 1
    finally:
        shutil.rmtree(keep, ignore_errors=True)
        if CUTS.is_dir() and not any(CUTS.iterdir()):
            CUTS.rmdir()
        print(f"  cuts deleted: {keep}", flush=True)


def main(p: dict, images: dict, args) -> int:
    signal.signal(signal.SIGTERM, cl._sigterm)
    pre = preflight(p, images, args)
    if getattr(args, "time_based", False):
        return main_time(p, images, args, pre)
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:200]
    s = s.replace(o, n)
f.write_text(s)
f = Path("cluster/cluster.py")
s = f.read_text()
o = """    w.add_argument("--again", action="store_true", help="run part 1 again even when pwr/check.json is current")
"""
n = o + """    w.add_argument("--time-based", action="store_true",
                   help="part 1 again into pwr_time/ keeping each window's VCD cut, then PT in time-based mode on the "
                        "cuts into pt_time/ and power_reports_time/; the averaged results are left as they are")
"""
assert s.count(o) == 1
s = s.replace(o, n)
o = "  pixi run cluster pwr <point> [--cores N] [--again] [--allow-branch]   step 4: the energy per program section\n"
n = "  pixi run cluster pwr <point> [--cores N] [--again | --time-based] [--allow-branch]   step 4: the energy per program section\n"
assert s.count(o) == 1
f.write_text(s.replace(o, n))
