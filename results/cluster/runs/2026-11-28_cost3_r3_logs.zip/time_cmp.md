### Per window: the top's dynamic pJ a cycle

| window | cycles | averaged | time-based | time / avg |
|---|---:|---:|---:|---:|
| 1_dma_in | 116 | 109.23 | 94.72 | 0.867 |
| 2_dma_in | 38 | 34.80 | 22.95 | 0.659 |
| 3_dma_in | 58 | 40.76 | 28.68 | 0.704 |
| 4_streamer_config | 43 | 35.21 | 22.68 | 0.644 |
| 5_acc_config | 3 | 36.45 | 29.49 | 0.809 |
| 6_run | 550 | 57.51 | 43.58 | 0.758 |
| 7_dma_out | 35 | 51.67 | 35.38 | 0.685 |
| 8_dma_in | 35 | 35.67 | 23.80 | 0.667 |
| 9_dma_in | 42 | 45.64 | 32.98 | 0.723 |
| 10_streamer_config | 48 | 34.32 | 22.48 | 0.655 |
| 11_acc_config | 9 | 34.66 | 22.99 | 0.663 |
| 12_run | 549 | 48.35 | 35.11 | 0.726 |
| 13_dma_out | 75 | 40.51 | 27.05 | 0.668 |
| span | 1601 | 53.80 | 40.35 | 0.750 |

### Per group over the span: pJ a cycle (energy over the span's cycles)

| group | averaged | time-based | time / avg |
|---|---:|---:|---:|
| tcdm_banks | 5.215 | 6.328 | 1.213 |
| icache_macros | 0.532 | 0.636 | 1.197 |
| acc_datapath | 4.649 | 4.293 | 0.923 |
| acc_control | 0.405 | 0.211 | 0.522 |
| acc_csr | 0.503 | 0.254 | 0.505 |
| streamers | 6.864 | 5.203 | 0.758 |
| acc_interface | 0.488 | 0.430 | 0.881 |
| tcdm_interconnect | 4.193 | 3.803 | 0.907 |
| tcdm_logic | 3.702 | 2.818 | 0.761 |
| dma | 6.466 | 4.958 | 0.767 |
| cores | 3.788 | 2.838 | 0.749 |
| icache_logic | 1.216 | 1.069 | 0.879 |
| axi | 8.627 | 6.085 | 0.705 |
| peripherals | 7.117 | 1.409 | 0.198 |
| others | 0.031 | 0.017 | 0.543 |

### Per window and group: time-based over averaged (groups above 0.05 pJ a cycle in either mode)

| window | tcdm_banks | icache_macros | acc_datapath | acc_control | acc_csr | streamers | acc_interface | tcdm_interconnect | tcdm_logic | dma | cores | icache_logic | axi | peripherals | others |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1_dma_in | 1.694 * | 1.234 * | – | 0.890 * | 0.274 * | 0.805 * | 0.884 * | 0.780 * | 0.848 * | 0.784 * | 0.754 * | 0.828 * | 0.696 * | 0.200 * | 0.715 * |
| 2_dma_in | 1.862 * | 1.224 * | – | 0.890 * | 0.274 * | 0.805 * | 0.888 * | 0.780 * | 0.660 * | 0.756 * | 0.753 * | 0.821 * | 0.694 * | 0.201 * | – |
| 3_dma_in | 1.877 * | 1.216 * | – | 0.890 * | 0.274 * | 0.805 * | 0.886 * | 0.780 * | 0.710 * | 0.748 * | 0.755 * | 0.781 * | 0.687 * | 0.200 * | – |
| 4_streamer_config | – | 1.019 | – | 0.890 * | 0.274 * | 0.754 * | 0.898 * | 0.780 * | 0.619 * | 0.754 * | 0.744 * | 0.790 * | 0.706 * | 0.198 * | – |
| 5_acc_config | – | 3.909 * | – | 0.909 * | 0.284 * | 0.767 * | 0.905 * | 0.780 * | 0.619 * | 0.750 * | 0.799 * | 0.873 * | 0.708 * | 0.196 * | – |
| 6_run | 1.025 | 1.245 * | 0.903 * | 0.514 * | 0.557 * | 0.776 * | 0.878 * | 0.942 * | 0.764 * | 0.751 * | 0.748 * | 0.935 * | 0.721 * | 0.197 * | – |
| 7_dma_out | 1.000 | 1.319 * | – | 0.890 * | 0.298 * | 0.750 * | 0.914 * | 0.803 * | 0.779 * | 0.748 * | 0.765 * | 0.797 * | 0.660 * | 0.202 * | 0.864 * |
| 8_dma_in | 1.858 * | 1.223 * | – | 0.890 * | 0.296 * | 0.805 * | 0.933 * | 0.786 * | 0.668 * | 0.759 * | 0.757 * | 0.826 * | 0.695 * | 0.202 * | – |
| 9_dma_in | 1.866 * | 1.227 * | – | 0.890 * | 0.296 * | 0.805 * | 0.938 * | 0.786 * | 0.727 * | 0.746 * | 0.766 * | 0.815 * | 0.683 * | 0.201 * | – |
| 10_streamer_config | – | 1.149 * | – | 0.890 * | 0.296 * | 0.757 * | 0.925 * | 0.786 * | 0.619 * | 0.762 * | 0.748 * | 0.807 * | 0.713 * | 0.198 * | – |
| 11_acc_config | – | 1.619 * | – | 0.887 * | 0.317 * | 0.788 * | 0.928 * | 0.786 * | 0.619 * | 0.763 * | 0.812 * | 0.783 * | 0.700 * | 0.198 * | – |
| 12_run | 1.043 | 1.145 * | 0.949 * | 0.478 * | 0.569 * | 0.726 * | 0.877 * | 0.914 * | 0.745 * | 0.767 * | 0.745 * | 0.886 * | 0.723 * | 0.197 * | – |
| 13_dma_out | 1.000 | 1.167 * | – | 0.890 * | 0.296 * | 0.791 * | 0.934 * | 0.792 * | 0.721 * | 0.755 * | 0.755 * | 0.764 * | 0.675 * | 0.200 * | 0.756 * |

`*` beyond 5 %.

### The banks: averaged PT, time-based PT, counted (nJ per window)

| window | averaged PT | time-based PT | counted | time-based / counted | averaged / counted |
|---|---:|---:|---:|---:|---:|
| 1_dma_in | 1.9501 | 3.3042 | 3.3042 | 1.0000 | 0.5902 |
| 2_dma_in | 0.0277 | 0.0516 | 0.0516 | 1.0000 | 0.5371 |
| 3_dma_in | 0.1100 | 0.2065 | 0.2065 | 1.0000 | 0.5328 |
| 4_streamer_config | 0.0000 | 0.0000 | 0.0000 | nan | nan |
| 5_acc_config | 0.0000 | 0.0000 | 0.0000 | nan | nan |
| 6_run | 3.7132 | 3.8053 | 3.7816 | 1.0063 | 0.9819 |
| 7_dma_out | 0.1095 | 0.1095 | 0.1083 | 1.0107 | 1.0110 |
| 8_dma_in | 0.0278 | 0.0516 | 0.0516 | 1.0000 | 0.5382 |
| 9_dma_in | 0.1107 | 0.2065 | 0.2065 | 1.0000 | 0.5359 |
| 10_streamer_config | 0.0000 | 0.0000 | 0.0000 | nan | nan |
| 11_acc_config | 0.0000 | 0.0000 | 0.0000 | nan | nan |
| 12_run | 2.1910 | 2.2856 | 2.2649 | 1.0091 | 0.9673 |
| 13_dma_out | 0.1095 | 0.1095 | 0.1083 | 1.0106 | 1.0108 |
| span | 8.3495 | 10.1304 | 10.0837 | 1.0046 | 0.8280 |

windows where time-based and counted differ by more than 1 %: 7_dma_out 1.0107, 13_dma_out 1.0106

### pwr_time/'s SAIFs against pwr/'s (bank counts per window)

13 of 13 windows with equal bank counts

### Beyond 5 %

- tcdm_banks over the span: 1.213
- icache_macros over the span: 1.197
- acc_datapath over the span: 0.923
- acc_control over the span: 0.522
- acc_csr over the span: 0.505
- streamers over the span: 0.758
- acc_interface over the span: 0.881
- tcdm_interconnect over the span: 0.907
- tcdm_logic over the span: 0.761
- dma over the span: 0.767
- cores over the span: 0.749
- icache_logic over the span: 0.879
- axi over the span: 0.705
- peripherals over the span: 0.198
- 1_dma_in tcdm_banks: 16.811 -> 28.485 pJ/cycle (1.694)
- 1_dma_in icache_macros: 0.592 -> 0.731 pJ/cycle (1.234)
- 1_dma_in acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 1_dma_in acc_csr: 0.330 -> 0.091 pJ/cycle (0.274)
- 1_dma_in streamers: 2.642 -> 2.127 pJ/cycle (0.805)
- 1_dma_in acc_interface: 0.131 -> 0.116 pJ/cycle (0.884)
- 1_dma_in tcdm_interconnect: 2.100 -> 1.637 pJ/cycle (0.780)
- 1_dma_in tcdm_logic: 9.294 -> 7.878 pJ/cycle (0.848)
- 1_dma_in dma: 34.221 -> 26.836 pJ/cycle (0.784)
- 1_dma_in cores: 3.276 -> 2.470 pJ/cycle (0.754)
- 1_dma_in icache_logic: 0.964 -> 0.798 pJ/cycle (0.828)
- 1_dma_in axi: 31.621 -> 22.020 pJ/cycle (0.696)
- 1_dma_in peripherals: 7.116 -> 1.425 pJ/cycle (0.200)
- 1_dma_in others: 0.050 -> 0.036 pJ/cycle (0.715)
- 2_dma_in tcdm_banks: 0.730 -> 1.359 pJ/cycle (1.862)
- 2_dma_in icache_macros: 0.910 -> 1.114 pJ/cycle (1.224)
- 2_dma_in acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 2_dma_in acc_csr: 0.330 -> 0.091 pJ/cycle (0.274)
- 2_dma_in streamers: 2.642 -> 2.127 pJ/cycle (0.805)
- 2_dma_in acc_interface: 0.155 -> 0.137 pJ/cycle (0.888)
- 2_dma_in tcdm_interconnect: 2.100 -> 1.637 pJ/cycle (0.780)
- 2_dma_in tcdm_logic: 2.413 -> 1.593 pJ/cycle (0.660)
- 2_dma_in dma: 5.963 -> 4.508 pJ/cycle (0.756)
- 2_dma_in cores: 3.082 -> 2.321 pJ/cycle (0.753)
- 2_dma_in icache_logic: 1.034 -> 0.849 pJ/cycle (0.821)
- 2_dma_in axi: 8.197 -> 5.691 pJ/cycle (0.694)
- 2_dma_in peripherals: 7.137 -> 1.437 pJ/cycle (0.201)
- 3_dma_in tcdm_banks: 1.897 -> 3.561 pJ/cycle (1.877)
- 3_dma_in icache_macros: 1.197 -> 1.456 pJ/cycle (1.216)
- 3_dma_in acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 3_dma_in acc_csr: 0.330 -> 0.091 pJ/cycle (0.274)
- 3_dma_in streamers: 2.642 -> 2.127 pJ/cycle (0.805)
- 3_dma_in acc_interface: 0.135 -> 0.120 pJ/cycle (0.886)
- 3_dma_in tcdm_interconnect: 2.100 -> 1.637 pJ/cycle (0.780)
- 3_dma_in tcdm_logic: 2.955 -> 2.099 pJ/cycle (0.710)
- 3_dma_in dma: 8.020 -> 5.999 pJ/cycle (0.748)
- 3_dma_in cores: 2.664 -> 2.010 pJ/cycle (0.755)
- 3_dma_in icache_logic: 1.149 -> 0.898 pJ/cycle (0.781)
- 3_dma_in axi: 10.435 -> 7.167 pJ/cycle (0.687)
- 3_dma_in peripherals: 7.124 -> 1.428 pJ/cycle (0.200)
- 4_streamer_config acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 4_streamer_config acc_csr: 0.330 -> 0.091 pJ/cycle (0.274)
- 4_streamer_config streamers: 2.915 -> 2.197 pJ/cycle (0.754)
- 4_streamer_config acc_interface: 0.265 -> 0.238 pJ/cycle (0.898)
- 4_streamer_config tcdm_interconnect: 2.100 -> 1.637 pJ/cycle (0.780)
- 4_streamer_config tcdm_logic: 2.074 -> 1.285 pJ/cycle (0.619)
- 4_streamer_config dma: 3.344 -> 2.523 pJ/cycle (0.754)
- 4_streamer_config cores: 4.670 -> 3.473 pJ/cycle (0.744)
- 4_streamer_config icache_logic: 1.876 -> 1.482 pJ/cycle (0.790)
- 4_streamer_config axi: 7.511 -> 5.303 pJ/cycle (0.706)
- 4_streamer_config peripherals: 7.110 -> 1.406 pJ/cycle (0.198)
- 5_acc_config icache_macros: 1.917 -> 7.494 pJ/cycle (3.909)
- 5_acc_config acc_control: 0.077 -> 0.070 pJ/cycle (0.909)
- 5_acc_config acc_csr: 0.460 -> 0.131 pJ/cycle (0.284)
- 5_acc_config streamers: 2.875 -> 2.206 pJ/cycle (0.767)
- 5_acc_config acc_interface: 0.363 -> 0.328 pJ/cycle (0.905)
- 5_acc_config tcdm_interconnect: 2.100 -> 1.637 pJ/cycle (0.780)
- 5_acc_config tcdm_logic: 2.074 -> 1.285 pJ/cycle (0.619)
- 5_acc_config dma: 3.366 -> 2.523 pJ/cycle (0.750)
- 5_acc_config cores: 7.867 -> 6.283 pJ/cycle (0.799)
- 5_acc_config icache_logic: 1.838 -> 1.605 pJ/cycle (0.873)
- 5_acc_config axi: 6.365 -> 4.505 pJ/cycle (0.708)
- 5_acc_config peripherals: 7.109 -> 1.396 pJ/cycle (0.196)
- 6_run icache_macros: 0.124 -> 0.154 pJ/cycle (1.245)
- 6_run acc_datapath: 7.507 -> 6.779 pJ/cycle (0.903)
- 6_run acc_control: 0.763 -> 0.392 pJ/cycle (0.514)
- 6_run acc_csr: 0.582 -> 0.324 pJ/cycle (0.557)
- 6_run streamers: 9.644 -> 7.483 pJ/cycle (0.776)
- 6_run acc_interface: 0.567 -> 0.498 pJ/cycle (0.878)
- 6_run tcdm_interconnect: 5.840 -> 5.501 pJ/cycle (0.942)
- 6_run tcdm_logic: 3.604 -> 2.753 pJ/cycle (0.764)
- 6_run dma: 3.523 -> 2.645 pJ/cycle (0.751)
- 6_run cores: 3.982 -> 2.979 pJ/cycle (0.748)
- 6_run icache_logic: 1.631 -> 1.524 pJ/cycle (0.935)
- 6_run axi: 5.853 -> 4.220 pJ/cycle (0.721)
- 6_run peripherals: 7.115 -> 1.402 pJ/cycle (0.197)
- 7_dma_out icache_macros: 1.346 -> 1.775 pJ/cycle (1.319)
- 7_dma_out acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 7_dma_out acc_csr: 0.331 -> 0.099 pJ/cycle (0.298)
- 7_dma_out streamers: 2.899 -> 2.173 pJ/cycle (0.750)
- 7_dma_out acc_interface: 0.277 -> 0.254 pJ/cycle (0.914)
- 7_dma_out tcdm_interconnect: 2.275 -> 1.826 pJ/cycle (0.803)
- 7_dma_out tcdm_logic: 4.150 -> 3.235 pJ/cycle (0.779)
- 7_dma_out dma: 10.615 -> 7.936 pJ/cycle (0.748)
- 7_dma_out cores: 3.590 -> 2.746 pJ/cycle (0.765)
- 7_dma_out icache_logic: 1.509 -> 1.203 pJ/cycle (0.797)
- 7_dma_out axi: 14.217 -> 9.389 pJ/cycle (0.660)
- 7_dma_out peripherals: 7.139 -> 1.445 pJ/cycle (0.202)
- 7_dma_out others: 0.111 -> 0.096 pJ/cycle (0.864)
- 8_dma_in tcdm_banks: 0.794 -> 1.475 pJ/cycle (1.858)
- 8_dma_in icache_macros: 0.989 -> 1.209 pJ/cycle (1.223)
- 8_dma_in acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 8_dma_in acc_csr: 0.330 -> 0.098 pJ/cycle (0.296)
- 8_dma_in streamers: 2.642 -> 2.127 pJ/cycle (0.805)
- 8_dma_in acc_interface: 0.161 -> 0.151 pJ/cycle (0.933)
- 8_dma_in tcdm_interconnect: 2.100 -> 1.651 pJ/cycle (0.786)
- 8_dma_in tcdm_logic: 2.462 -> 1.646 pJ/cycle (0.668)
- 8_dma_in dma: 6.350 -> 4.818 pJ/cycle (0.759)
- 8_dma_in cores: 3.284 -> 2.486 pJ/cycle (0.757)
- 8_dma_in icache_logic: 1.114 -> 0.921 pJ/cycle (0.826)
- 8_dma_in axi: 8.198 -> 5.698 pJ/cycle (0.695)
- 8_dma_in peripherals: 7.142 -> 1.441 pJ/cycle (0.202)
- 9_dma_in tcdm_banks: 2.635 -> 4.917 pJ/cycle (1.866)
- 9_dma_in icache_macros: 0.822 -> 1.008 pJ/cycle (1.227)
- 9_dma_in acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 9_dma_in acc_csr: 0.330 -> 0.098 pJ/cycle (0.296)
- 9_dma_in streamers: 2.642 -> 2.127 pJ/cycle (0.805)
- 9_dma_in acc_interface: 0.142 -> 0.133 pJ/cycle (0.938)
- 9_dma_in tcdm_interconnect: 2.100 -> 1.651 pJ/cycle (0.786)
- 9_dma_in tcdm_logic: 3.350 -> 2.436 pJ/cycle (0.727)
- 9_dma_in dma: 10.277 -> 7.670 pJ/cycle (0.746)
- 9_dma_in cores: 3.238 -> 2.481 pJ/cycle (0.766)
- 9_dma_in icache_logic: 1.112 -> 0.906 pJ/cycle (0.815)
- 9_dma_in axi: 11.749 -> 8.024 pJ/cycle (0.683)
- 9_dma_in peripherals: 7.135 -> 1.437 pJ/cycle (0.201)
- 10_streamer_config icache_macros: 2.714 -> 3.118 pJ/cycle (1.149)
- 10_streamer_config acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 10_streamer_config acc_csr: 0.330 -> 0.098 pJ/cycle (0.296)
- 10_streamer_config streamers: 2.886 -> 2.184 pJ/cycle (0.757)
- 10_streamer_config acc_interface: 0.249 -> 0.230 pJ/cycle (0.925)
- 10_streamer_config tcdm_interconnect: 2.100 -> 1.651 pJ/cycle (0.786)
- 10_streamer_config tcdm_logic: 2.074 -> 1.285 pJ/cycle (0.619)
- 10_streamer_config dma: 3.337 -> 2.543 pJ/cycle (0.762)
- 10_streamer_config cores: 4.330 -> 3.240 pJ/cycle (0.748)
- 10_streamer_config icache_logic: 1.686 -> 1.360 pJ/cycle (0.807)
- 10_streamer_config axi: 7.405 -> 5.282 pJ/cycle (0.713)
- 10_streamer_config peripherals: 7.108 -> 1.405 pJ/cycle (0.198)
- 11_acc_config icache_macros: 1.368 -> 2.215 pJ/cycle (1.619)
- 11_acc_config acc_control: 0.067 -> 0.060 pJ/cycle (0.887)
- 11_acc_config acc_csr: 0.383 -> 0.121 pJ/cycle (0.317)
- 11_acc_config streamers: 2.746 -> 2.163 pJ/cycle (0.788)
- 11_acc_config acc_interface: 0.277 -> 0.257 pJ/cycle (0.928)
- 11_acc_config tcdm_interconnect: 2.100 -> 1.651 pJ/cycle (0.786)
- 11_acc_config tcdm_logic: 2.074 -> 1.285 pJ/cycle (0.619)
- 11_acc_config dma: 3.328 -> 2.538 pJ/cycle (0.763)
- 11_acc_config cores: 3.991 -> 3.240 pJ/cycle (0.812)
- 11_acc_config icache_logic: 2.449 -> 1.918 pJ/cycle (0.783)
- 11_acc_config axi: 8.722 -> 6.110 pJ/cycle (0.700)
- 11_acc_config peripherals: 7.113 -> 1.409 pJ/cycle (0.198)
- 12_run icache_macros: 0.103 -> 0.118 pJ/cycle (1.145)
- 12_run acc_datapath: 6.024 -> 5.715 pJ/cycle (0.949)
- 12_run acc_control: 0.357 -> 0.171 pJ/cycle (0.478)
- 12_run acc_csr: 0.581 -> 0.331 pJ/cycle (0.569)
- 12_run streamers: 7.859 -> 5.706 pJ/cycle (0.726)
- 12_run acc_interface: 0.693 -> 0.608 pJ/cycle (0.877)
- 12_run tcdm_interconnect: 4.432 -> 4.053 pJ/cycle (0.914)
- 12_run tcdm_logic: 3.253 -> 2.422 pJ/cycle (0.745)
- 12_run dma: 3.418 -> 2.620 pJ/cycle (0.767)
- 12_run cores: 3.987 -> 2.969 pJ/cycle (0.745)
- 12_run icache_logic: 0.710 -> 0.629 pJ/cycle (0.886)
- 12_run axi: 5.799 -> 4.191 pJ/cycle (0.723)
- 12_run peripherals: 7.115 -> 1.402 pJ/cycle (0.197)
- 13_dma_out icache_macros: 2.190 -> 2.555 pJ/cycle (1.167)
- 13_dma_out acc_control: 0.065 -> 0.058 pJ/cycle (0.890)
- 13_dma_out acc_csr: 0.330 -> 0.098 pJ/cycle (0.296)
- 13_dma_out streamers: 2.775 -> 2.195 pJ/cycle (0.791)
- 13_dma_out acc_interface: 0.151 -> 0.141 pJ/cycle (0.934)
- 13_dma_out tcdm_interconnect: 2.189 -> 1.733 pJ/cycle (0.792)
- 13_dma_out tcdm_logic: 3.082 -> 2.221 pJ/cycle (0.721)
- 13_dma_out dma: 6.758 -> 5.105 pJ/cycle (0.755)
- 13_dma_out cores: 2.521 -> 1.904 pJ/cycle (0.755)
- 13_dma_out icache_logic: 1.532 -> 1.171 pJ/cycle (0.764)
- 13_dma_out axi: 10.264 -> 6.925 pJ/cycle (0.675)
- 13_dma_out peripherals: 7.123 -> 1.426 pJ/cycle (0.200)
- 13_dma_out others: 0.060 -> 0.045 pJ/cycle (0.756)
