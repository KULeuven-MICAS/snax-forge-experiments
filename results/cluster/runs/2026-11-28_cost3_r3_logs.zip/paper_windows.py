import json, sys
P = ("datapath", "control", "streamers", "crossbar", "memory", "dma")
for s, i in (("forms", "mvt_column"), ("forms", "atax_read_once"), ("forms", "mvt_dma_copy"), ("limits", "bicg_sequential_padded_w32")):
    e = json.load(open(f"out/paper/{s}/{i}/energy/energy.json"))
    def tot(ws):
        return sum(w["energy"]["total"] for w in ws), sum(w["cycles"] for w in ws)
    boot = [w for w in e["windows"] if w["kind"] == "boot"]
    chk = [w for w in e["windows"] if w["kind"] == "check"]
    prog = [w for w in e["windows"] if w["kind"] not in ("boot", "check")]
    (eb, cb), (ep, cp), (ec, cc) = tot(boot), tot(prog), tot(chk)
    print(f"| `{i}` | {cb} / {cp} / {cc} | {eb:.2f} / {ep:.2f} / {ec:.2f} | {sum(e['total'][p] for p in P):.2f} |")
