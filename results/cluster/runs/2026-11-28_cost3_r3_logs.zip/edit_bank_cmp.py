from pathlib import Path
f = Path("tmp/cost3-r3/bank_cmp.py")
s = f.read_text()
reps = [("""root = Path(sys.argv[1])
""", """root = Path(sys.argv[1])
sys.path.insert(0, str(root / "report"))
import model_fit as mf  # noqa: E402  ge_path: ge/csyn2/, ge/ge1/, ge/
"""),
("""    ge = json.loads((res / "ge" / f"{pt}.json").read_text())
""", """    gf = res / "ge" / f"{pt}.json"
    gf = gf if gf.is_file() else mf.ge_path("nangate45", pt)   # dot3: GE1's run, the program its SAIFs are of
    ge = json.loads(gf.read_text())
    src[pt] = str(gf.relative_to(res / "ge"))
"""),
("""beyond_all = []
""", """beyond_all = []
src = {}
"""),
("""print(f"\\n{len(beyond_all)} windows beyond 1 %")
""", """print(f"\\n{len(beyond_all)} windows beyond 1 %; SNAX-GVSoC runs read: "
      + ", ".join(f"{p} {s}" for p, s in src.items() if "/" in s))
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o
    s = s.replace(o, n)
f.write_text(s)
