"""Step 6: averaged PT against time-based PT on one point, per window and per group of cluster/groups.json.

    pixi run python time_cmp.py SFE_ROOT POINT

Reads power_reports/<point>.zip (averaged) and power_reports_time/<point>.zip (time-based), each window's
power_hierarchy.rpt summed into groups.json's groups (report/cluster_energy.py's rules), dynamic only. The banks:
averaged PT, time-based PT and bank_counts.json's counted energy. Also the time-based run's SAIFs (pwr_time/) against
the averaged run's (pwr/): their bank counts per window (report/bank_counts.py's count) must be equal.
"""

import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
point = sys.argv[2]
sys.path[:0] = [str(root / "arc"), str(root / "report")]
import arc  # noqa: E402
import bank_counts as bc  # noqa: E402
import cluster_energy as ce  # noqa: E402

res = root / "results" / "cluster" / "nangate45"
import re  # noqa: E402
_N = r"([-+0-9.eE]+)"
_ROW_T = re.compile(rf"^( *)(\S+)(?: \((\S+)\))?\s+{_N}\s+{_N}\s+{_N}\s+(?:{_N}|N/A)\s+\S+\s+{_N}\s+{_N}\s+{_N}"
                    rf"\s+(?:{_N}|N/A)\s*$")


def parse_hier(text: str) -> list[dict]:
    """cluster_energy.parse_hierarchy, and for a time-based report (Int, Switch, Leak, Peak Power, Peak Time,
    Glitch, X-tran, Total, %) the same rows by the same depth rules, total = Int + Switch."""
    if "Report : Time Based Power" not in text:
        return ce.parse_hierarchy(text)
    rows, stack = [], []
    for ln in text.splitlines():
        m = _ROW_T.match(ln)
        if not m:
            continue
        depth = len(m.group(1)) // 2
        name, design = m.group(2), m.group(3) or m.group(2)
        if not rows and depth != 0:
            continue
        while stack and stack[-1][0] >= depth:
            stack.pop()
        stack.append((depth, name))
        rows.append({"path": "/".join(x for _, x in stack[1:]), "design": design,
                     "total": float(m.group(4)) + float(m.group(5)), "int": float(m.group(4)),
                     "sw": float(m.group(5)), "leak": float(m.group(6))})
    return rows
cfg = json.loads((root / "cluster" / "groups.json").read_text())
za, zt = res / "power_reports" / f"{point}.zip", res / "power_reports_time" / f"{point}.zip"
wins = json.loads(arc.read(zt, "windows.json"))
counted = json.loads((res / "bank_counts.json").read_text())["points"][point]["windows"]
CLK = 10.0
FLAG = 0.05

rows, big = [], []
tot = {"avg": {}, "time": {}, "cyc": 0}
for w in wins:
    n = f"{w['mark']}_{w['kind']}"
    ga = ce.window_groups(parse_hier(arc.read_text(za, f"{n}/power_hierarchy.rpt")), cfg, CLK)
    gt = ce.window_groups(parse_hier(arc.read_text(zt, f"{n}/power_hierarchy.rpt")), cfg, CLK)
    nt = len(parse_hier(arc.read_text(zt, f"{n}/power_hierarchy.rpt")))
    na = len(ce.parse_hierarchy(arc.read_text(za, f"{n}/power_hierarchy.rpt")))
    if nt != na:
        sys.exit(f"{n}: {nt} hierarchy rows parsed time-based, {na} averaged")
    if not ga or not gt:
        sys.exit(f"{n}: no hierarchy rows parsed (averaged {len(ga)}, time-based {len(gt)})")
    c = w["cycles"]
    tot["cyc"] += c
    for g in ga:
        tot["avg"][g] = tot["avg"].get(g, 0.0) + ga[g] * c
        tot["time"][g] = tot["time"].get(g, 0.0) + gt.get(g, 0.0) * c
    rows.append((n, c, ga, gt))

groups = [g for g in rows[0][2]]
print("### Per window: the top's dynamic pJ a cycle\n")
print("| window | cycles | averaged | time-based | time / avg |")
print("|---|---:|---:|---:|---:|")
for n, c, ga, gt in rows:
    a, t = sum(ga.values()), sum(gt.values())
    print(f"| {n} | {c} | {a:.2f} | {t:.2f} | {t / a:.3f} |")
a, t = sum(tot["avg"].values()) / tot["cyc"], sum(tot["time"].values()) / tot["cyc"]
print(f"| span | {tot['cyc']} | {a:.2f} | {t:.2f} | {t / a:.3f} |")

print("\n### Per group over the span: pJ a cycle (energy over the span's cycles)\n")
print("| group | averaged | time-based | time / avg |")
print("|---|---:|---:|---:|")
for g in groups:
    a, t = tot["avg"][g] / tot["cyc"], tot["time"][g] / tot["cyc"]
    r = t / a if a else float("nan")
    print(f"| {g} | {a:.3f} | {t:.3f} | {r:.3f} |")
    if a and abs(r - 1) > FLAG and max(a, t) > 0.05:
        big.append(f"{g} over the span: {r:.3f}")

print("\n### Per window and group: time-based over averaged (groups above 0.05 pJ a cycle in either mode)\n")
print("| window | " + " | ".join(groups) + " |")
print("|---|" + "---:|" * len(groups))
for n, c, ga, gt in rows:
    cells = []
    for g in groups:
        a, t = ga.get(g, 0.0), gt.get(g, 0.0)
        if max(a, t) <= 0.05:
            cells.append("–")
            continue
        r = t / a if a else float("inf")
        cells.append(f"{r:.3f}" + (" *" if abs(r - 1) > FLAG else ""))
        if abs(r - 1) > FLAG:
            big.append(f"{n} {g}: {a:.3f} -> {t:.3f} pJ/cycle ({r:.3f})")
    print(f"| {n} | " + " | ".join(cells) + " |")
print("\n`*` beyond 5 %.")

print("\n### The banks: averaged PT, time-based PT, counted (nJ per window)\n")
print("| window | averaged PT | time-based PT | counted | time-based / counted | averaged / counted |")
print("|---|---:|---:|---:|---:|---:|")
sa = st = sc = 0.0
beyond = []
for n, c, ga, gt in rows:
    a, t, k = ga["tcdm_banks"] * c / 1e3, gt["tcdm_banks"] * c / 1e3, counted[n]["counted_nj"]
    sa, st, sc = sa + a, st + t, sc + k
    rt = t / k if k else float("nan")
    if k and abs(rt - 1) > 0.01:
        beyond.append(f"{n} {rt:.4f}")
    print(f"| {n} | {a:.4f} | {t:.4f} | {k:.4f} | {rt:.4f} | {a / k if k else float('nan'):.4f} |")
print(f"| span | {sa:.4f} | {st:.4f} | {sc:.4f} | {st / sc:.4f} | {sa / sc:.4f} |")
print(f"\nwindows where time-based and counted differ by more than 1 %: {', '.join(beyond) or 'none'}")

print("\n### pwr_time/'s SAIFs against pwr/'s (bank counts per window)\n")
rz = root / "sim" / "runs" / "cluster" / "nangate45" / f"{point}.zip"
same = []
for n, *_ in rows:
    ca = bc.count(arc.read_text(rz, f"pwr/{n}/w.saif"))
    ct = bc.count(arc.read_text(rz, f"pwr_time/{n}/w.saif"))
    same.append(ca == ct)
    if ca != ct:
        print(f"- {n}: pwr/ {ca}, pwr_time/ {ct}")
print(f"{sum(same)} of {len(same)} windows with equal bank counts")
print("\n### Beyond 5 %\n")
print("\n".join(f"- {b}" for b in big) or "none")
