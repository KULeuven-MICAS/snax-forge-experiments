import json
o = json.load(open("results/cluster/nangate45/ge/csyn2/dot3_w16_cg.json"))
n = json.load(open("results/cluster/nangate45/ge/dot3_w16_cg.json"))
print("old source", json.dumps(o.get("source"))[:400])
print("new source", json.dumps(n.get("source"))[:400])
for a, b in zip(o["windows"], n["windows"]):
    ka, kb = set(a["counters"]), set(b["counters"])
    print(a["mark"], a["kind"], a["cycles"], b["cycles"], "keys only old", sorted(ka - kb), "only new", sorted(kb - ka),
          "copies old", a["counters"].get("copies"), "new", b["counters"].get("copies"))
r_o = [w for w in o["windows"] if w["kind"] == "run"][0]["counters"]
r_n = [w for w in n["windows"] if w["kind"] == "run"][0]["counters"]
print("banks old sum", sum(x["reads"] + x["writes"] for x in r_o["banks"]), "new", sum(x["reads"] + x["writes"] for x in r_n["banks"]))
print("groups old", r_o["groups"], "\ngroups new", r_n["groups"])
