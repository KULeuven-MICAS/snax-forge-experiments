
### forms.csv

- rows: 21 before, 21 after; status before {'ok': 21}, after {'ok': 21}
- energy columns that moved: dynamic_crossbar_nj, dynamic_dma_nj, dynamic_memory_nj, dynamic_nj, dynamic_streamers_nj, idle_nj, static_crossbar_nj, static_dma_nj, static_memory_nj, static_nj, static_streamers_nj

`static_nj`: before min 25.5945, max 818.1765, sum 3156.0499; after min 37.0166, max 783.4868, sum 3371.4417

| id | static_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `mvt_dma_copy` | 803.3929 | 755.9903 | -47.4026 | -5.9 |
| `gesummv_literal` | 125.2664 | 165.6571 | +40.3907 | +32.2 |
| `gesummv_literal_shared_movers` | 125.2727 | 163.0605 | +37.7878 | +30.2 |
| `atax_dma_copy_shared_movers` | 818.1765 | 781.4277 | -36.7488 | -4.5 |
| `atax_dma_copy` | 818.1765 | 783.4868 | -34.6897 | -4.2 |

`dynamic_nj`: before min 25.6208, max 818.6341, sum 3160.6711; after min 76.0982, max 827.8625, sum 4517.9042

| id | dynamic_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `gesummv_literal` | 126.1920 | 254.5941 | +128.4021 | +101.8 |
| `gesummv_factor_out` | 32.2119 | 121.0635 | +88.8516 | +275.8 |
| `mvt_column` | 26.2409 | 111.1973 | +84.9564 | +323.8 |
| `mvt_column_chain` | 26.3990 | 111.3514 | +84.9524 | +321.8 |
| `mvt_column_pipeline` | 26.5645 | 111.2307 | +84.6662 | +318.7 |

`idle_nj`: before min 18.7852, max 295.2067, sum 1428.3626; after min 14.9537, max 234.9955, sum 1137.0290

| id | idle_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `mvt_dma_copy` | 295.2067 | 234.9955 | -60.2112 | -20.4 |
| `atax_dma_copy_shared_movers` | 292.7760 | 233.0605 | -59.7155 | -20.4 |
| `atax_dma_copy` | 291.8084 | 232.2903 | -59.5181 | -20.4 |
| `gesummv_literal_shared_movers` | 58.2437 | 46.3641 | -11.8796 | -20.4 |
| `gesummv_literal` | 57.5357 | 45.8005 | -11.7352 | -20.4 |
| `mvt_column_chain` | 37.3109 | 29.7008 | -7.6101 | -20.4 |
| `mvt_column` | 37.2401 | 29.6445 | -7.5956 | -20.4 |
| `bicg_two_pass` | 34.8565 | 27.7471 | -7.1094 | -20.4 |
| `gesummv_factor_out_shared_movers` | 32.5438 | 25.9060 | -6.6378 | -20.4 |
| `gesummv_factor_out_shared_engine` | 32.4966 | 25.8685 | -6.6281 | -20.4 |
| `gesummv_factor_out` | 32.2370 | 25.6618 | -6.5752 | -20.4 |
| `atax_column_shared_movers` | 30.8682 | 24.5722 | -6.2960 | -20.4 |
| `atax_column` | 30.8446 | 24.5534 | -6.2912 | -20.4 |
| `gesummv_x_read_once` | 21.6644 | 17.2456 | -4.4188 | -20.4 |
| `gesummv_factor_out_pipeline` | 21.5228 | 17.1329 | -4.3899 | -20.4 |
| `mvt_column_pipeline` | 21.3340 | 16.9826 | -4.3514 | -20.4 |
| `mvt_read_once` | 21.2160 | 16.8887 | -4.3273 | -20.4 |
| `bicg_two_pass_pipeline` | 20.3192 | 16.1748 | -4.1444 | -20.4 |
| `bicg_read_once` | 20.2012 | 16.0809 | -4.1203 | -20.4 |
| `atax_t_linked` | 19.3516 | 15.4046 | -3.9470 | -20.4 |
| `atax_read_once` | 18.7852 | 14.9537 | -3.8315 | -20.4 |

### limits.csv

- rows: 36 before, 36 after; status before {'ok': 36}, after {'ok': 36}
- energy columns that moved: dynamic_crossbar_nj, dynamic_dma_nj, dynamic_memory_nj, dynamic_nj, dynamic_streamers_nj, idle_nj, static_crossbar_nj, static_dma_nj, static_memory_nj, static_nj, static_streamers_nj

`static_nj`: before min 205.4381, max 283.4984, sum 8234.8690; after min 266.6084, max 358.0494, sum 10621.2632

| id | static_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `bicg_sequential_contiguous_banks16` | 242.9752 | 318.9151 | +75.9399 | +31.3 |
| `bicg_sequential_padded_banks16` | 242.9752 | 318.9151 | +75.9399 | +31.3 |
| `bicg_sequential_contiguous_w4` | 215.8826 | 291.6319 | +75.7493 | +35.1 |
| `bicg_sequential_padded_w4` | 215.8826 | 291.6319 | +75.7493 | +35.1 |
| `mvt_contiguous_banks16` | 283.4984 | 358.0494 | +74.5510 | +26.3 |

`dynamic_nj`: before min 208.0075, max 485.9205, sum 9691.0978; after min 426.8090, max 768.1839, sum 18832.6114

| id | dynamic_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `bicg_sequential_padded_w32` | 245.0404 | 768.1839 | +523.1435 | +213.5 |
| `bicg_sequential_contiguous_w32` | 245.0231 | 737.7851 | +492.7620 | +201.1 |
| `bicg_pipeline_padded_w32` | 303.2929 | 741.7499 | +438.4570 | +144.6 |
| `bicg_pipeline_contiguous_w32` | 307.6901 | 741.1312 | +433.4411 | +140.9 |
| `bicg_sequential_padded_w16` | 208.5810 | 567.2741 | +358.6931 | +172.0 |

`idle_nj`: before min 25.9359, max 133.6678, sum 1847.0181; after min 20.6459, max 106.4045, sum 1470.2948

| id | idle_nj before | after | change | % |
|---|---:|---:|---:|---:|
| `mvt_contiguous_w4` | 133.6678 | 106.4045 | -27.2633 | -20.4 |
| `mvt_contiguous_banks16` | 110.4459 | 87.9190 | -22.5269 | -20.4 |
| `mvt_contiguous_w8` | 109.2423 | 86.9609 | -22.2814 | -20.4 |
| `mvt_contiguous_banks64` | 108.1803 | 86.1155 | -22.0648 | -20.4 |
| `mvt_contiguous_w16` | 74.2442 | 59.1011 | -15.1431 | -20.4 |
| `bicg_sequential_contiguous_w4` | 70.7278 | 56.3020 | -14.4258 | -20.4 |
| `bicg_sequential_padded_w4` | 70.1378 | 55.8323 | -14.3055 | -20.4 |
| `mvt_padded_w4` | 68.7927 | 54.7615 | -14.0312 | -20.4 |
| `mvt_contiguous_w32` | 66.1731 | 52.6763 | -13.4968 | -20.4 |
| `bicg_pipeline_contiguous_w4` | 50.5738 | 40.2586 | -10.3152 | -20.4 |
| `bicg_sequential_contiguous_banks16` | 46.9159 | 37.3468 | -9.5691 | -20.4 |
| `bicg_sequential_padded_banks16` | 46.5383 | 37.0462 | -9.4921 | -20.4 |
| `bicg_sequential_contiguous_w8` | 46.4203 | 36.9523 | -9.4680 | -20.4 |
| `bicg_sequential_contiguous_banks64` | 46.2787 | 36.8396 | -9.4391 | -20.4 |
| `bicg_sequential_padded_w8` | 45.9719 | 36.5953 | -9.3766 | -20.4 |
| `bicg_sequential_padded_banks64` | 45.9719 | 36.5953 | -9.3766 | -20.4 |
| `bicg_pipeline_padded_w4` | 45.9011 | 36.5390 | -9.3621 | -20.4 |
| `mvt_padded_banks16` | 45.4999 | 36.2196 | -9.2803 | -20.4 |
| `mvt_padded_w8` | 44.4379 | 35.3742 | -9.0637 | -20.4 |
| `mvt_padded_banks64` | 44.3671 | 35.3179 | -9.0492 | -20.4 |
| `bicg_pipeline_contiguous_banks16` | 41.0868 | 32.7066 | -8.3802 | -20.4 |
| `bicg_pipeline_padded_banks16` | 39.7652 | 31.6546 | -8.1106 | -20.4 |
| `bicg_pipeline_contiguous_w8` | 36.8389 | 29.3251 | -7.5138 | -20.4 |
| `bicg_pipeline_contiguous_banks64` | 36.5557 | 29.0997 | -7.4560 | -20.4 |
| `bicg_pipeline_padded_w8` | 34.5261 | 27.4841 | -7.0420 | -20.4 |
| `bicg_sequential_padded_w16` | 34.3845 | 27.3714 | -7.0131 | -20.4 |
| `bicg_sequential_contiguous_w16` | 33.9833 | 27.0520 | -6.9313 | -20.4 |
| `mvt_padded_w16` | 33.4642 | 26.6387 | -6.8255 | -20.4 |
| `mvt_padded_w32` | 32.4730 | 25.8497 | -6.6233 | -20.4 |
| `bicg_pipeline_padded_banks64` | 32.1898 | 25.6243 | -6.5655 | -20.4 |
| `bicg_sequential_padded_w32` | 30.9862 | 24.6662 | -6.3200 | -20.4 |
| `bicg_sequential_contiguous_w32` | 30.8682 | 24.5722 | -6.2960 | -20.4 |
| `bicg_pipeline_padded_w16` | 28.8386 | 22.9566 | -5.8820 | -20.4 |
| `bicg_pipeline_contiguous_w16` | 28.4847 | 22.6748 | -5.8099 | -20.4 |
| `bicg_pipeline_padded_w32` | 26.1483 | 20.8150 | -5.3333 | -20.4 |
| `bicg_pipeline_contiguous_w32` | 25.9359 | 20.6459 | -5.2900 | -20.4 |

no status, cycles, est_cycles or non-energy column moved
