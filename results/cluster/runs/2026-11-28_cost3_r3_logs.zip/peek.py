import json, sys
sys.path.insert(0, "arc")
import arc
z = "sim/runs/cluster/nangate45/mvt_column_cg.zip"
c = json.loads(arc.read(z, "pwr/check.json"))
print(c["status"], c.get("vcd_bytes"), c["seconds"])
for w in c["windows"]:
    print({k: w[k] for k in ("mark", "kind", "label", "cycles", "t0_ps", "t1_ps", "cut_t0", "cut_t1")})
print(sorted(n for n in arc.names(z) if n.startswith(("pwr/", "pt/")))[:40])
