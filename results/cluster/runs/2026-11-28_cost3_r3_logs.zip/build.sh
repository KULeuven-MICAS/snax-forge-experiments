set -e
git config --global --add safe.directory '*'
cd /users/micas/rantonio/no_backup/kul_main/snax-forge-cost3
pixi install -e default
pixi install -e ci
pixi run python -c 'import snax_forge; print(snax_forge.__file__)'
CCACHE_DISABLE= pixi run make -C gvsoc build
echo BUILD_RC=0
