git config --global --add safe.directory '*'
cd /users/micas/rantonio/no_backup/kul_main/snax-forge-cost3
echo "== test-estimate"; timeout 1800 pixi run test-estimate 2>&1 | tail -15; echo "RC_estimate=${PIPESTATUS[0]}"
echo "== test-char"; timeout 1800 pixi run test-char 2>&1 | tail -15; echo "RC_char=${PIPESTATUS[0]}"
echo "== test_energy"; timeout 1800 pixi run -e ci pytest -q tests/flow/test_energy.py 2>&1 | tail -15; echo "RC_energy=${PIPESTATUS[0]}"
echo "== test_energy gvsoc"; timeout 1800 pixi run -e ci pytest -q tests/flow/test_energy.py -m gvsoc 2>&1 | tail -15; echo "RC_energy_gvsoc=${PIPESTATUS[0]}"
