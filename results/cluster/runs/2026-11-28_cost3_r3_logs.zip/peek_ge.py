import json, sys
g = json.load(open(f"results/cluster/nangate45/ge/{sys.argv[1]}.json"))
print("top keys", sorted(g))
print("prices", json.dumps(g.get("prices"))[:900])
for w in g["windows"]:
    print(w["mark"], w["kind"], w.get("label"), w["cycles"], sorted(w))
w = [w for w in g["windows"] if w["kind"] == "run"][0]
print("counters", json.dumps(w["counters"])[:1500])
print("energy", json.dumps(w["energy"])[:800])
