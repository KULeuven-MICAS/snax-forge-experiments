from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
reps = [
("""def part1(p: dict, images: dict, args, pre: dict | None = None) -> dict:
    \"\"\"Part 1: the quiet netlist run, the windows, the SAIFs, packed under pwr/ of the point's zip. Returns the
    check.json it packed; part 2 reads the SAIFs from the zip, and main skips this when part1_current says so.\"\"\"
""", """def part1(p: dict, images: dict, args, pre: dict | None = None, sub: str = "pwr", keep: Path | None = None) -> dict:
    \"\"\"Part 1: the quiet netlist run, the windows, the SAIFs, packed under sub/ of the point's zip (pwr/; pwr_time/
    for --time-based, whose VCD cuts are kept in keep/). Returns the check.json it packed; part 2 reads the SAIFs from
    the zip, and main skips this when part1_current says so.\"\"\"
"""),
("""    pdir = work / "pwr"
    pdir.mkdir()
    print(f"cluster pwr {point} (part 1): snax_cluster""", """    pdir = work / sub
    pdir.mkdir()
    print(f"cluster pwr {point} (part 1{', time-based: the cuts kept' if keep else ''}): snax_cluster"""),
("""           "seconds": {}, "obs_marks": marks}
    try:
        t = time.monotonic()
        netlist, cfg, opts = build(work, steps, pre)""", """           "seconds": {}, "obs_marks": marks, "cuts_kept": keep is not None}
    try:
        t = time.monotonic()
        netlist, cfg, opts = build(work, steps, pre)"""),
("""        saif_jobs(vcd, wins, pdir, res)
        bad = [n for n, i in res["saif"].items() if i["status"] != "PASS"]""", """        saif_jobs(vcd, wins, pdir, res, keep=keep)
        bad = [n for n, i in res["saif"].items() if i["status"] != "PASS"]"""),
("""            res["failed_log"], res["failed_tail"] = f"pwr/{bad[0]}/vcd2saif.log", cl.tail(pdir / bad[0] / "vcd2saif.log")""",
 """            res["failed_log"], res["failed_tail"] = f"{sub}/{bad[0]}/vcd2saif.log", cl.tail(pdir / bad[0] / "vcd2saif.log")"""),
("""        try:
            pack(work, point, res)
        except Exception as e:  # noqa: BLE001
            print(f"  could not pack pwr/ of""", """        try:
            pack(work, point, res, sub)
        except Exception as e:  # noqa: BLE001
            print(f"  could not pack {sub}/ of"""),
("""def pack(work: Path, point: str, res: dict) -> None:
    \"\"\"Under pwr/ of sim/runs/cluster/nangate45/<point>.zip; the zip's other members (rtl/, gls/) kept.\"\"\"
    z = cl.RUN_ZIPS / f"{point}.zip"
    pdir = work / "pwr"
    new = {}
    for f in ("pwr.do", "vcd_add.do", "vsim_cmd.sh", "vsim.txt", "obs_log.txt", "windows.json"):
        if (pdir / f).is_file():
            new[f"pwr/{f}"] = (pdir / f).read_bytes()
    for d in sorted(x for x in pdir.iterdir() if x.is_dir()):
        for f in ("w.saif", "vcd2saif.log"):
            if (d / f).is_file():
                new[f"pwr/{d.name}/{f}"] = (d / f).read_bytes()
    if (work / "logs").is_dir():
        new.update({f"pwr/logs/{k}": v.read_bytes() for k, v in arc.files_of(work / "logs").items()})
    new["pwr/check.json"] = (json.dumps(res, indent=2) + "\\n").encode()
    old = {k: v for k, v in arc.read_all(z).items() if not k.startswith("pwr/")}
    arc.write(z, {**old, **new})
    res["zip"] = str(z.relative_to(ROOT))
    print(f"  packed {res['zip']} ({len(new)} members under pwr/)", flush=True)""",
 """def pack(work: Path, point: str, res: dict, sub: str = "pwr") -> None:
    \"\"\"Under sub/ (pwr/, or pwr_time/) of sim/runs/cluster/nangate45/<point>.zip; the zip's other members kept.\"\"\"
    z = cl.RUN_ZIPS / f"{point}.zip"
    pdir = work / sub
    new = {}
    for f in ("pwr.do", "vcd_add.do", "vsim_cmd.sh", "vsim.txt", "obs_log.txt", "windows.json"):
        if (pdir / f).is_file():
            new[f"{sub}/{f}"] = (pdir / f).read_bytes()
    for d in sorted(x for x in pdir.iterdir() if x.is_dir()):
        for f in ("w.saif", "vcd2saif.log"):
            if (d / f).is_file():
                new[f"{sub}/{d.name}/{f}"] = (d / f).read_bytes()
    if (work / "logs").is_dir():
        new.update({f"{sub}/logs/{k}": v.read_bytes() for k, v in arc.files_of(work / "logs").items()})
    new[f"{sub}/check.json"] = (json.dumps(res, indent=2) + "\\n").encode()
    old = {k: v for k, v in arc.read_all(z).items() if not k.startswith(f"{sub}/")}
    arc.write(z, {**old, **new})
    res["zip"] = str(z.relative_to(ROOT))
    print(f"  packed {res['zip']} ({len(new)} members under {sub}/)", flush=True)"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:200]
    s = s.replace(o, n)
f.write_text(s)
