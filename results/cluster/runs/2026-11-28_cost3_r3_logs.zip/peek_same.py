import json, sys
sys.path.insert(0, "arc")
import arc
for p in sys.argv[1:]:
    c = json.loads(arc.read(f"sim/runs/cluster/nangate45/{p}.zip", "rtl/check.json"))
    g = c.get("checks", {}).get("gvsoc", {})
    prov = json.loads(arc.read(f"rtl/cluster/{p}.zip", "provenance.json"))
    print(p, "csyn2 rtl same_quiet_elf:", g.get("same_quiet_elf"), "q", str(g.get("quiet_elf_sha256"))[:16],
          "bundle", prov["quiet_elf_sha256"][:16], "bundle commit", prov["snax_forge_commit"][:10], "rtl run commit", c["snax_forge_commit"][:10])
