from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
o = """snax_cluster (--again reruns it). The steps and checks are in cluster/README.md, "pwr".
"""
n = """snax_cluster (--again reruns it). --time-based: part 1 into pwr_time/ keeping each window's VCD cut, PT time-based
on the cuts into pt_time/ and power_reports_time/ (main_time; --recheck: recheck_time). The steps and checks are in
cluster/README.md, "pwr" and "pwr --time-based".
"""
assert s.count(o) == 1
f.write_text(s.replace(o, n))
