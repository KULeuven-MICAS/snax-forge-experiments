import csv, sys
P = ("datapath", "control", "streamers", "crossbar", "memory", "dma")
for s, ids in (("forms", ["mvt_column", "gesummv_literal", "mvt_dma_copy", "atax_read_once"]),
               ("limits", ["mvt_contiguous_w8", "bicg_sequential_padded_w32", "bicg_pipeline_contiguous_w8"])):
    b = {r["id"]: r for r in csv.DictReader(open(f"tmp/cost3-r3/paper_before/{s}.csv"))}
    a = {r["id"]: r for r in csv.DictReader(open(f"snax-forge-cost3/paper/data/{s}.csv"))}
    for i in ids:
        print(f"| `{i}` | {a[i]['cycles']} | " + " | ".join(f"{float(b[i][f'dynamic_{p}_nj']):.2f} / {float(a[i][f'dynamic_{p}_nj']):.2f}" for p in P)
              + f" | {float(b[i]['dynamic_nj']):.2f} / {float(a[i]['dynamic_nj']):.2f} |")
