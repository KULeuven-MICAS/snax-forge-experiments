### Per window kind

| point | kind | windows | reads | writes | counted nJ | PT nJ | PT / counted |
|---|---|---:|---:|---:|---:|---:|---:|
| `atax_column_shared_movers_cg` | dma_in | 2 | 0 | 520 | 3.356 | 1.978 | 0.589 |
| `atax_column_shared_movers_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_column_shared_movers_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_column_shared_movers_cg` | run | 2 | 1792 | 64 | 6.480 | 6.338 | 0.978 |
| `atax_column_shared_movers_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.110 | 1.011 |
| `atax_dma_copy_cg` | dma_in | 2 | 0 | 520 | 3.356 | 1.978 | 0.589 |
| `atax_dma_copy_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_dma_copy_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_dma_copy_cg` | run | 2 | 3584 | 64 | 12.547 | 12.431 | 0.991 |
| `atax_dma_copy_cg` | dma_copy | 1 | 32768 | 32768 | 322.407 | 241.851 | 0.750 |
| `atax_dma_copy_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.110 | 1.011 |
| `atax_read_once_cg` | dma_in | 2 | 0 | 520 | 3.356 | 2.003 | 0.597 |
| `atax_read_once_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_read_once_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `atax_read_once_cg` | run | 1 | 1024 | 32 | 3.673 | 3.603 | 0.981 |
| `atax_read_once_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.109 | 1.011 |
| `bicg_pipeline_contiguous_w8_cg` | run | 1 | 12928 | 4352 | 71.854 | 63.535 | 0.884 |
| `bicg_read_once_cg` | dma_in | 3 | 0 | 528 | 3.407 | 2.002 | 0.588 |
| `bicg_read_once_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_read_once_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_read_once_cg` | run | 1 | 1032 | 64 | 3.907 | 3.745 | 0.959 |
| `bicg_read_once_cg` | dma_out | 2 | 64 | 0 | 0.217 | 0.219 | 1.011 |
| `bicg_sequential_contiguous_w8_cg` | dma_in | 3 | 0 | 4224 | 27.260 | 17.227 | 0.632 |
| `bicg_sequential_contiguous_w8_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_sequential_contiguous_w8_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_sequential_contiguous_w8_cg` | run | 2 | 12800 | 128 | 44.161 | 44.377 | 1.005 |
| `bicg_sequential_contiguous_w8_cg` | dma_out | 2 | 128 | 0 | 0.433 | 0.438 | 1.011 |
| `bicg_two_pass_cg` | dma_in | 3 | 0 | 528 | 3.407 | 2.022 | 0.593 |
| `bicg_two_pass_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_two_pass_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `bicg_two_pass_cg` | run | 2 | 1600 | 64 | 5.830 | 5.684 | 0.975 |
| `bicg_two_pass_cg` | dma_out | 2 | 64 | 0 | 0.217 | 0.219 | 1.011 |
| `bicg_two_pass_pipeline_cg` | run | 1 | 1664 | 592 | 9.454 | 7.836 | 0.829 |
| `dot3_w16_cg` | dma_in | 2 | 0 | 4096 | 26.434 | 17.071 | 0.646 |
| `dot3_w16_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w16_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w16_cg` | run | 1 | 4096 | 1 | 13.874 | 14.649 | 1.056 |
| `dot3_w16_cg` | dma_out | 1 | 8 | 0 | 0.027 | 0.028 | 1.046 |
| `dot3_w2_cg` | dma_in | 2 | 0 | 4096 | 26.434 | 17.071 | 0.646 |
| `dot3_w2_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w2_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w2_cg` | run | 1 | 4096 | 1 | 13.874 | 14.647 | 1.056 |
| `dot3_w2_cg` | dma_out | 1 | 8 | 0 | 0.027 | 0.028 | 1.046 |
| `dot3_w32_cg` | dma_in | 2 | 0 | 4096 | 26.434 | 17.071 | 0.646 |
| `dot3_w32_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w32_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w32_cg` | run | 1 | 4096 | 1 | 13.874 | 14.648 | 1.056 |
| `dot3_w32_cg` | dma_out | 1 | 8 | 0 | 0.027 | 0.028 | 1.046 |
| `dot3_w4_cg` | dma_in | 2 | 0 | 4096 | 26.434 | 17.071 | 0.646 |
| `dot3_w4_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w4_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w4_cg` | run | 1 | 4096 | 1 | 13.874 | 14.647 | 1.056 |
| `dot3_w4_cg` | dma_out | 1 | 8 | 0 | 0.027 | 0.028 | 1.046 |
| `dot3_w8_cg` | dma_in | 2 | 0 | 4096 | 26.434 | 17.071 | 0.646 |
| `dot3_w8_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w8_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `dot3_w8_cg` | run | 1 | 4096 | 1 | 13.874 | 14.648 | 1.056 |
| `dot3_w8_cg` | dma_out | 1 | 8 | 0 | 0.027 | 0.028 | 1.046 |
| `gesummv_factor_out_cg` | dma_in | 3 | 0 | 1032 | 6.660 | 3.934 | 0.591 |
| `gesummv_factor_out_cg` | streamer_config | 3 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_factor_out_cg` | acc_config | 3 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_factor_out_cg` | run | 3 | 2112 | 96 | 7.770 | 7.543 | 0.971 |
| `gesummv_factor_out_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.110 | 1.011 |
| `gesummv_literal_cg` | dma_in | 3 | 0 | 1032 | 6.660 | 3.962 | 0.595 |
| `gesummv_literal_cg` | streamer_config | 5 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_literal_cg` | acc_config | 5 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_literal_cg` | run | 5 | 6208 | 4192 | 48.071 | 37.290 | 0.776 |
| `gesummv_literal_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.109 | 1.011 |
| `gesummv_x_read_once_cg` | dma_in | 3 | 0 | 1032 | 6.660 | 3.990 | 0.599 |
| `gesummv_x_read_once_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_x_read_once_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `gesummv_x_read_once_cg` | run | 2 | 1600 | 96 | 6.036 | 5.815 | 0.963 |
| `gesummv_x_read_once_cg` | dma_out | 1 | 32 | 0 | 0.108 | 0.110 | 1.011 |
| `mvt_column_cg` | dma_in | 5 | 0 | 592 | 3.821 | 2.226 | 0.583 |
| `mvt_column_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_column_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_column_cg` | run | 2 | 1664 | 64 | 6.047 | 5.904 | 0.976 |
| `mvt_column_cg` | dma_out | 2 | 64 | 0 | 0.217 | 0.219 | 1.011 |
| `mvt_column_pipeline_cg` | run | 1 | 1728 | 656 | 10.084 | 8.290 | 0.822 |
| `mvt_contiguous_w8_cg` | dma_in | 5 | 0 | 4352 | 28.086 | 17.633 | 0.628 |
| `mvt_contiguous_w8_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_contiguous_w8_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_contiguous_w8_cg` | run | 2 | 16512 | 128 | 56.728 | 57.043 | 1.006 |
| `mvt_contiguous_w8_cg` | dma_out | 2 | 128 | 0 | 0.433 | 0.438 | 1.011 |
| `mvt_dma_copy_cg` | dma_in | 5 | 0 | 592 | 3.821 | 2.231 | 0.584 |
| `mvt_dma_copy_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_dma_copy_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_dma_copy_cg` | run | 2 | 2112 | 64 | 7.563 | 7.428 | 0.982 |
| `mvt_dma_copy_cg` | dma_out | 2 | 64 | 0 | 0.217 | 0.219 | 1.011 |
| `mvt_dma_copy_cg` | dma_copy | 1 | 32768 | 32768 | 322.407 | 241.818 | 0.750 |
| `mvt_padded_w8_cg` | dma_in | 5 | 0 | 4416 | 28.499 | 17.880 | 0.627 |
| `mvt_padded_w8_cg` | streamer_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_padded_w8_cg` | acc_config | 2 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_padded_w8_cg` | run | 2 | 16512 | 128 | 56.728 | 57.121 | 1.007 |
| `mvt_padded_w8_cg` | dma_out | 2 | 128 | 0 | 0.433 | 0.438 | 1.011 |
| `mvt_read_once_cg` | dma_in | 5 | 0 | 592 | 3.821 | 2.216 | 0.580 |
| `mvt_read_once_cg` | streamer_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_read_once_cg` | acc_config | 1 | 0 | 0 | 0.000 | 0.000 | nan |
| `mvt_read_once_cg` | run | 1 | 1096 | 64 | 4.124 | 3.966 | 0.962 |
| `mvt_read_once_cg` | dma_out | 2 | 66 | 0 | 0.223 | 0.226 | 1.011 |

### Against SNAX-GVSoC's bank counters (reads + writes)

| point | SAIF reads + writes | SNAX-GVSoC reads + writes | diff | % | windows beyond 1 % |
|---|---:|---:|---:|---:|---|
| `atax_column_shared_movers_cg` | 2408 | 2408 | +0 | +0.00 | none |
| `atax_dma_copy_cg` | 69736 | 69736 | +0 | +0.00 | none |
| `atax_read_once_cg` | 1608 | 1608 | +0 | +0.00 | none |
| `bicg_pipeline_contiguous_w8_cg` | 17280 | 17280 | +0 | +0.00 | none |
| `bicg_read_once_cg` | 1688 | 1688 | +0 | +0.00 | none |
| `bicg_sequential_contiguous_w8_cg` | 17280 | 17280 | +0 | +0.00 | none |
| `bicg_two_pass_cg` | 2256 | 2256 | +0 | +0.00 | none |
| `bicg_two_pass_pipeline_cg` | 2256 | 2256 | +0 | +0.00 | none |
| `dot3_w16_cg` | 8201 | 8201 | +0 | +0.00 | none |
| `dot3_w2_cg` | 8201 | 8201 | +0 | +0.00 | none |
| `dot3_w32_cg` | 8201 | 8201 | +0 | +0.00 | none |
| `dot3_w4_cg` | 8201 | 8201 | +0 | +0.00 | none |
| `dot3_w8_cg` | 8201 | 8201 | +0 | +0.00 | none |
| `gesummv_factor_out_cg` | 3272 | 3272 | +0 | +0.00 | none |
| `gesummv_literal_cg` | 11464 | 11464 | +0 | +0.00 | none |
| `gesummv_x_read_once_cg` | 2760 | 2760 | +0 | +0.00 | none |
| `mvt_column_cg` | 2384 | 2384 | +0 | +0.00 | none |
| `mvt_column_pipeline_cg` | 2384 | 2384 | +0 | +0.00 | none |
| `mvt_contiguous_w8_cg` | 21120 | 21120 | +0 | +0.00 | none |
| `mvt_dma_copy_cg` | 68368 | 68368 | +0 | +0.00 | none |
| `mvt_padded_w8_cg` | 21184 | 21184 | +0 | +0.00 | none |
| `mvt_read_once_cg` | 1818 | 1816 | +2 | +0.11 | 10_dma_out 34 / 32 (+6.2 %) |

1 windows beyond 1 %; SNAX-GVSoC runs read: dot3_w16_cg ge1/dot3_w16_cg.json, dot3_w2_cg ge1/dot3_w2_cg.json, dot3_w32_cg ge1/dot3_w32_cg.json, dot3_w4_cg ge1/dot3_w4_cg.json, dot3_w8_cg ge1/dot3_w8_cg.json
