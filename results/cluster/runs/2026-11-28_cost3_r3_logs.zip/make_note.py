"""Writes results/cluster/runs/2026-11-28_cost3_r3.md from the round's outputs in this folder (tables spliced in)."""

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1])
QUOTA_END = sys.argv[2]


def text(name: str) -> str:
    return (HERE / name).read_text()


def block(src: str, start: str, stop_blank: bool = True) -> str:
    """The lines from the one starting with `start` to the next blank line (a table)."""
    lines = src.splitlines()
    i = next(k for k, ln in enumerate(lines) if ln.startswith(start))
    out = []
    for ln in lines[i:]:
        if stop_blank and not ln.strip():
            break
        out.append(ln)
    return "\n".join(out)


def tables_after(src: str, heading: str) -> str:
    """The first table after a heading line."""
    lines = src.splitlines()
    i = next(k for k, ln in enumerate(lines) if ln.startswith(heading))
    j = next(k for k in range(i + 1, len(lines)) if lines[k].startswith("|"))
    return block("\n".join(lines[j:]), "|")


paper = text("paper_cmp.md")
sets = {}
for s in ("forms", "limits"):
    part = paper.split(f"### {s}.csv")[1].split("### ")[0]
    rows = re.sub(r"\{.(\w+).: (\d+)\}", r"\2 \1", re.search(r"- rows: .*", part).group(0))
    moved = re.search(r"- energy columns that moved: .*", part).group(0)
    out = [rows, moved, ""]
    for c in ("static_nj", "dynamic_nj"):
        line = next(ln for ln in part.splitlines() if ln.startswith(f"`{c}`"))
        out += [line, "", tables_after(part, f"`{c}`"), ""]
    idle = next(ln for ln in part.splitlines() if ln.startswith("`idle_nj`"))
    out += [idle + ". Every row fell by 20.4 % (18.79 / 23.6)."]
    sets[s] = "\n".join(out)

ge = text("ge_cmp17.md")
ge_table = block(ge, "| point | windows")
abl = text("ablation.md")
abl_tables = "\n\n".join(block(abl, h) for h in ("| design", "| pair, change %", "| kernel"))
bc = text("bank_counts.out")
bc_table = block(bc, "| point | reads")
pivot = text("bank_pivot.md").strip()
cmpg = text("bank_cmp.md")
gv_table = block(cmpg, "| point | SAIF reads")
tc = text("time_cmp.md")
tc_win = tables_after(tc, "### Per window: the top's")
tc_grp = tables_after(tc, "### Per group over the span")
tc_bank = tables_after(tc, "### The banks:")
ptg = text("pt_groups.md").strip()

note = f"""# COST3 R3, 27–28 Nov 2026: the energy runs with the new terms, the banks counted, one time-based cross-check

Claude Code on micas-lapserv1 (32 cores), snax-forge-experiments on `ry/cost3` from R2b's `7a0a6a68`, snax-forge in a worktree `../snax-forge-cost3` on `ry/cost3` from R2's `45b5d018`, snax_cluster on `main` `baf87858`. SNAX-GVSoC's energy runs and snax-forge's `paper/` rows priced again with D203–D205, the TCDM banks counted from every point's SAIFs (X114), and one point's PT in time-based mode against averaged PT and the counts. No DC. Raw data for Ryan's read.

**Result.** The `paper/` rows keep every status and cycle count; only energy columns moved (snax-forge `14e8f940`, tag `cost3-r3`). The 17 tier A energy runs equal CSYN2's window for window, now priced with `r_strm`, the floor and `e_l2`; the five dot3 points' committed runs turned out to be GE1's, of an older program, so the step stopped and, on Ryan's word, they stay as dot3's runs in `ge/ge1/` and the new dot3 runs were dropped (X115). `bank-counts` passed on all 22 points; its counts equal SNAX-GVSoC's bank counters to the access on 21, `mvt_read_once_cg` +2 in one window. Time-based PT on `mvt_column_cg` gives the banks at 1.0046 of the counts (averaged 0.828) and the logic at 0.750 of averaged, all of it internal power on the clock network and registers (PITFALLS PT10). `model_fit.json` is byte-equal; the ablation's last step and the live runs agree on all 17 designs (0.91–1.08 of the netlist).

## Host, licences, quota

- Host micas-lapserv1, `nproc` 32. Load 24–29 at the start (another user's `VDitTop` jobs, about 22 cores), 42–45 during steps 5 and 6.
- Licences before step 6 (`lmutil lmstat`): PrimeTime 20 of 20 free, PrimePower 30 of 30, Design-Compiler 10 of 10, msimhdlsim 63 of 75 (the 12 in use not ours). No Questa, PT or DC process of Ryan's on the host (`ps`); one Questa and one PT session this round, nothing else.
- PT threads: `--cores 16` lowered to 4 by `pt_threads` (load 45.5 on 32 cores).
- Quota (`quota -v`, users/sli): 1,328,764 files at the start, {QUOTA_END} at the end (soft 1,600,000); most of the rise is the worktree's pixi environments and its SNAX-GVSoC build.
- Tools: PrimeTime W-2024.09-SP5, Questa 2022.4; images `snax-forge:main` `c8abd925`, `snax` `c5db84ad7bce`.

## Step 1: pull and the worktree

- snax-forge: `git fetch origin`; `git worktree add ../snax-forge-cost3 ry/cost3` at `45b5d018` (`cost3-r2`), `git submodule update --init --recursive` (snax-gvsoc `554a3156`), clean. Its own pixi environments (`default`, `ci`; the editable install points at the worktree) and SNAX-GVSoC built there in the image (`make -C gvsoc build`, exit 0). The main checkout (E2E1's `ry/e2e1-blk`) was not touched.
- snax-forge-experiments: at first on E2E1's `ry/e2e1-blk` with uncommitted work, so the round stopped; Ryan stashed it (`E2E1 A5: 13 char points …`), then `ry/cost3` at `7a0a6a68` (`cost3-r2b`), clean. Neither tag exists locally or on origin; the round went on from the commits.
- snax_cluster: `main` `baf87858` = origin/main, clean.

## Step 2: tests

- snax-forge-experiments `pixi run test`: exit 0, `test_lint` skipped (no Verilator on PATH). At the end, with this round's tests: exit 0 again.
- snax-forge worktree, in the image (home Scala caches mounted): `pixi run test-estimate` 162 passed (203 s); `test-char` 18 passed; `-e ci pytest -q tests/flow/test_energy.py` 15 passed; with `-m gvsoc` 5 passed, 10 deselected. Nothing to fix in R2's code.

## Step 3: the paper/ rows

In the image: `pixi run paper forms --run -j 8` (`paper/data/forms.csv: 21 points, 0 not ok`, 2 min 53 s) and `pixi run paper limits --run -j 8` (`36 points, 0 not ok`, 3 min 17 s; the W = 32 rows' table extrapolation notes as before). Compared row by row with the CSVs at `45b5d018`: header and order unchanged; no `status`, `cycles`, `est_cycles` or other non-energy column moved. Committed on snax-forge's `ry/cost3` as `14e8f940` (`COST3 R3: the paper rows with the new terms`), tagged `cost3-r3`, both pushed.

### forms.csv

{sets["forms"]}

### limits.csv

{sets["limits"]}

### A row's dynamic energy is the whole energy run

`paper/run.py` takes a row's `dynamic_<part>_nj` from the energy run's `total`, every window (boot, the program, the check), while `cycles` and the background lines are the program window. Before D205 boot and check cost the design almost nothing; with the floor they now pay it for thousands of cycles. Not changed this round (only the two CSVs may change in snax-forge); for Ryan's read:

| id | cycles boot / program / check | nJ boot / program / check | row's `dynamic_nj` |
|---|---|---|---:|
| `mvt_column` | 2763 / 1556 / 4682 | 23.48 / 47.92 / 39.79 | 111.20 |
| `atax_read_once` | 2628 / 820 / 2553 | 16.82 / 42.95 / 16.34 | 76.10 |
| `mvt_dma_copy` | 2774 / 12518 / 4709 | 17.08 / 759.49 / 29.00 | 805.57 |
| `bicg_sequential_padded_w32` | 6643 / 1336 / 9022 | 196.33 / 305.21 / 266.64 | 768.18 |

## Step 4: the energy runs of the cluster points

- `git mv` of the 22 committed `ge/<point>.json` to `ge/csyn2/`; then, after the stop below, the five dot3 files on to `ge/ge1/` (X115). `ge_check.csv` and `ge_energy_five.png` stay in `ge/`.
- `cluster ge POINT` (`cluster/cluster.py`: `ge`, `ge_run` around rtl's `gvsoc_energy`), its test `test_ge_run_alone`, `cluster/README.md` ("ge") and `docs/TOOL.md`.
- The 22 runs with `SNAX_FORGE=../snax-forge-cost3`, five lanes (one per kernel, so no two runs of a kernel compile into the cold DaCe cache at once), 518 s of flow in all; all PASS. The quiet ELF equals the bundle's on the 17 tier A points; on the five dot3 points it does not (their bundles are of `b29bf0c0`).

### The stop: the dot3 runs were GE1's

The prompt took the 22 committed files for CSYN2's. The 17 tier A ones are; the five dot3 ones were last committed by GE1 (`5ae355e7`, 17 Nov), made by snax-forge `04165576` from bundles of `b29bf0c0`, the program the dot3 power runs used. Today's runs differ, so step 4 stopped. On `dot3_w16_cg`, old → new cycles: boot 6270 → 6266, acc_config 14 → 3, run 169 → 161, dma_out 54 → 52, check 859 → 884 (the dma_in and streamer_config windows equal); every window's counters gain `copies` (all zero); on w16 and w2 the run window's per-bank, input and mover counters differ, the total bank accesses equal (4,097), `stall_in` 3 → 0. W = 4, 8 and 32: the same window changes, the counters only by `copies`. With the new dot3 files in `ge/`, `pixi run model-fit` failed (below). Ryan's decision (X115): GE1's five runs to `ge/ge1/`, the new dot3 runs deleted and not committed; `model_fit.py` reads a run from `ge/csyn2/`, `ge/ge1/`, then `ge/` (`GE_ORDER`); `ablation.py`'s `base_ge` is that, and its `run` column is `ge/<point>.json` only when it is not the base.

### The 17 tier A points

Every window's mark, kind, cycles and counters equal `ge/csyn2/<point>.json`'s; the prices carry `r_strm` 0.0847, `r_xbar` 0, `e_l2` 54.48 pJ and a floor per point (DMA 3.378 pJ a cycle; streamers 1.01–8.59, crossbar 1.77–5.27 by shape). The program window's six parts (nJ, the windows between boot and check), CSYN2's prices / the new:

{ge_table}

## Step 5: the banks counted

`pixi run bank-counts --md`: exit 0, all 22 points; every SAIF has the point's 32 bank instances, whole cycles everywhere, `we_i` never high without `req_i`. `bank_counts.json` is new.

{bc_table}

Per window kind (each kind's windows together; `dma_copy` the copies' windows):

{pivot}

Against SNAX-GVSoC: the SAIF's reads + writes over the program window and the energy run's bank counters over the same marks (for dot3 GE1's runs, the program their SAIFs are of):

{gv_table}

One window beyond 1 %: `mvt_read_once_cg` `10_dma_out`, 34 accesses at gate level against 32.

## Step 6: the time-based cross-check on mvt_column_cg

`cluster pwr POINT --time-based` (`cluster/power.py`: `main_time`, `time_site`, `part1(sub, keep)`, `part2(site, vcds)`; `sim/scripts/pt_power.tcl`: `PWR_ANALYSIS`, `read_vcd -strip_path tb_bin/i_dut/i_snax_forge_cluster -time {{t0 t1}}` per window, t0 and t1 in ns at the cuts' 10ps unit). Part 1 again (rtl-gen 82 s, vsim_preparation 44 s, the netlist build 81 s, the run 22 s, a 0.10 GB VCD, 13 cuts and SAIFs, every window's cycles equal to the quiet RTL run's), the cuts kept in `tmp/cluster_time/mvt_column_cg/` (638 MB); part 2 one PT session, 485 s on 4 threads. Every window 100 % annotated. `pwr_time/` and `pt_time/` of the run zip, `power_reports_time/mvt_column_cg.zip` (56 members, 0.9 MB); `pwr/`, `pt/`, `power_reports/mvt_column_cg.zip` and `power_pt.csv` unchanged. The SAIFs of the rerun give the same bank counts as `pwr/`'s on all 13 windows.

The first part 2 failed every window on `hierarchy_total` only: a time-based hierarchy row has peak power where averaged has the total (PITFALLS PT12), so `hier_top` read 5.25 W against `power.rpt`'s 13.18 mW. `hier_top` reads the time-based row's eighth number now, and `--recheck` did part 2's checks again from what it had packed, with no Questa and no PT: all 13 windows PASS (`rechecked` in both `pt_check.json`).

Per window, the top's dynamic energy (internal + switching), pJ a cycle:

{tc_win}

Per group of `groups.json` over the span (each window's groups by `report/cluster_energy.py`'s rules, a time-based row read by its own columns):

{tc_grp}

PT's own groups over the span, pJ a cycle (internal / switching):

{ptg}

The banks, nJ per window:

{tc_bank}

Where the modes differ by more than 5 %: every group but `tcdm_banks` in the run windows. The difference is the clock network's and the registers' internal power only (27.66 → 16.12 and 5.43 → 2.32 pJ a cycle); switching and combinational internal power are equal in both modes. That is PITFALLS PT10 (held flops' clock pins), so the logic stays averaged (X20 · X60 · X74). The macros go the other way: the banks 1.21 of averaged over the span, 1.69–1.88 in the `dma_in` windows, where averaged PT's independent `req_i` and `we_i` (PT7) are furthest off; the I-cache macros 1.20 (3.9 in the 3-cycle `5_acc_config`). Time-based and counted agree within 1 % over the span (1.0046) and on every window but the two `dma_out` (1.0107, 1.0106).

## Step 7: the chat's scripts

- `pixi run model-fit`: exit 0, `results/cluster/nangate45/model_fit.json` byte-equal (`git diff` empty), its runs read through `GE_ORDER`. Before X115, with today's dot3 runs in `ge/`, it failed (below).
- `pixi run ablation --md`: exit 0, `ablation.json` (17 designs), the banks counted on all 17 (`banks` `counted`):

{abl_tables}

The `run` column (today's energy runs, `ge/<point>.json`) equals the `copy` step on every design to two digits. Not run, as asked: `tier-check`, `cluster-breakdown`, `cluster-energy`, the initial findings' figures.

## Failures on the way

1. Step 1: snax-forge-experiments on E2E1's branch with work in it; stopped and reported; Ryan stashed it.
2. Step 3: the wrapper around the two paper runs exited 1 from its closing `tail`; both runs had exit 0 (`RC_forms=0`, `RC_limits=0`).
3. Step 4: the dot3 stop above. `pixi run model-fit` with today's dot3 runs in `ge/`, before X115:

```
  File ".../report/model_fit.py", line 103, in fit_l2
    return {{"e_l2_pj": sum(p["dma_above_floor_nj"] for p in pts.values()) * 1e3 / sum(p["beats"] for p in pts.values()),
ZeroDivisionError: float division by zero
```

   The new runs price the transfers, so no bank access is left beyond the priced ones (the beats); nothing was written.
4. Step 6: part 2's `hierarchy_total` on all 13 windows (`{{"power_rpt": 0.01317776, "hierarchy": 5.248917, "status": "FAIL"}}` in `6_run`), fixed in the parser and rechecked, above.
5. The session restarted during step 5; `bank-counts` kept running and finished (exit 0).

## Clean

`pixi run arc check`: `arc check: nothing left over`; the cuts were deleted at the end of step 6 (`tmp/cluster_time/` gone). snax_cluster clean after part 1. The round's consoles, comparison scripts and long tables (the per-window and per-group ratios of step 6, the per-kind bank rows, the paper runs' logs) are in [`2026-11-28_cost3_r3_logs.zip`](2026-11-28_cost3_r3_logs.zip).

## Committed

snax-forge `ry/cost3`: `14e8f940` (the two CSVs), tag `cost3-r3`. snax-forge-experiments `ry/cost3`: `cluster ge` and `cluster pwr --time-based` with their tests and `pt_power.tcl`'s time-based mode; `model_fit.py`'s `GE_ORDER` and `ablation.py`'s base, with tests; `ge/csyn2/` (17), `ge/ge1/` (5), the 17 new `ge/<point>.json`; `bank_counts.json`, `ablation.json`; `power_reports_time/mvt_column_cg.zip`; X114's cross-check, X115, PITFALLS PT10 and PT12, `cluster/README.md`, `docs/TOOL.md`; this note and its logs zip. Nothing under `sim/runs`, `syn/runs` or `rtl/`.
"""
OUT.write_text(note)
print(f"wrote {OUT} ({len(note.splitlines())} lines)")
