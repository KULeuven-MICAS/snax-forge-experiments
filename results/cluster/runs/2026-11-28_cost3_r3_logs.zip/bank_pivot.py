import json
bc = json.load(open("results/cluster/nangate45/bank_counts.json"))["points"]
kinds = []
agg = {}
for pt, v in bc.items():
    for n, w in v["windows"].items():
        k = n.split("_", 1)[1]
        if k not in kinds:
            kinds.append(k)
        a = agg.setdefault(pt, {}).setdefault(k, [0, 0, 0.0, 0.0])
        a[0] += w["reads"]; a[1] += w["writes"]; a[2] += w["counted_nj"]; a[3] += w["pt_nj"]
kinds = [k for k in kinds if any(agg[p].get(k, [0, 0, 0, 0])[2] > 0 for p in agg)]
print("| point | " + " | ".join(f"{k}: counted nJ, PT / counted" for k in kinds) + " |")
print("|---|" + "---:|" * len(kinds))
tot = {k: [0.0, 0.0] for k in kinds}
for pt in agg:
    cells = []
    for k in kinds:
        a = agg[pt].get(k)
        if not a or a[2] == 0:
            cells.append("–")
            continue
        tot[k][0] += a[2]; tot[k][1] += a[3]
        cells.append(f"{a[2]:.2f}, {a[3] / a[2]:.3f}")
    print(f"| `{pt}` | " + " | ".join(cells) + " |")
print("| all 22 | " + " | ".join(f"{t[0]:.2f}, {t[1] / t[0]:.3f}" if t[0] else "–" for t in tot.values()) + " |")
