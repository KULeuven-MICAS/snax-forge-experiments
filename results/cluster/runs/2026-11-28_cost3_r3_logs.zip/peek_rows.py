import sys
sys.path.insert(0, "arc")
import arc
h = arc.read_text("results/cluster/nangate45/power_reports_time/mvt_column_cg.zip", "1_dma_in/power_hierarchy.rpt").splitlines()
i = next(k for k, l in enumerate(h) if l.startswith("-----"))
for l in h[i + 1:i + 5]:
    print(repr(l))
