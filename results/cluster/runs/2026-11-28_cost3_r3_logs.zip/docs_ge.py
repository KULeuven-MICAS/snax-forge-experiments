from pathlib import Path
f = Path("docs/TOOL.md")
s = f.read_text()
o = "| `cluster pwr POINT [--cores 16] [--again] [--allow-branch]` | one VCD, a SAIF per section, one PT session (X20 · X60 · X74) |\n"
n = o + "| `cluster ge POINT [--allow-branch]` | step 1's energy run on SNAX-GVSoC alone (`flow --energy` in snax-forge's image from `SNAX_FORGE`), into `ge/<point>.json`; for a new price on the same program |\n"
assert s.count(o) == 1
f.write_text(s.replace(o, n))
f = Path("cluster/README.md")
s = f.read_text()
o = "## The reports\n"
n = ("### ge\n\n"
     "`cluster ge POINT` runs step 1's energy run alone, for a point whose program is made again with new prices and nothing else: `flow --energy` in snax-forge's image from `SNAX_FORGE` (rtl's `gvsoc_energy`, the same command), its `energy.json` into `results/cluster/nangate45/ge/<point>.json`. Checks: snax_cluster and snax-forge as rtl's (clean, snax_cluster on origin/main unless `--allow-branch`); the run's quiet ELF against the bundle zip's `quiet_elf_sha256` (rtl/cluster/<point>.zip's provenance), printed as same or not, never a gate. Nothing else is run or kept: no bundle is made, the run zip is not touched, the work folder `tmp/cluster/<point>/` is deleted; the flow's folder stays in snax-forge's `out/flow/`. One line at the end: PASS with the file, the quiet ELF's verdict and the windows (mark, kind, cycles), or FAIL with at most 30 lines of the flow's log.\n\n"
     + o)
assert s.count(o) == 1
f.write_text(s.replace(o, n, 1))
