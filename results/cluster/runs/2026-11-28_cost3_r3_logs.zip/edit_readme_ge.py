from pathlib import Path
f = Path("cluster/README.md")
s = f.read_text()
o = "FAIL with at most 30 lines of the flow's log.\n\n## The reports\n"
n = ("FAIL with at most 30 lines of the flow's log.\n\n"
     "`ge/csyn2/` holds CSYN2's runs (tier A), `ge/ge1/` GE1's dot3 runs (the ones their power reports match), and `ge/` the runs with the current prices; `model-fit` and `ablation` read a point's run in that order (`model_fit.py`'s `GE_ORDER`).\n\n"
     "## The reports\n")
assert s.count(o) == 1
f.write_text(s.replace(o, n))
