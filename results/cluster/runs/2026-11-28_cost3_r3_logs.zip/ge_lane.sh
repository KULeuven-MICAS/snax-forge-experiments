#!/bin/bash
# one lane: the given points one after another, each with its own log and rc
cd /users/micas/rantonio/no_backup/kul_main/snax-forge-experiments
export SNAX_FORGE=/users/micas/rantonio/no_backup/kul_main/snax-forge-cost3
for p in "$@"; do
  timeout 1800 pixi run cluster ge "$p" > /users/micas/rantonio/no_backup/kul_main/tmp/cost3-r3/ge/$p.log 2>&1
  rc=$?
  echo "$p rc=$rc $(tail -1 /users/micas/rantonio/no_backup/kul_main/tmp/cost3-r3/ge/$p.log | cut -c1-200)"
done
