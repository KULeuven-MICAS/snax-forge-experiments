from pathlib import Path
f = Path("docs/DECISIONS.md")
s = f.read_text()
o = """- **Why:** averaged PT takes `req_i` and `we_i` as independent (PITFALLS PT7) and puts the DMA's accesses 34–67 % under their price; the macro's Liberty model is CACTI's energy per access, so counts × prices is what time-based PT gives for it. Ryan, 27 Nov: counted on all 17 tier A points, with one time-based cross-check.
- **Where:** `report/bank_counts.py`; `results/cluster/runs/2026-11-27_cost3_r1.md`.
"""
n = """- **Why:** averaged PT takes `req_i` and `we_i` as independent (PITFALLS PT7) and puts the DMA's accesses 34–67 % under their price; the macro's Liberty model is CACTI's energy per access, so counts × prices is what time-based PT gives for it. Ryan, 27 Nov: counted on all 17 tier A points, with one time-based cross-check. The cross-check (COST3 R3, `mvt_column_cg`, `cluster pwr --time-based`): time-based PT's banks are 1.0046 of the counts over the program's 13 windows (1.0000 on every `dma_in`, within 1.1 % on every window), averaged PT's 0.828 (0.53–0.59 on `dma_in`); the counts equal SNAX-GVSoC's bank counters on 21 of 22 points.
- **Where:** `report/bank_counts.py`; `results/cluster/runs/2026-11-27_cost3_r1.md`, `2026-11-28_cost3_r3.md`.

### X115 — SNAX-GVSoC's runs by pricing: `ge/csyn2/`, `ge/ge1/`, `ge/`

- **Decided:** `ge/csyn2/` keeps CSYN2's energy runs of the 17 tier A points, `ge/ge1/` GE1's of the five `dot3_w*_cg` points (snax-forge `0416557`, bundles `b29bf0c`: the program their power runs used), and `ge/` the runs with the current prices (`cluster ge`, tier A only). `model-fit` and `ablation` read a point's run in that order (`model_fit.py`'s `GE_ORDER`); `ablation`'s `run` column is `ge/<point>.json` when it is not that run.
- **Why:** today's dot3 programs are not the ones their netlists ran (window cycles, `stall_in`, a `copies` counter), so a new dot3 run would not match its power reports; the fits must read the runs as priced before the terms, which the new runs already include (Ryan, 28 Nov).
- **Where:** `report/model_fit.py`, `report/ablation.py`, `cluster/README.md` ("ge"); `results/cluster/runs/2026-11-28_cost3_r3.md`.
"""
assert s.count(o) == 1
s = s.replace(o, n)
s = s.replace("Next free number: **X115**.", "Next free number: **X116**.")
f.write_text(s)
f = Path("docs/PITFALLS.md")
s = f.read_text()
o = "- **PT10.** Time-based mode gives about half the clock-pin energy of held flops: averaged (X20 · X60 · X74).\n"
n = ("- **PT10.** Time-based mode gives about half the clock-pin energy of held flops: averaged (X20 · X60 · X74). On `mvt_column_cg` (COST3 R3) clock network internal 0.58 and register internal 0.43 of averaged, switching and combinational equal; the logic 0.75 in all, the macros 1.21 (PT7 gone).\n"
     "- **PT12.** A time-based hierarchy row is Int, Switch, Leak, Peak Power, Peak Time (`t0-t1`), Glitch, X-tran, Total, %: the averaged parsers take peak power as the total; `power.hier_top` reads the eighth number.\n")
assert s.count(o) == 1
f.write_text(s.replace(o, n))
f = Path("docs/TOOL.md")
s = f.read_text()
o = "| `cluster pwr POINT [--cores 16] [--again] [--allow-branch]` | one VCD, a SAIF per section, one PT session (X20 · X60 · X74) |\n"
n = ("| `cluster pwr POINT [--cores 16] [--again] [--allow-branch]` | one VCD, a SAIF per section, one PT session (X20 · X60 · X74) |\n"
     "| `cluster pwr POINT --time-based [--recheck]` | part 1 again into `pwr_time/` keeping each window's VCD cut, PT time-based on the cuts into `pt_time/` and `power_reports_time/<point>.zip`; the averaged results untouched; `--recheck` redoes part 2's checks from what it packed, no tool run |\n")
assert s.count(o) == 1
f.write_text(s.replace(o, n))
f = Path("cluster/README.md")
s = f.read_text()
o = "## The reports\n"
n = ("### pwr --time-based\n\n"
     "`cluster pwr POINT --time-based` is a cross-check of part 2's averaged mode (PITFALLS PT7, PT10), not a replacement: part 1 runs again as above into `pwr_time/` of the run zip, each window's VCD cut moved to `tmp/cluster_time/<point>/` after its vcd2saif instead of deleted; then one PT session with `PWR_ANALYSIS=time_based` (`set power_analysis_mode time_based`), per window `read_vcd -strip_path tb_bin/i_dut/i_snax_forge_cluster -time {t0 t1}` on its cut, t0 and t1 the window's bounds in ns at the cuts' 10ps unit (PITFALLS PT4), and the same reports and checks (the hierarchy's total from its eighth column, PT12). Results: `pt_time/` of the run zip and `results/cluster/nangate45/power_reports_time/<point>.zip`; no `power_pt.csv` row, and `pwr/`, `pt/` and `power_reports/` stay as they are. The cuts are deleted at the end, also on a failure. `--recheck` redoes part 2's checks from the report zip, `pt_time/`'s not-annotated lists and `pwr_time/`'s SAIFs, with no Questa and no PT, and rewrites both `pt_check.json` (`rechecked` records it).\n\n"
     + o)
assert s.count(o) == 1
f.write_text(s.replace(o, n, 1))
