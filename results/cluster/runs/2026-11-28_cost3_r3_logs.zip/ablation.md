✨ Pixi task (ablation): python report/ablation.py --md
wrote results/cluster/nangate45/ablation.json: 17 designs
SNAX-GVSoC over the netlist, the six parts' dynamic energy over the program window:

| design | netlist nJ | committed | refusals | floor | transfers | copy | run |
|---|---|---|---|---|---|---|---|
| `mvt_column` | 46.2 | 0.57 | 0.57 | 0.85 | 1.04 | 1.04 | 1.04 |
| `mvt_read_once` | 42.3 | 0.64 | 0.64 | 0.83 | 1.03 | 1.03 | 1.03 |
| `bicg_two_pass` | 42.3 | 0.61 | 0.60 | 0.86 | 1.04 | 1.04 | 1.04 |
| `bicg_read_once` | 38.1 | 0.69 | 0.69 | 0.85 | 1.06 | 1.06 | 1.06 |
| `atax_read_once` | 39.9 | 0.76 | 0.76 | 0.90 | 1.08 | 1.08 | 1.08 |
| `atax_column_shared_movers` | 51.8 | 0.60 | 0.60 | 0.77 | 0.91 | 0.91 | 0.91 |
| `gesummv_x_read_once` | 48.9 | 0.57 | 0.57 | 0.76 | 1.05 | 1.05 | 1.05 |
| `gesummv_factor_out` | 59.6 | 0.54 | 0.54 | 0.79 | 1.02 | 1.02 | 1.02 |
| `gesummv_literal` | 192.6 | 0.66 | 0.65 | 0.84 | 0.91 | 0.91 | 0.91 |
| `mvt_dma_copy` | 749.2 | 1.07 | 1.07 | 1.18 | 1.19 | 1.01 | 1.01 |
| `atax_dma_copy` | 788.7 | 1.04 | 1.04 | 1.15 | 1.16 | 1.00 | 1.00 |
| `mvt_contiguous_w8` | 356.1 | 1.00 | 0.70 | 0.82 | 0.98 | 0.98 | 0.98 |
| `mvt_padded_w8` | 320.1 | 0.76 | 0.75 | 0.81 | 1.00 | 1.00 | 1.00 |
| `bicg_sequential_contiguous_w8` | 297.7 | 0.71 | 0.71 | 0.78 | 0.98 | 0.98 | 0.98 |
| `mvt_column_pipeline` | 40.8 | 0.65 | 0.64 | 0.83 | 1.04 | 1.04 | 1.04 |
| `bicg_two_pass_pipeline` | 38.0 | 0.68 | 0.67 | 0.84 | 1.04 | 1.04 | 1.04 |
| `bicg_pipeline_contiguous_w8` | 301.7 | 0.80 | 0.70 | 0.76 | 0.95 | 0.95 | 0.95 |
| range | | 0.54–1.07 | 0.54–1.07 | 0.76–1.18 | 0.91–1.19 | 0.91–1.08 |

| pair, change % | netlist | committed | refusals | floor | transfers | copy |
|---|---|---|---|---|---|---|
| mvt_contiguous_w8 -> mvt_padded_w8 | -10.1 | -31.6 | -3.1 | -10.8 | -8.7 | -8.7 |
| bicg_sequential_contiguous_w8 -> bicg_pipeline_contiguous_w8 | +1.3 | +14.4 | +0.9 | -1.1 | -0.9 | -0.9 |
| mvt_column -> mvt_column_pipeline | -11.7 | +1.2 | +0.1 | -13.9 | -11.4 | -11.4 |
| bicg_two_pass -> bicg_two_pass_pipeline | -10.1 | +1.2 | +0.1 | -12.1 | -10.0 | -10.0 |

| kernel | netlist top-1 | committed top-1, τ | refusals top-1, τ | floor top-1, τ | transfers top-1, τ | copy top-1, τ |
|---|---|---|---|---|---|---|
| atax | atax_read_once | atax_read_once, 1.00 | atax_read_once, 1.00 | atax_read_once, 1.00 | atax_read_once, 1.00 | atax_read_once, 1.00 |
| bicg | bicg_read_once, bicg_two_pass_pipeline | bicg_two_pass, 0.50 | bicg_two_pass, bicg_two_pass_pipeline, 0.50 | bicg_two_pass_pipeline, 0.70 | bicg_two_pass_pipeline, 0.80 | bicg_two_pass_pipeline, 0.80 |
| gesummv | gesummv_x_read_once | gesummv_x_read_once, 1.00 | gesummv_x_read_once, 1.00 | gesummv_x_read_once, 1.00 | gesummv_x_read_once, 1.00 | gesummv_x_read_once, 1.00 |
| mvt | mvt_column_pipeline | mvt_column, 0.73 | mvt_column, mvt_column_pipeline, 0.80 | mvt_column_pipeline, 1.00 | mvt_column_pipeline, 1.00 | mvt_column_pipeline, 1.00 |

