git config --global --add safe.directory '*'
cd /users/micas/rantonio/no_backup/kul_main/snax-forge-cost3
echo "== forms $(date +%T)"; timeout 5400 pixi run paper forms --run -j 8 > /users/micas/rantonio/no_backup/kul_main/tmp/cost3-r3/paper_forms.log 2>&1; echo "RC_forms=$? $(date +%T)"
echo "== limits $(date +%T)"; timeout 7200 pixi run paper limits --run -j 8 > /users/micas/rantonio/no_backup/kul_main/tmp/cost3-r3/paper_limits.log 2>&1; echo "RC_limits=$? $(date +%T)"
