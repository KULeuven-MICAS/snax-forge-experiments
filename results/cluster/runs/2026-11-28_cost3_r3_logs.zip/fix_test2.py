from pathlib import Path
f = Path("cluster/test_cluster.py")
s = f.read_text()
for o, n in (("""        old = cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS
        cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS = d / "forge", d / "ge", d / "rtl"
""", """        old = cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS, cl.ROOT
        cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS, cl.ROOT = d / "forge", d / "ge", d / "rtl", d
"""), ("""            cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS = old
""", """            cl.FORGE, cl.GE_DIR, cl.RTL_ZIPS, cl.ROOT = old
""")):
    assert s.count(o) == 1, o
    s = s.replace(o, n)
f.write_text(s)
