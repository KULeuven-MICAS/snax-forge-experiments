| PT group | averaged int / sw pJ a cycle | time-based int / sw | time / avg (int + sw) |
|---|---:|---:|---:|
| clock_network | 27.661 / 2.488 | 16.121 / 2.488 | 0.617 |
| register | 5.430 / 0.723 | 2.315 / 0.729 | 0.495 |
| combinational | 5.431 / 6.315 | 5.406 / 6.329 | 0.999 |
| black_box | 5.715 / 0.032 | 6.932 / 0.032 | 1.212 |
| memory | 0.000 / 0.000 | 0.000 / 0.000 | nan |
| all | 53.796 | 40.353 | 0.750 |
