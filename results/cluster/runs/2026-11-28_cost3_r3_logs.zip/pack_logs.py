import sys
from pathlib import Path
sys.path.insert(0, "arc")
import arc
src = Path("../tmp/cost3-r3").resolve()
z = Path("results/cluster/runs/2026-11-28_cost3_r3_logs.zip")
members = {rel: f.read_bytes() for rel, f in arc.files_of(src).items()}
arc.write(z, members)
back = arc.read_all(z)
assert back.keys() == members.keys() and all(back[k] == v for k, v in members.items()), "test read failed"
print(f"{z}: {len(members)} members, {z.stat().st_size / 1e3:.0f} kB, test read OK")
