from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
o = """    \"\"\"report_power -hierarchy's first row, the top: (internal, switching, leakage, total). A time-based report has
    no total column (peak power and time follow the leakage): its total is the sum of the three.\"\"\"
    timed = "Report : Time Based Power" in text
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if ln.startswith("-----"):
            m = re.match(rf"^(\\S+)\\s+({NUM})\\s+({NUM})\\s+({NUM})\\s+({NUM})", lines[i + 1])
            if m:
                v = tuple(float(x) for x in m.groups()[1:])
                return (*v[:3], sum(v[:3])) if timed else v
            break
"""
n = """    \"\"\"report_power -hierarchy's first row, the top: (internal, switching, leakage, total). A time-based report's
    row is internal, switching, leakage, peak power, peak time, glitch, X-transition, total, %.\"\"\"
    timed = "Report : Time Based Power" in text
    row = (rf"^(\\S+)\\s+({NUM})\\s+({NUM})\\s+({NUM})\\s+(?:{NUM}|N/A)\\s+\\S+\\s+{NUM}\\s+{NUM}\\s+({NUM})" if timed
           else rf"^(\\S+)\\s+({NUM})\\s+({NUM})\\s+({NUM})\\s+({NUM})")
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if ln.startswith("-----"):
            m = re.match(row, lines[i + 1])
            if m:
                return tuple(float(x) for x in m.groups()[1:])
            break
"""
assert s.count(o) == 1
f.write_text(s.replace(o, n))
f = Path("cluster/test_power.py")
s = f.read_text()
o = """snax_forge_cluster_wrapper            3.223882e-03              1.134443e-03              8.819431e-03              5.248917e+00              10640.00-10640.01                0.000000e+00
\"\"\""""
n = """snax_forge_cluster_wrapper            3.223882e-03              1.134443e-03              8.819431e-03              5.248917e+00              10640.00-10640.01                0.000000e+00              2.622217e-05              1.317776e-02              100.0
  i_cluster (snitch_cluster_48)       1.000000e-03              1.000000e-04              1.000000e-03              1.000000e+00              0.00-0.01                0.000000e+00              0.000000e+00              2.100000e-03              15.9
\"\"\""""
assert s.count(o) == 1
s = s.replace(o, n)
s = s.replace("    # time-based: no total column, peak power fourth; the total is internal + switching + leakage\n",
              "    # time-based: peak power, peak time, glitch and X-transition before the total\n")
s = s.replace("""    assert abs(top[3] - 1.317776e-02) <= power.HIER_TOL * 1.317776e-02, top
""", """    assert top[3] == 1.317776e-02 and abs(sum(top[:3]) - top[3]) <= power.HIER_TOL * top[3], top
""")
f.write_text(s)
f = Path("../tmp/cost3-r3/time_cmp.py")
s = f.read_text()
o = """_ROW_T = re.compile(rf"^( *)(\\S+)(?: \\((\\S+)\\))?\\s+{_N}\\s+{_N}\\s+{_N}\\s+(?:{_N}|N/A)\\s+\\S+\\s+\\S+\\s*$")"""
n = """_ROW_T = re.compile(rf"^( *)(\\S+)(?: \\((\\S+)\\))?\\s+{_N}\\s+{_N}\\s+{_N}\\s+(?:{_N}|N/A)\\s+\\S+\\s+{_N}\\s+{_N}\\s+{_N}"
                    rf"\\s+(?:{_N}|N/A)\\s*$")"""
assert s.count(o) == 1, "tcmp"
s = s.replace(o, n)
s = s.replace("(Int, Switch, Leak, Peak Power, Peak Time,\n    Glitch; no total)", "(Int, Switch, Leak, Peak Power, Peak Time,\n    Glitch, X-tran, Total, %)")
f.write_text(s)
