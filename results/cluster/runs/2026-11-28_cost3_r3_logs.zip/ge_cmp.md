| point | windows | cycles | datapath before / after | control before / after | streamers before / after | crossbar before / after | memory before / after | dma before / after | total before / after | change |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `atax_column_shared_movers_cg` | 9 | 1409 | 14.536 / 14.536 | 0.560 / 0.560 | 6.133 / 7.699 | 3.410 / 6.043 | 6.480 / 9.944 | 0.000 / 8.519 | 31.119 / 47.301 | +52.0 % |
| `atax_dma_copy_cg` | 10 | 12376 | 15.305 / 15.305 | 0.755 / 0.755 | 11.449 / 34.635 | 20.343 / 32.132 | 334.954 / 338.418 | 435.828 / 365.396 | 818.634 / 786.641 | -3.9 % |
| `atax_read_once_cg` | 6 | 820 | 20.617 / 20.617 | 0.794 / 0.794 | 3.467 / 4.395 | 1.932 / 3.475 | 3.673 / 7.137 | 0.000 / 6.529 | 30.483 / 42.947 | +40.9 % |
| `bicg_pipeline_contiguous_w8_cg` | 1 | 1561 | 104.876 / 104.876 | 0.874 / 0.874 | 55.617 / 46.213 | 35.898 / 29.180 | 44.161 / 71.854 | 0.000 / 34.909 | 241.426 / 287.906 | +19.3 % |
| `bicg_read_once_cg` | 8 | 899 | 16.217 / 16.217 | 0.563 / 0.563 | 3.606 / 5.070 | 1.997 / 3.788 | 3.907 / 7.531 | 0.000 / 7.068 | 26.291 / 40.237 | +53.0 % |
| `bicg_sequential_contiguous_w8_cg` | 11 | 1930 | 104.876 / 104.876 | 0.566 / 0.566 | 37.330 / 46.527 | 24.083 / 30.469 | 44.161 / 71.854 | 0.000 / 36.155 | 211.016 / 290.447 | +37.6 % |
| `bicg_two_pass_cg` | 11 | 1454 | 10.709 / 10.709 | 0.560 / 0.560 | 5.478 / 8.217 | 3.044 / 6.026 | 5.830 / 9.454 | 0.000 / 8.943 | 25.621 / 43.909 | +71.4 % |
| `bicg_two_pass_pipeline_cg` | 1 | 853 | 10.709 / 10.709 | 0.576 / 0.576 | 5.665 / 7.095 | 3.148 / 4.790 | 5.830 / 9.454 | 0.000 / 6.913 | 25.928 / 39.537 | +52.5 % |
| `dot3_w16_cg` | 6 | 851 | 23.879 / 23.879 | 0.048 / 0.047 | 11.456 / 15.287 | 7.565 / 10.458 | 14.499 / 40.334 | 0.000 / 30.821 | 57.446 / 120.826 | +110.3 % |
| `dot3_w2_cg` | 6 | 1748 | 24.984 / 24.984 | 0.375 / 0.374 | 12.219 / 13.979 | 7.539 / 10.728 | 14.499 / 40.334 | 0.000 / 33.852 | 59.616 / 124.251 | +108.4 % |
| `dot3_w32_cg` | 6 | 855 | 23.985 / 23.985 | 0.048 / 0.048 | 22.619 / 19.651 | 15.010 / 12.043 | 14.499 / 40.334 | 0.000 / 30.835 | 76.161 / 126.895 | +66.6 % |
| `dot3_w4_cg` | 6 | 1239 | 24.347 / 24.347 | 0.188 / 0.188 | 11.734 / 13.601 | 7.543 / 10.083 | 14.499 / 40.334 | 0.000 / 32.132 | 58.311 / 120.686 | +107.0 % |
| `dot3_w8_cg` | 6 | 984 | 24.170 / 24.170 | 0.095 / 0.095 | 11.545 / 14.009 | 7.550 / 10.011 | 14.499 / 40.334 | 0.000 / 31.271 | 57.859 / 119.889 | +107.2 % |
| `gesummv_factor_out_cg` | 13 | 1584 | 12.392 / 12.392 | 0.746 / 0.746 | 7.261 / 12.626 | 4.044 / 8.100 | 7.770 / 14.538 | 0.000 / 12.597 | 32.212 / 60.998 | +89.4 % |
| `gesummv_literal_cg` | 19 | 2805 | 27.884 / 27.884 | 0.942 / 0.942 | 31.470 / 47.562 | 17.826 / 27.311 | 48.071 / 54.839 | 0.000 / 16.722 | 126.192 / 175.258 | +38.9 % |
| `gesummv_x_read_once_cg` | 10 | 1033 | 12.392 / 12.392 | 0.742 / 0.742 | 5.695 / 8.812 | 3.157 / 5.681 | 6.036 / 12.805 | 0.000 / 10.735 | 28.021 / 51.166 | +82.6 % |
| `mvt_column_cg` | 13 | 1556 | 10.770 / 10.770 | 0.561 / 0.561 | 5.691 / 9.982 | 3.173 / 6.800 | 6.047 / 10.084 | 0.000 / 9.724 | 26.241 / 47.920 | +82.6 % |
| `mvt_column_pipeline_cg` | 1 | 909 | 10.770 / 10.770 | 0.578 / 0.578 | 5.888 / 8.201 | 3.283 / 5.284 | 6.047 / 10.084 | 0.000 / 7.538 | 26.565 / 42.454 | +59.8 % |
| `mvt_contiguous_w8_cg` | 13 | 4777 | 106.018 / 106.018 | 2.709 / 2.709 | 114.450 / 66.018 | 74.463 / 42.848 | 56.728 / 85.247 | 0.000 / 46.645 | 354.368 / 349.485 | -1.4 % |
| `mvt_dma_copy_cg` | 14 | 12518 | 12.230 / 12.230 | 0.745 / 0.745 | 7.197 / 19.802 | 17.492 / 26.121 | 329.970 / 334.007 | 435.828 / 366.584 | 803.462 / 759.490 | -5.5 % |
| `mvt_padded_w8_cg` | 13 | 2056 | 106.018 / 106.018 | 0.750 / 0.750 | 47.779 / 52.810 | 31.005 / 35.847 | 56.728 / 85.660 | 0.000 / 37.888 | 242.280 / 318.974 | +31.7 % |
| `mvt_read_once_cg` | 10 | 989 | 16.278 / 16.278 | 0.566 / 0.566 | 3.832 / 6.290 | 2.134 / 4.370 | 4.124 / 8.161 | 0.000 / 7.808 | 26.933 / 43.472 | +61.4 % |

prices' new terms (distinct across the 22 points: 16):
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 1.7689563914314537, "dma": 3.378391099999999, "streamers": 1.0100404536274674}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 1.8263902927419375, "dma": 3.378391099999999, "streamers": 1.0100404536274674}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 1.8838241940524214, "dma": 3.378391099999999, "streamers": 1.136295510330901}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 1.998691996673389, "dma": 3.378391099999999, "streamers": 1.6413157371446345}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.056125897983873, "dma": 3.378391099999999, "streamers": 1.5150606804412012}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.056125897983873, "dma": 3.378391099999999, "streamers": 1.8938258505515013}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.2858615032258083, "dma": 3.378391099999999, "streamers": 2.5251011340686684}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.343295404536292, "dma": 3.378391099999999, "streamers": 2.7776112474755354}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.5155971084677433, "dma": 3.378391099999999, "streamers": 2.5251011340686684}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.5155971084677433, "dma": 3.378391099999999, "streamers": 3.1563764175858355}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.5730310097782274, "dma": 3.378391099999999, "streamers": 2.7776112474755354}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 2.5730310097782274, "dma": 3.378391099999999, "streamers": 3.4088865309927026}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 3.434539529435485, "dma": 3.378391099999999, "streamers": 4.545182041323604}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 3.4919734307459684, "dma": 3.378391099999999, "streamers": 5.050202268137337}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 3.4919734307459684, "dma": 3.378391099999999, "streamers": 5.933987665061371}
- {"e_l2": 54.476143195250145, "r_strm": 0.08473695178960629, "r_xbar": 0.0} {"crossbar": 5.272424371370967, "dma": 3.378391099999999, "streamers": 8.585343855833473}

STOP:
- dot3_w16_cg: windows differ: [(0, 6270), (1, 314), (2, 287), (3, 34), (4, 14), (5, 169), (6, 54), (7, 859)] / [(0, 6266), (1, 314), (2, 287), (3, 34), (4, 3), (5, 161), (6, 52), (7, 884)]
- dot3_w16_cg: window 0 boot: counters differ in ['copies']
- dot3_w16_cg: window 1 dma_in: counters differ in ['copies']
- dot3_w16_cg: window 2 dma_in: counters differ in ['copies']
- dot3_w16_cg: window 3 streamer_config: counters differ in ['copies']
- dot3_w16_cg: window 4 acc_config: counters differ in ['copies']
- dot3_w16_cg: window 5 run: counters differ in ['banks', 'copies', 'groups', 'inputs', 'movers']
- dot3_w16_cg: window 6 dma_out: counters differ in ['copies']
- dot3_w16_cg: window 7 check: counters differ in ['copies']
- dot3_w2_cg: windows differ: [(0, 6270), (1, 314), (2, 287), (3, 34), (4, 14), (5, 1066), (6, 54), (7, 962)] / [(0, 6266), (1, 314), (2, 287), (3, 34), (4, 3), (5, 1058), (6, 52), (7, 987)]
- dot3_w2_cg: window 0 boot: counters differ in ['copies']
- dot3_w2_cg: window 1 dma_in: counters differ in ['copies']
- dot3_w2_cg: window 2 dma_in: counters differ in ['copies']
- dot3_w2_cg: window 3 streamer_config: counters differ in ['copies']
- dot3_w2_cg: window 4 acc_config: counters differ in ['copies']
- dot3_w2_cg: window 5 run: counters differ in ['banks', 'copies', 'groups', 'inputs', 'movers']
- dot3_w2_cg: window 6 dma_out: counters differ in ['copies']
- dot3_w2_cg: window 7 check: counters differ in ['copies']
- dot3_w32_cg: windows differ: [(0, 6262), (1, 314), (2, 287), (3, 35), (4, 14), (5, 169), (6, 63), (7, 857)] / [(0, 6266), (1, 314), (2, 287), (3, 35), (4, 3), (5, 164), (6, 52), (7, 880)]
- dot3_w32_cg: window 0 boot: counters differ in ['copies']
- dot3_w32_cg: window 1 dma_in: counters differ in ['copies']
- dot3_w32_cg: window 2 dma_in: counters differ in ['copies']
- dot3_w32_cg: window 3 streamer_config: counters differ in ['copies']
- dot3_w32_cg: window 4 acc_config: counters differ in ['copies']
- dot3_w32_cg: window 5 run: counters differ in ['copies']
- dot3_w32_cg: window 6 dma_out: counters differ in ['copies']
- dot3_w32_cg: window 7 check: counters differ in ['copies']
- dot3_w4_cg: windows differ: [(0, 6262), (1, 314), (2, 287), (3, 35), (4, 14), (5, 553), (6, 63), (7, 473)] / [(0, 6266), (1, 314), (2, 287), (3, 35), (4, 3), (5, 548), (6, 52), (7, 496)]
- dot3_w4_cg: window 0 boot: counters differ in ['copies']
- dot3_w4_cg: window 1 dma_in: counters differ in ['copies']
- dot3_w4_cg: window 2 dma_in: counters differ in ['copies']
- dot3_w4_cg: window 3 streamer_config: counters differ in ['copies']
- dot3_w4_cg: window 4 acc_config: counters differ in ['copies']
- dot3_w4_cg: window 5 run: counters differ in ['copies']
- dot3_w4_cg: window 6 dma_out: counters differ in ['copies']
- dot3_w4_cg: window 7 check: counters differ in ['copies']
- dot3_w8_cg: windows differ: [(0, 6262), (1, 314), (2, 287), (3, 35), (4, 14), (5, 298), (6, 63), (7, 728)] / [(0, 6266), (1, 314), (2, 287), (3, 35), (4, 3), (5, 293), (6, 52), (7, 751)]
- dot3_w8_cg: window 0 boot: counters differ in ['copies']
- dot3_w8_cg: window 1 dma_in: counters differ in ['copies']
- dot3_w8_cg: window 2 dma_in: counters differ in ['copies']
- dot3_w8_cg: window 3 streamer_config: counters differ in ['copies']
- dot3_w8_cg: window 4 acc_config: counters differ in ['copies']
- dot3_w8_cg: window 5 run: counters differ in ['copies']
- dot3_w8_cg: window 6 dma_out: counters differ in ['copies']
- dot3_w8_cg: window 7 check: counters differ in ['copies']
