from pathlib import Path
f = Path("report/model_fit.py")
s = f.read_text()
reps = [
("""dma group in the CALIBRATION points' dma_in and dma_out windows less f_dma a cycle, over their beats (the bank
accesses SNAX-GVSoC's energy run counts beyond its priced ones, ge/<point>.json, over the superbank's banks): e_l2.
""", """dma group in the CALIBRATION points' dma_in and dma_out windows less f_dma a cycle, over their beats (the bank
accesses SNAX-GVSoC's energy run counts beyond its priced ones, over the superbank's banks): e_l2. SNAX-GVSoC's runs
are read as priced before the terms, the first file of GE_ORDER that has the point: ge/csyn2/ (CSYN2's tier A),
ge/ge1/ (GE1's dot3, the program their power runs used), then ge/ (the runs with the current prices).
"""),
("""REF_PAIR = ("mvt_contiguous_w8_cg", "mvt_padded_w8_cg")""", """GE_ORDER = ("csyn2", "ge1", "")  # ge/'s subfolders _ge reads a point's energy run from, first found
REF_PAIR = ("mvt_contiguous_w8_cg", "mvt_padded_w8_cg")"""),
("""def _ge(tech: str, pt: str) -> dict:
    return json.loads((_res(tech) / "ge" / f"{pt}.json").read_text())
""", """def ge_path(tech: str, pt: str) -> Path:
    \"\"\"The point's energy run as the fits read it: the first of GE_ORDER's folders under ge/ that has it.\"\"\"
    for d in GE_ORDER:
        f = _res(tech) / "ge" / d / f"{pt}.json"
        if f.is_file():
            return f
    raise FileNotFoundError(f"no {pt}.json under ge/ ({', '.join(d + '/' if d else 'ge/' for d in GE_ORDER)})")


def _ge(tech: str, pt: str) -> dict:
    return json.loads(ge_path(tech, pt).read_text())
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:120]
    s = s.replace(o, n)
f.write_text(s)

f = Path("report/ablation.py")
s = f.read_text()
reps = [
("""Re-prices each tier A point's energy run as CSYN2 priced it (ge/csyn2/<point>.json, else ge/<point>.json) over the""",
 """Re-prices each tier A point's energy run as CSYN2 priced it (model_fit's _ge: ge/csyn2/, ge/ge1/, then ge/) over the"""),
("""def base_ge(tech: str, pt: str) -> dict:
    \"\"\"The point's energy run as CSYN2 priced it: ge/csyn2/<point>.json once ge/ holds the runs priced with the
    terms, ge/<point>.json before.\"\"\"
    old = ROOT / "results" / "cluster" / tech / "ge" / "csyn2" / f"{pt}.json"
    return json.loads(old.read_text()) if old.is_file() else mf._ge(tech, pt)


def rerun_nj(tech: str, pt: str, marks: set[int]) -> float | None:
    \"\"\"ge/<point>.json's six parts over the program window when it is priced with the terms, else None.\"\"\"
    ge = mf._ge(tech, pt)
    if "r_strm" not in ge["prices"]:
        return None
""", """def base_ge(tech: str, pt: str) -> dict:
    \"\"\"The point's energy run as CSYN2 priced it, as the fits read it (model_fit's _ge).\"\"\"
    return mf._ge(tech, pt)


def rerun_nj(tech: str, pt: str, marks: set[int]) -> float | None:
    \"\"\"ge/<point>.json's six parts over the program window when it is priced with the terms, else None: also when
    there is no such file, or it is the one base_ge read (no run beside the base).\"\"\"
    f = ROOT / "results" / "cluster" / tech / "ge" / f"{pt}.json"
    if not f.is_file() or f.resolve() == mf.ge_path(tech, pt).resolve():
        return None
    ge = json.loads(f.read_text())
    if "r_strm" not in ge["prices"]:
        return None
"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:120]
    s = s.replace(o, n)
f.write_text(s)
