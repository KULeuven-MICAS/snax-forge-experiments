"""Step 3: paper/data/<set>.csv before (as committed) and after the --run, row by row.

    python paper_cmp.py BEFORE_DIR AFTER_DIR [SET ...]

Stops (exit 1) when a row's status, cycles or est_cycles moved, a row was added or dropped, or any column that is not
an energy (*_nj) moved. Prints Markdown: per set the rows and statuses, static_nj and dynamic_nj before and after
(min, max, the five largest changes), idle_nj before and after.
"""

import csv
import sys
from pathlib import Path


def load(p: Path) -> tuple[list[str], dict[str, dict]]:
    with p.open(newline="") as fh:
        r = csv.DictReader(fh)
        rows = list(r)
        return r.fieldnames, {row["id"]: row for row in rows}


def num(x: str) -> float | None:
    try:
        return float(x)
    except ValueError:
        return None


def main() -> int:
    before, after = Path(sys.argv[1]), Path(sys.argv[2])
    sets = sys.argv[3:] or ["forms", "limits"]
    stop = []
    for s in sets:
        hb, b = load(before / f"{s}.csv")
        ha, a = load(after / f"{s}.csv")
        print(f"\n### {s}.csv\n")
        if hb != ha:
            stop.append(f"{s}: header changed")
        if list(b) != list(a):
            stop.append(f"{s}: rows differ: {sorted(set(b) ^ set(a))} or order")
        stat_b = {}
        for row in b.values():
            stat_b[row["status"]] = stat_b.get(row["status"], 0) + 1
        stat_a = {}
        for row in a.values():
            stat_a[row["status"]] = stat_a.get(row["status"], 0) + 1
        print(f"- rows: {len(b)} before, {len(a)} after; status before {stat_b}, after {stat_a}")
        moved_other = {}
        for i in b:
            if i not in a:
                continue
            for c in hb:
                if b[i][c] != a[i].get(c):
                    if c in ("status", "cycles", "est_cycles"):
                        stop.append(f"{s} {i}: {c} {b[i][c]} -> {a[i].get(c)}")
                    elif not c.endswith("_nj"):
                        moved_other.setdefault(c, []).append(f"{i}: {b[i][c]} -> {a[i].get(c)}")
        for c, v in moved_other.items():
            stop.append(f"{s}: non-energy column {c} moved in {len(v)} rows, e.g. {v[:3]}")
        moved = {c for c in hb if c.endswith("_nj") and any(b[i][c] != a[i][c] for i in b if i in a)}
        print(f"- energy columns that moved: {', '.join(sorted(moved)) or 'none'}")
        for c in ("static_nj", "dynamic_nj", "idle_nj"):
            vb = [num(b[i][c]) for i in b if num(b[i][c]) is not None]
            va = [num(a[i][c]) for i in a if num(a[i][c]) is not None]
            print(f"\n`{c}`: before min {min(vb):.4f}, max {max(vb):.4f}, sum {sum(vb):.4f}; after min {min(va):.4f}, "
                  f"max {max(va):.4f}, sum {sum(va):.4f}\n")
            ch = sorted(((num(a[i][c]) - num(b[i][c]), i) for i in b if i in a and num(b[i][c]) is not None
                         and num(a[i][c]) is not None), key=lambda x: -abs(x[0]))
            n = 5 if c != "idle_nj" else len(ch)
            print(f"| id | {c} before | after | change | % |\n|---|---:|---:|---:|---:|")
            for d, i in ch[:n]:
                pb = num(b[i][c])
                print(f"| `{i}` | {pb:.4f} | {num(a[i][c]):.4f} | {d:+.4f} | {100 * d / pb if pb else 0:+.1f} |")
    if stop:
        print("\nSTOP:\n" + "\n".join(f"- {x}" for x in stop))
        return 1
    print("\nno status, cycles, est_cycles or non-energy column moved")
    return 0


if __name__ == "__main__":
    sys.exit(main())
