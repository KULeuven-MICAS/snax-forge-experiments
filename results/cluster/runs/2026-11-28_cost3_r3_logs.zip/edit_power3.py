from pathlib import Path
f = Path("cluster/power.py")
s = f.read_text()
reps = [
("""    strip: str          # the wrapper's instance in the testbench (read_saif -strip_path)
    power_csv: Path     # results/<source>/<tech>/power_pt.csv
    power_reports: Path  # results/<source>/<tech>/power_reports/
""", """    strip: str          # the wrapper's instance in the testbench (read_saif -strip_path)
    power_csv: Path | None  # results/<source>/<tech>/power_pt.csv (None: no rows written)
    power_reports: Path  # results/<source>/<tech>/power_reports/
    pwr_dir: str = "pwr"         # part 1's folder in the run zip
    pt_dir: str = "pt"           # part 2's folder in the run zip
    analysis: str = "averaged"   # PrimePower's power_analysis_mode (time_based: read_vcd on part 1's cuts)
"""),
("""    return Site("cluster pwr", cl.RUN_ZIPS, cl.TMP, cl.NETLIST, STRIP, POWER_CSV, POWER_REPORTS)
""", """    return Site("cluster pwr", cl.RUN_ZIPS, cl.TMP, cl.NETLIST, STRIP, POWER_CSV, POWER_REPORTS)


def time_site() -> Site:
    \"\"\"forge's cluster in time-based mode (--time-based): pwr_time/ and pt_time/ of the run zip, the reports in
    power_reports_time/, no power_pt.csv row; the averaged results are left as they are.\"\"\"
    return Site("cluster pwr --time-based", cl.RUN_ZIPS, cl.TMP, cl.NETLIST, STRIP, None, POWER_REPORTS_TIME,
                "pwr_time", "pt_time", "time_based")
"""),
("""POWER_REPORTS = RESULTS / "power_reports"
""", """POWER_REPORTS = RESULTS / "power_reports"
POWER_REPORTS_TIME = RESULTS / "power_reports_time"
"""),
("""def windows_file(wins: list[dict], saifs: dict[str, Path]) -> str:
    \"\"\"PWR_WINDOWS: one `<name> <saif path>` per line, in the span's order (pt_power.tcl's cluster mode).\"\"\"
    lines = []
    for w in wins:
        n, f = window_name(w), str(saifs[window_name(w)])
        if re.search(r"\\s", n + f):
            raise ValueError(f"whitespace in a window's name or SAIF path: {n!r} {f!r}")
        lines.append(f"{n} {f}")
    return "\\n".join(lines) + "\\n"
""", """def cut_ns(t: int) -> str:
    \"\"\"A cut's time (tb_bin's ps numbers, read at the cuts' 10ps unit, X76) in ns for read_vcd -time, exactly.\"\"\"
    return f"{t // 100}.{t % 100:02d}"


def windows_file(wins: list[dict], saifs: dict[str, Path], times: bool = False) -> str:
    \"\"\"PWR_WINDOWS: one `<name> <activity file>` per line, in the span's order (pt_power.tcl's cluster mode); with
    times (a VCD cut per window), also the window's bounds in ns, `<name> <vcd> <t0_ns> <t1_ns>`.\"\"\"
    lines = []
    for w in wins:
        n, f = window_name(w), str(saifs[window_name(w)])
        if re.search(r"\\s", n + f):
            raise ValueError(f"whitespace in a window's name or activity path: {n!r} {f!r}")
        lines.append(f"{n} {f} {cut_ns(w['cut_t0'])} {cut_ns(w['cut_t1'])}" if times else f"{n} {f}")
    return "\\n".join(lines) + "\\n"
"""),
("""def part2(p: dict, pre: dict, args, p1: dict, site: Site | None = None) -> dict:
    \"\"\"Part 2: one PT session on the netlist, a window after another (pt_power.tcl's cluster mode), the checks per
    window, power_pt.csv, the report zip and pt/ of the run zip; site is where (forge's cluster by default).\"\"\"
""", """def part2(p: dict, pre: dict, args, p1: dict, site: Site | None = None, vcds: dict[str, Path] | None = None) -> dict:
    \"\"\"Part 2: one PT session on the netlist, a window after another (pt_power.tcl's cluster mode), the checks per
    window, power_pt.csv, the report zip and pt/ of the run zip; site is where (forge's cluster by default). In
    time-based mode (site.analysis) PT reads each window's VCD cut (vcds) between its bounds; the SAIFs still serve
    the annotation's check.\"\"\"
"""),
("""           "quiet_elf_sha256": pre["quiet_sha"], "seconds": {}}
    rows = []""", """           "quiet_elf_sha256": pre["quiet_sha"], "seconds": {}, "analysis": site.analysis}
    rows = []"""),
("""            saifs[n].write_bytes(arc.read(run_zip, f"pwr/{n}/w.saif"))
        (pt / "windows.txt").write_text(windows_file(wins, saifs))""", """            saifs[n].write_bytes(arc.read(run_zip, f"{site.pwr_dir}/{n}/w.saif"))
        timed = site.analysis == "time_based"
        if timed and (not vcds or any(not vcds.get(window_name(w), Path("/nonexistent")).is_file() for w in wins)):
            raise cl.Stop(f"time-based: a window has no VCD cut ({sorted(vcds or {})})")
        (pt / "windows.txt").write_text(windows_file(wins, vcds if timed else saifs, times=timed))"""),
("""               "PWR_STRIP": site.strip, "PWR_EXTRA_SDC": str(pt / "run" / "cluster.sdc"),""",
 """               "PWR_STRIP": site.strip, "PWR_EXTRA_SDC": str(pt / "run" / "cluster.sdc"), "PWR_ANALYSIS": site.analysis,"""),
("""            if rows:
                merge_csv(site.power_csv, rows)""", """            if rows and site.power_csv is not None:
                merge_csv(site.power_csv, rows)"""),
("""    members["windows.json"] = arc.read(run_zip, "pwr/windows.json")""", """    site = site or forge_site()
    members["windows.json"] = arc.read(run_zip, f"{site.pwr_dir}/windows.json")"""),
("""    z = (site or forge_site()).power_reports / f"{point}.zip"
""", """    z = site.power_reports / f"{point}.zip"
"""),
("""    new = {"pt/pt_check.json": (json.dumps(res, indent=2, default=str) + "\\n").encode()}
    for f in ("pt_shell.log", "time.txt", "windows.txt"):
        if (pt / f).is_file():
            new[f"pt/{f}"] = (pt / f).read_bytes()
    for f in ("setup_times.txt", "cluster_ports.rpt"):
        for src in (rep / f, pt / "reports" / f):
            if src.is_file():
                new[f"pt/{f}"] = src.read_bytes()
    for w in wins:
        n = window_name(w)
        for f in ("not_annotated.rpt", "done"):
            if (rep / n / f).is_file():
                new[f"pt/{n}/{f}"] = (rep / n / f).read_bytes()
    if (pt.parent / "logs").is_dir():
        new.update({f"pt/logs/{k}": v.read_bytes() for k, v in arc.files_of(pt.parent / "logs").items()})
    old = {k: v for k, v in arc.read_all(run_zip).items() if not k.startswith("pt/")}
    arc.write(run_zip, {**old, **new})
    print(f"  packed {z.relative_to(ROOT)} ({len(members)} members, {z.stat().st_size / 1e6:.1f} MB) and "
          f"{run_zip.relative_to(ROOT)} ({len(new)} members under pt/)", flush=True)""",
 """    d = site.pt_dir
    new = {f"{d}/pt_check.json": (json.dumps(res, indent=2, default=str) + "\\n").encode()}
    for f in ("pt_shell.log", "time.txt", "windows.txt"):
        if (pt / f).is_file():
            new[f"{d}/{f}"] = (pt / f).read_bytes()
    for f in ("setup_times.txt", "cluster_ports.rpt"):
        for src in (rep / f, pt / "reports" / f):
            if src.is_file():
                new[f"{d}/{f}"] = src.read_bytes()
    for w in wins:
        n = window_name(w)
        for f in ("not_annotated.rpt", "done"):
            if (rep / n / f).is_file():
                new[f"{d}/{n}/{f}"] = (rep / n / f).read_bytes()
    if (pt.parent / "logs").is_dir():
        new.update({f"{d}/logs/{k}": v.read_bytes() for k, v in arc.files_of(pt.parent / "logs").items()})
    old = {k: v for k, v in arc.read_all(run_zip).items() if not k.startswith(f"{d}/")}
    arc.write(run_zip, {**old, **new})
    print(f"  packed {z.relative_to(ROOT)} ({len(members)} members, {z.stat().st_size / 1e6:.1f} MB) and "
          f"{run_zip.relative_to(ROOT)} ({len(new)} members under {d}/)", flush=True)"""),
]
for o, n in reps:
    assert s.count(o) == 1, o[:200]
    s = s.replace(o, n)
f.write_text(s)
