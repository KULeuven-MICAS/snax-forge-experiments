from pathlib import Path
f = Path("cluster/test_power.py")
s = f.read_text()
o = """def test_pack2_report_zip_size():"""
n = '''HIER_TIME = """****************************************
Report : Time Based Power
\t-hierarchy
Design : snax_forge_cluster_wrapper
****************************************

                                      Int                       Switch                    Leak                      Peak                      Peak                             Glitch
Hierarchy                             Power                     Power                     Power                     Power                     Time                             Power
--------------------------------------------------------------------------------------------------------------------------------
snax_forge_cluster_wrapper            3.223882e-03              1.134443e-03              8.819431e-03              5.248917e+00              10640.00-10640.01                0.000000e+00
"""


def test_hierarchy_total_time_based():
    # time-based: no total column, peak power fourth; the total is internal + switching + leakage
    top = power.hier_top(HIER_TIME)
    assert top[:3] == (3.223882e-03, 1.134443e-03, 8.819431e-03), top
    assert abs(top[3] - 1.317776e-02) <= power.HIER_TOL * 1.317776e-02, top
    assert power.hier_top(HIER.format(total="1.528582e-01"))[3] == 1.528582e-01     # averaged unchanged


def test_pack2_report_zip_size():'''
assert s.count(o) == 1
f.write_text(s.replace(o, n, 1))
