import json, sys
sys.path[:0] = ["arc", "cluster"]
import arc
import power
res = "results/cluster/nangate45"
pt = sys.argv[1]
za, zt = f"{res}/power_reports/{pt}.zip", f"{res}/power_reports_time/{pt}.zip"
wins = json.loads(arc.read(zt, "windows.json"))
G = ("clock_network", "register", "combinational", "black_box", "memory")
tot = {m: {g: [0.0, 0.0] for g in G} for m in ("avg", "time")}
cyc = 0
for w in wins:
    n, c = f"{w['mark']}_{w['kind']}", w["cycles"]
    cyc += c
    for m, z in (("avg", za), ("time", zt)):
        groups, _ = power.power_table(arc.read_text(z, f"{n}/power.rpt"))
        u = power.pwr.pt_to_uw_text(arc.read_text(z, f"{n}/units.rpt")) if hasattr(power.pwr, "pt_to_uw_text") else 1e6
        for g in G:
            i, s, _l, _t = groups[g]
            tot[m][g][0] += i * u * 10 / 1000 * c
            tot[m][g][1] += s * u * 10 / 1000 * c
print("| PT group | averaged int / sw pJ a cycle | time-based int / sw | time / avg (int + sw) |")
print("|---|---:|---:|---:|")
for g in G:
    a, t = tot["avg"][g], tot["time"][g]
    sa, st = sum(a) / cyc, sum(t) / cyc
    print(f"| {g} | {a[0] / cyc:.3f} / {a[1] / cyc:.3f} | {t[0] / cyc:.3f} / {t[1] / cyc:.3f} | {st / sa if sa else float('nan'):.3f} |")
sa = sum(sum(v) for v in tot["avg"].values()) / cyc
st = sum(sum(v) for v in tot["time"].values()) / cyc
print(f"| all | {sa:.3f} | {st:.3f} | {st / sa:.3f} |")
