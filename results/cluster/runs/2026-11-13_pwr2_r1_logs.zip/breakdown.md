✨ Pixi task (cluster-breakdown): python report/cluster_breakdown.py --md
results/cluster/nangate45/breakdown.json: dot3_w16, dot3_w4, dot3_w8, dot3_w2, dot3_w32
### dot3_w16

Total 1,261,630 µm².

| group | µm² | share |
|---|---|---|
| TCDM banks (macros) | 432,726 | 34.3 % |
| I-cache macros (data and tag) | 43,064 | 3.4 % |
| accelerator datapath | 115,506 | 9.2 % |
| accelerator control | 756 | 0.1 % |
| accelerator csr (with its peripherals) | 1,060 | 0.1 % |
| streamers | 169,312 | 13.4 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2,129 | 0.2 % |
| TCDM sparse interconnect | 102,884 | 8.2 % |
| TCDM bank logic (AMO shims, muxes) | 55,539 | 4.4 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 82,140 | 6.5 % |
| RISC-V cores (Snitch, with the shared mul/div) | 30,424 | 2.4 % |
| I-cache logic (the hive without its macros and mul/div) | 24,232 | 1.9 % |
| AXI: the external cuts, both crossbars, the converters | 183,222 | 14.5 % |
| cluster peripherals (with the barrier) | 18,138 | 1.4 % |
| others (what no rule names) | 497 | 0.0 % |

HWCOST (snax-forge `299ef010`, `platforms/snax_forge.json`) against the cluster's groups:

| part | HWCOST µm² | cluster µm² | difference | share (HWCOST / cluster) |
|---|---|---|---|---|
| datapath | 115,450 | 115,506 | 0.0 % | 14.1 % / 14.1 % |
| control | 713 | 756 | -5.7 % | 0.1 % / 0.1 % |
| streamers | 158,090 | 169,312 | -6.6 % | 19.3 % / 20.6 % |
| crossbar | 113,776 | 102,884 | +10.6 % | 13.9 % / 12.5 % |
| memory | 432,726 | 432,726 | 0.0 % | 52.7 % / 52.7 % |
| the five parts | 820,755 | 821,185 | -0.1 % | |

Not costed by HWCOST: 440,445 µm² of the cluster (34.9 %).

The accelerator's shell in the cluster against `done/dot/forge3_w16` alone (snax-forge `3c7ea005`):

| | cluster µm² | alone µm² | difference |
|---|---|---|---|
| csr | 1,060 | 1,074 | -1.3 % |
| ctrl | 756 | 761 | -0.7 % |
| datapath | 115,506 | 115,442 | +0.1 % |
| glue | 1 | 2 |  |
| total | 117,322 | 117,278 | 0.0 % |
### dot3_w4

Total 990,408 µm².

| group | µm² | share |
|---|---|---|
| TCDM banks (macros) | 432,726 | 43.7 % |
| I-cache macros (data and tag) | 43,064 | 4.3 % |
| accelerator datapath | 29,308 | 3.0 % |
| accelerator control | 756 | 0.1 % |
| accelerator csr (with its peripherals) | 1,060 | 0.1 % |
| streamers | 51,982 | 5.2 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2,151 | 0.2 % |
| TCDM sparse interconnect | 35,211 | 3.6 % |
| TCDM bank logic (AMO shims, muxes) | 55,535 | 5.6 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 82,139 | 8.3 % |
| RISC-V cores (Snitch, with the shared mul/div) | 30,424 | 3.1 % |
| I-cache logic (the hive without its macros and mul/div) | 24,229 | 2.4 % |
| AXI: the external cuts, both crossbars, the converters | 183,214 | 18.5 % |
| cluster peripherals (with the barrier) | 18,137 | 1.8 % |
| others (what no rule names) | 472 | 0.0 % |

HWCOST (snax-forge `b29bf0c0`, `platforms/snax_forge.json`) against the cluster's groups:

| part | HWCOST µm² | cluster µm² | difference | share (HWCOST / cluster) |
|---|---|---|---|---|
| datapath | 29,293 | 29,308 | 0.0 % | 5.4 % / 5.3 % |
| control | 713 | 756 | -5.7 % | 0.1 % / 0.1 % |
| streamers | 44,740 | 51,982 | -13.9 % | 8.2 % / 9.5 % |
| crossbar | 37,840 | 35,211 | +7.5 % | 6.9 % / 6.4 % |
| memory | 432,726 | 432,726 | 0.0 % | 79.4 % / 78.7 % |
| the five parts | 545,313 | 549,982 | -0.8 % | |

Not costed by HWCOST: 440,425 µm² of the cluster (44.5 %).

The accelerator's shell in the cluster against `done/dot/forge3_w4` alone (snax-forge `3c7ea005`):

| | cluster µm² | alone µm² | difference |
|---|---|---|---|
| csr | 1,060 | 1,074 | -1.3 % |
| ctrl | 756 | 761 | -0.7 % |
| datapath | 29,308 | 29,291 | +0.1 % |
| glue | 1 | 2 |  |
| total | 31,124 | 31,127 | 0.0 % |
### dot3_w8

Total 1,080,530 µm².

| group | µm² | share |
|---|---|---|
| TCDM banks (macros) | 432,726 | 40.0 % |
| I-cache macros (data and tag) | 43,064 | 4.0 % |
| accelerator datapath | 58,042 | 5.4 % |
| accelerator control | 756 | 0.1 % |
| accelerator csr (with its peripherals) | 1,060 | 0.1 % |
| streamers | 91,070 | 8.4 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2,130 | 0.2 % |
| TCDM sparse interconnect | 57,447 | 5.3 % |
| TCDM bank logic (AMO shims, muxes) | 55,592 | 5.1 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 82,141 | 7.6 % |
| RISC-V cores (Snitch, with the shared mul/div) | 30,424 | 2.8 % |
| I-cache logic (the hive without its macros and mul/div) | 24,231 | 2.2 % |
| AXI: the external cuts, both crossbars, the converters | 183,218 | 17.0 % |
| cluster peripherals (with the barrier) | 18,137 | 1.7 % |
| others (what no rule names) | 492 | 0.0 % |

HWCOST (snax-forge `b29bf0c0`, `platforms/snax_forge.json`) against the cluster's groups:

| part | HWCOST µm² | cluster µm² | difference | share (HWCOST / cluster) |
|---|---|---|---|---|
| datapath | 58,012 | 58,042 | -0.1 % | 9.1 % / 9.1 % |
| control | 713 | 756 | -5.7 % | 0.1 % / 0.1 % |
| streamers | 82,519 | 91,070 | -9.4 % | 12.9 % / 14.2 % |
| crossbar | 63,334 | 57,447 | +10.2 % | 9.9 % / 9.0 % |
| memory | 432,726 | 432,726 | 0.0 % | 67.9 % / 67.6 % |
| the five parts | 637,305 | 640,041 | -0.4 % | |

Not costed by HWCOST: 440,489 µm² of the cluster (40.8 %).

The accelerator's shell in the cluster against `done/dot/forge3_w8` alone (snax-forge `3c7ea005`):

| | cluster µm² | alone µm² | difference |
|---|---|---|---|
| csr | 1,060 | 1,074 | -1.3 % |
| ctrl | 756 | 761 | -0.7 % |
| datapath | 58,042 | 58,009 | +0.1 % |
| glue | 1 | 2 |  |
| total | 59,858 | 59,845 | 0.0 % |
### dot3_w2

Total 945,145 µm².

| group | µm² | share |
|---|---|---|
| TCDM banks (macros) | 432,726 | 45.8 % |
| I-cache macros (data and tag) | 43,064 | 4.6 % |
| accelerator datapath | 14,939 | 1.6 % |
| accelerator control | 756 | 0.1 % |
| accelerator csr (with its peripherals) | 1,060 | 0.1 % |
| streamers | 32,418 | 3.4 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2,151 | 0.2 % |
| TCDM sparse interconnect | 23,878 | 2.5 % |
| TCDM bank logic (AMO shims, muxes) | 55,534 | 5.9 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 82,141 | 8.7 % |
| RISC-V cores (Snitch, with the shared mul/div) | 30,423 | 3.2 % |
| I-cache logic (the hive without its macros and mul/div) | 24,228 | 2.6 % |
| AXI: the external cuts, both crossbars, the converters | 183,217 | 19.4 % |
| cluster peripherals (with the barrier) | 18,137 | 1.9 % |
| others (what no rule names) | 472 | 0.0 % |

HWCOST (snax-forge `b29bf0c0`, `platforms/snax_forge.json`) against the cluster's groups:

| part | HWCOST µm² | cluster µm² | difference | share (HWCOST / cluster) |
|---|---|---|---|---|
| datapath | 14,932 | 14,939 | 0.0 % | 3.0 % / 3.0 % |
| control | 713 | 756 | -5.7 % | 0.1 % / 0.1 % |
| streamers | 25,796 | 32,418 | -20.4 % | 5.2 % / 6.4 % |
| crossbar | 25,177 | 23,878 | +5.4 % | 5.0 % / 4.7 % |
| memory | 432,726 | 432,726 | 0.0 % | 86.7 % / 85.7 % |
| the five parts | 499,344 | 504,717 | -1.1 % | |

Not costed by HWCOST: 440,428 µm² of the cluster (46.6 %).

The accelerator's shell in the cluster against `done/dot/forge3_w2` alone (snax-forge `3c7ea005`):

| | cluster µm² | alone µm² | difference |
|---|---|---|---|
| csr | 1,060 | 1,074 | -1.3 % |
| ctrl | 756 | 761 | -0.7 % |
| datapath | 14,939 | 14,931 | +0.1 % |
| glue | 1 | 2 |  |
| total | 16,755 | 16,767 | -0.1 % |
### dot3_w32

Total 1,621,112 µm².

| group | µm² | share |
|---|---|---|
| TCDM banks (macros) | 432,726 | 26.7 % |
| I-cache macros (data and tag) | 43,064 | 2.7 % |
| accelerator datapath | 230,437 | 14.2 % |
| accelerator control | 756 | 0.0 % |
| accelerator csr (with its peripherals) | 1,060 | 0.1 % |
| streamers | 325,740 | 20.1 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2,151 | 0.1 % |
| TCDM sparse interconnect | 191,070 | 11.8 % |
| TCDM bank logic (AMO shims, muxes) | 55,545 | 3.4 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 82,140 | 5.1 % |
| RISC-V cores (Snitch, with the shared mul/div) | 30,423 | 1.9 % |
| I-cache logic (the hive without its macros and mul/div) | 24,228 | 1.5 % |
| AXI: the external cuts, both crossbars, the converters | 183,141 | 11.3 % |
| cluster peripherals (with the barrier) | 18,137 | 1.1 % |
| others (what no rule names) | 494 | 0.0 % |

HWCOST (snax-forge `b29bf0c0`, `platforms/snax_forge.json`) against the cluster's groups:

| part | HWCOST µm² | cluster µm² | difference | share (HWCOST / cluster) |
|---|---|---|---|---|
| datapath | 230,322 | 230,437 | 0.0 % | 19.4 % / 19.5 % |
| control | 713 | 756 | -5.7 % | 0.1 % / 0.1 % |
| streamers | 309,231 | 325,740 | -5.1 % | 26.1 % / 27.6 % |
| crossbar | 213,577 | 191,070 | +11.8 % | 18.0 % / 16.2 % |
| memory | 432,726 | 432,726 | 0.0 % | 36.5 % / 36.6 % |
| the five parts | 1,186,570 | 1,180,729 | +0.5 % | |

Not costed by HWCOST: 440,383 µm² of the cluster (27.2 %).

The accelerator's shell in the cluster against `done/dot/forge3_w32` alone (snax-forge `b29bf0c0`):

| | cluster µm² | alone µm² | difference |
|---|---|---|---|
| csr | 1,060 | 1,074 | -1.3 % |
| ctrl | 756 | 761 | -0.7 % |
| datapath | 230,437 | 230,306 | +0.1 % |
| glue | 1 | 2 |  |
| total | 232,253 | 232,142 | 0.0 % |

