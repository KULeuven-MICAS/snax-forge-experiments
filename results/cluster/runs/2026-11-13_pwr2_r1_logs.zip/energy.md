✨ Pixi task (cluster-energy): python report/cluster_energy.py --md
results/cluster/nangate45/energy.json: dot3_w16, dot3_w4, dot3_w8, dot3_w2, dot3_w32
### dot3_w16

Per window, pJ per cycle (internal + switching, leakage out):

| group | 1_dma_in | 2_dma_in | 3_streamer_config | 4_acc_config | 5_run | 6_dma_out |
|---|---|---|---|---|---|---|
| TCDM banks (macros) | 27.9 | 29.4 | 0.0 | 0.0 | 79.2 | 0.4 |
| I-cache macros (data and tag) | 0.2 | 0.1 | 2.8 | 1.0 | 0.5 | 1.9 |
| accelerator datapath | 0.5 | 0.5 | 0.5 | 0.5 | 80.4 | 0.5 |
| accelerator control | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| accelerator csr (with its peripherals) | 0.9 | 0.9 | 0.9 | 1.0 | 1.0 | 0.9 |
| streamers | 154.2 | 154.2 | 154.2 | 154.2 | 149.8 | 153.7 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.5 | 1.5 | 1.6 | 1.7 | 1.5 | 1.5 |
| TCDM sparse interconnect | 3.0 | 3.0 | 3.0 | 3.0 | 49.2 | 3.1 |
| TCDM bank logic (AMO shims, muxes) | 29.0 | 29.8 | 20.6 | 20.6 | 42.0 | 20.7 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 83.7 | 86.8 | 60.7 | 60.7 | 61.7 | 58.9 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.7 | 19.7 | 20.2 | 20.2 | 19.9 | 19.4 |
| I-cache logic (the hive without its macros and mul/div) | 18.8 | 18.9 | 19.1 | 19.6 | 18.9 | 18.4 |
| AXI: the external cuts, both crossbars, the converters | 171.4 | 174.7 | 154.8 | 156.9 | 155.0 | 154.6 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 10.5 | 10.6 | 10.6 | 10.6 |
| others (what no rule names) | 0.0 | 0.0 | 0.0 | 0.1 | 0.0 | 0.0 |
| total | 521.7 | 530.5 | 449.4 | 450.4 | 670.2 | 445.0 |
| cycles | 305 | 291 | 32 | 11 | 185 | 77 |
| window nJ | 159.12 | 154.38 | 14.38 | 4.95 | 123.99 | 34.27 |

The span: 901 cycles, 491.10 nJ.

| group | nJ | share |
|---|---|---|
| TCDM banks (macros) | 31.75 | 6.5 % |
| I-cache macros (data and tag) | 0.43 | 0.1 % |
| accelerator datapath | 15.21 | 3.1 % |
| accelerator control | 0.43 | 0.1 % |
| accelerator csr (with its peripherals) | 0.84 | 0.2 % |
| streamers | 138.06 | 28.1 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.34 | 0.3 % |
| TCDM sparse interconnect | 11.25 | 2.3 % |
| TCDM bank logic (AMO shims, muxes) | 27.75 | 5.7 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 69.35 | 14.1 % |
| RISC-V cores (Snitch, with the shared mul/div) | 17.78 | 3.6 % |
| I-cache logic (the hive without its macros and mul/div) | 16.99 | 3.5 % |
| AXI: the external cuts, both crossbars, the converters | 150.37 | 30.6 % |
| cluster peripherals (with the barrier) | 9.52 | 1.9 % |
| others (what no rule names) | 0.02 | 0.0 % |

The run phase, `5_run` (185 cycles) against the idle `4_acc_config`:

| group | idle pJ/cycle | run pJ/cycle | run nJ | above idle nJ |
|---|---|---|---|---|
| TCDM banks (macros) | 0.0 | 79.2 | 14.65 | 14.65 |
| I-cache macros (data and tag) | 1.0 | 0.5 | 0.09 | -0.11 |
| accelerator datapath | 0.5 | 80.4 | 14.88 | 14.79 |
| accelerator control | 0.5 | 0.5 | 0.09 | 0.00 |
| accelerator csr (with its peripherals) | 1.0 | 1.0 | 0.18 | -0.00 |
| streamers | 154.2 | 149.8 | 27.71 | -0.81 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.7 | 1.5 | 0.28 | -0.04 |
| TCDM sparse interconnect | 3.0 | 49.2 | 9.11 | 8.56 |
| TCDM bank logic (AMO shims, muxes) | 20.6 | 42.0 | 7.77 | 3.97 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 60.7 | 61.7 | 11.42 | 0.19 |
| RISC-V cores (Snitch, with the shared mul/div) | 20.2 | 19.9 | 3.69 | -0.04 |
| I-cache logic (the hive without its macros and mul/div) | 19.6 | 18.9 | 3.49 | -0.14 |
| AXI: the external cuts, both crossbars, the converters | 156.9 | 155.0 | 28.68 | -0.34 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 1.95 | -0.00 |
| others (what no rule names) | 0.1 | 0.0 | 0.00 | -0.01 |

HWCOST's energy (snax-forge `299ef010`, stimulus rand64 seed 0) against the run phase; the shares are each side's of its own five parts:

| part | HWCOST nJ | share | run nJ | share | above idle nJ | share |
|---|---|---|---|---|---|---|
| datapath | 23.92 | 34.2 % | 14.88 | 22.4 % | 14.79 | 39.8 % |
| control | 0.07 | 0.1 % | 0.09 | 0.1 % | 0.00 | 0.0 % |
| streamers | 20.21 | 28.9 % | 27.71 | 41.7 % | -0.81 | -2.2 % |
| crossbar | 11.22 | 16.1 % | 9.11 | 13.7 % | 8.56 | 23.0 % |
| memory | 14.50 | 20.7 % | 14.65 | 22.0 % | 14.65 | 39.4 % |
| the five parts | 69.92 | | 66.44 | | 37.19 | |

The accelerator's shell in the run window against `done/dot/forge3_w16` alone (snax-forge `3c7ea005`, seed 0, X23's busy window):

| | cycles | pJ/cycle | nJ |
|---|---|---|---|
| in the cluster | 185 | 81.9 | 15.15 |
| alone | 129 | 181.6 | 23.43 |
### dot3_w4

Per window, pJ per cycle (internal + switching, leakage out):

| group | 1_dma_in | 2_dma_in | 3_streamer_config | 4_acc_config | 5_run | 6_dma_out |
|---|---|---|---|---|---|---|
| TCDM banks (macros) | 27.9 | 29.4 | 0.0 | 0.0 | 25.5 | 0.3 |
| I-cache macros (data and tag) | 0.2 | 0.1 | 2.7 | 0.8 | 0.1 | 2.0 |
| accelerator datapath | 0.5 | 0.5 | 0.5 | 0.5 | 26.3 | 0.5 |
| accelerator control | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| accelerator csr (with its peripherals) | 0.9 | 0.9 | 0.9 | 1.0 | 1.0 | 0.9 |
| streamers | 46.7 | 46.7 | 46.8 | 46.8 | 47.2 | 46.6 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.5 | 1.5 | 1.7 | 1.7 | 1.6 | 1.5 |
| TCDM sparse interconnect | 1.5 | 1.5 | 1.5 | 1.5 | 13.1 | 1.6 |
| TCDM bank logic (AMO shims, muxes) | 29.0 | 29.8 | 20.6 | 20.6 | 26.4 | 20.7 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 83.7 | 86.8 | 60.7 | 60.7 | 61.0 | 59.2 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.4 | 19.5 | 20.3 | 19.7 | 19.8 | 19.1 |
| I-cache logic (the hive without its macros and mul/div) | 18.8 | 18.9 | 19.1 | 19.2 | 18.9 | 18.2 |
| AXI: the external cuts, both crossbars, the converters | 171.4 | 174.7 | 154.7 | 156.7 | 155.6 | 154.1 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 10.5 | 10.6 | 10.6 | 10.6 |
| others (what no rule names) | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| total | 412.6 | 421.4 | 340.4 | 340.2 | 407.6 | 335.8 |
| cycles | 305 | 291 | 33 | 14 | 574 | 90 |
| window nJ | 125.84 | 122.63 | 11.23 | 4.76 | 233.95 | 30.22 |

The span: 1307 cycles, 528.63 nJ.

| group | nJ | share |
|---|---|---|
| TCDM banks (macros) | 31.75 | 6.0 % |
| I-cache macros (data and tag) | 0.47 | 0.1 % |
| accelerator datapath | 15.43 | 2.9 % |
| accelerator control | 0.63 | 0.1 % |
| accelerator csr (with its peripherals) | 1.24 | 0.2 % |
| streamers | 61.34 | 11.6 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.98 | 0.4 % |
| TCDM sparse interconnect | 8.66 | 1.6 % |
| TCDM bank logic (AMO shims, muxes) | 35.47 | 6.7 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 93.98 | 17.8 % |
| RISC-V cores (Snitch, with the shared mul/div) | 25.61 | 4.8 % |
| I-cache logic (the hive without its macros and mul/div) | 24.63 | 4.7 % |
| AXI: the external cuts, both crossbars, the converters | 213.62 | 40.4 % |
| cluster peripherals (with the barrier) | 13.81 | 2.6 % |
| others (what no rule names) | 0.02 | 0.0 % |

The run phase, `5_run` (574 cycles) against the idle `4_acc_config`:

| group | idle pJ/cycle | run pJ/cycle | run nJ | above idle nJ |
|---|---|---|---|---|
| TCDM banks (macros) | 0.0 | 25.5 | 14.65 | 14.65 |
| I-cache macros (data and tag) | 0.8 | 0.1 | 0.09 | -0.38 |
| accelerator datapath | 0.5 | 26.3 | 15.09 | 14.83 |
| accelerator control | 0.5 | 0.5 | 0.28 | 0.01 |
| accelerator csr (with its peripherals) | 1.0 | 1.0 | 0.55 | 0.00 |
| streamers | 46.8 | 47.2 | 27.10 | 0.26 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.7 | 1.6 | 0.89 | -0.11 |
| TCDM sparse interconnect | 1.5 | 13.1 | 7.54 | 6.66 |
| TCDM bank logic (AMO shims, muxes) | 20.6 | 26.4 | 15.15 | 3.35 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 60.7 | 61.0 | 35.02 | 0.17 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.7 | 19.8 | 11.35 | 0.05 |
| I-cache logic (the hive without its macros and mul/div) | 19.2 | 18.9 | 10.85 | -0.20 |
| AXI: the external cuts, both crossbars, the converters | 156.7 | 155.6 | 89.33 | -0.60 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 6.06 | 0.00 |
| others (what no rule names) | 0.0 | 0.0 | 0.01 | 0.00 |

HWCOST's energy (snax-forge `b29bf0c0`, stimulus rand64 seed 0) against the run phase; the shares are each side's of its own five parts:

| part | HWCOST nJ | share | run nJ | share | above idle nJ | share |
|---|---|---|---|---|---|---|
| datapath | 24.51 | 34.5 % | 15.09 | 23.3 % | 14.83 | 40.7 % |
| control | 0.26 | 0.4 % | 0.28 | 0.4 % | 0.01 | 0.0 % |
| streamers | 20.51 | 28.9 % | 27.10 | 41.9 % | 0.26 | 0.7 % |
| crossbar | 11.22 | 15.8 % | 7.54 | 11.7 % | 6.66 | 18.3 % |
| memory | 14.50 | 20.4 % | 14.65 | 22.7 % | 14.65 | 40.2 % |
| the five parts | 71.00 | | 64.65 | | 36.40 | |

The accelerator's shell in the run window against `done/dot/forge3_w4` alone (snax-forge `3c7ea005`, seed 0, X23's busy window):

| | cycles | pJ/cycle | nJ |
|---|---|---|---|
| in the cluster | 574 | 27.7 | 15.92 |
| alone | 513 | 48.0 | 24.65 |
### dot3_w8

Per window, pJ per cycle (internal + switching, leakage out):

| group | 1_dma_in | 2_dma_in | 3_streamer_config | 4_acc_config | 5_run | 6_dma_out |
|---|---|---|---|---|---|---|
| TCDM banks (macros) | 27.9 | 29.4 | 0.0 | 0.0 | 45.5 | 0.3 |
| I-cache macros (data and tag) | 0.2 | 0.1 | 2.7 | 0.8 | 0.3 | 2.0 |
| accelerator datapath | 0.5 | 0.5 | 0.5 | 0.5 | 46.3 | 0.5 |
| accelerator control | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| accelerator csr (with its peripherals) | 0.9 | 0.9 | 0.9 | 1.0 | 1.0 | 0.9 |
| streamers | 82.6 | 82.6 | 82.6 | 82.6 | 81.6 | 82.3 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.5 | 1.5 | 1.6 | 1.7 | 1.5 | 1.5 |
| TCDM sparse interconnect | 2.1 | 2.1 | 2.1 | 2.1 | 25.2 | 2.1 |
| TCDM bank logic (AMO shims, muxes) | 28.9 | 29.8 | 20.6 | 20.6 | 33.7 | 20.7 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 83.7 | 86.8 | 60.7 | 60.7 | 61.3 | 59.2 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.4 | 19.5 | 20.3 | 19.9 | 19.7 | 19.1 |
| I-cache logic (the hive without its macros and mul/div) | 18.8 | 18.9 | 19.1 | 19.2 | 18.9 | 18.2 |
| AXI: the external cuts, both crossbars, the converters | 171.4 | 174.7 | 154.7 | 156.7 | 155.3 | 154.1 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 10.5 | 10.6 | 10.6 | 10.6 |
| others (what no rule names) | 0.0 | 0.0 | 0.0 | 0.1 | 0.0 | 0.0 |
| total | 448.9 | 457.8 | 376.8 | 376.7 | 501.3 | 372.1 |
| cycles | 305 | 291 | 33 | 14 | 322 | 90 |
| window nJ | 136.93 | 133.21 | 12.44 | 5.27 | 161.43 | 33.48 |

The span: 1055 cycles, 482.75 nJ.

| group | nJ | share |
|---|---|---|
| TCDM banks (macros) | 31.75 | 6.6 % |
| I-cache macros (data and tag) | 0.47 | 0.1 % |
| accelerator datapath | 15.24 | 3.2 % |
| accelerator control | 0.50 | 0.1 % |
| accelerator csr (with its peripherals) | 0.99 | 0.2 % |
| streamers | 86.76 | 18.0 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.58 | 0.3 % |
| TCDM sparse interconnect | 9.64 | 2.0 % |
| TCDM bank logic (AMO shims, muxes) | 31.19 | 6.5 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 78.70 | 16.3 % |
| RISC-V cores (Snitch, with the shared mul/div) | 20.62 | 4.3 % |
| I-cache logic (the hive without its macros and mul/div) | 19.85 | 4.1 % |
| AXI: the external cuts, both crossbars, the converters | 174.30 | 36.1 % |
| cluster peripherals (with the barrier) | 11.15 | 2.3 % |
| others (what no rule names) | 0.02 | 0.0 % |

The run phase, `5_run` (322 cycles) against the idle `4_acc_config`:

| group | idle pJ/cycle | run pJ/cycle | run nJ | above idle nJ |
|---|---|---|---|---|
| TCDM banks (macros) | 0.0 | 45.5 | 14.65 | 14.65 |
| I-cache macros (data and tag) | 0.8 | 0.3 | 0.09 | -0.18 |
| accelerator datapath | 0.5 | 46.3 | 14.91 | 14.76 |
| accelerator control | 0.5 | 0.5 | 0.16 | 0.00 |
| accelerator csr (with its peripherals) | 1.0 | 1.0 | 0.31 | 0.00 |
| streamers | 82.6 | 81.6 | 26.28 | -0.31 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.7 | 1.5 | 0.50 | -0.05 |
| TCDM sparse interconnect | 2.1 | 25.2 | 8.10 | 7.43 |
| TCDM bank logic (AMO shims, muxes) | 20.6 | 33.7 | 10.87 | 4.25 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 60.7 | 61.3 | 19.73 | 0.19 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.9 | 19.7 | 6.36 | -0.05 |
| I-cache logic (the hive without its macros and mul/div) | 19.2 | 18.9 | 6.07 | -0.13 |
| AXI: the external cuts, both crossbars, the converters | 156.7 | 155.3 | 50.01 | -0.44 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 3.40 | 0.00 |
| others (what no rule names) | 0.1 | 0.0 | 0.01 | -0.01 |

HWCOST's energy (snax-forge `b29bf0c0`, stimulus rand64 seed 0) against the run phase; the shares are each side's of its own five parts:

| part | HWCOST nJ | share | run nJ | share | above idle nJ | share |
|---|---|---|---|---|---|---|
| datapath | 24.25 | 34.4 % | 14.91 | 23.3 % | 14.76 | 40.4 % |
| control | 0.13 | 0.2 % | 0.16 | 0.2 % | 0.00 | 0.0 % |
| streamers | 20.31 | 28.8 % | 26.28 | 41.0 % | -0.31 | -0.8 % |
| crossbar | 11.22 | 15.9 % | 8.10 | 12.6 % | 7.43 | 20.3 % |
| memory | 14.50 | 20.6 % | 14.65 | 22.9 % | 14.65 | 40.1 % |
| the five parts | 70.41 | | 64.09 | | 36.53 | |

The accelerator's shell in the run window against `done/dot/forge3_w8` alone (snax-forge `3c7ea005`, seed 0, X23's busy window):

| | cycles | pJ/cycle | nJ |
|---|---|---|---|
| in the cluster | 322 | 47.7 | 15.37 |
| alone | 257 | 92.7 | 23.83 |
### dot3_w2

Per window, pJ per cycle (internal + switching, leakage out):

| group | 1_dma_in | 2_dma_in | 3_streamer_config | 4_acc_config | 5_run | 6_dma_out |
|---|---|---|---|---|---|---|
| TCDM banks (macros) | 27.9 | 29.4 | 0.0 | 0.0 | 13.5 | 0.4 |
| I-cache macros (data and tag) | 0.2 | 0.1 | 2.8 | 1.0 | 0.1 | 1.9 |
| accelerator datapath | 0.5 | 0.5 | 0.5 | 0.5 | 14.5 | 0.5 |
| accelerator control | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| accelerator csr (with its peripherals) | 0.9 | 0.9 | 0.9 | 1.0 | 1.0 | 0.9 |
| streamers | 28.8 | 28.8 | 28.9 | 28.9 | 29.4 | 28.8 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.5 | 1.5 | 1.6 | 1.8 | 1.6 | 1.5 |
| TCDM sparse interconnect | 1.1 | 1.1 | 1.1 | 1.1 | 7.0 | 1.2 |
| TCDM bank logic (AMO shims, muxes) | 29.0 | 29.8 | 20.6 | 20.6 | 23.3 | 20.7 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 83.7 | 86.8 | 60.7 | 60.7 | 60.9 | 58.9 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.7 | 19.7 | 20.3 | 20.2 | 20.0 | 19.4 |
| I-cache logic (the hive without its macros and mul/div) | 18.8 | 18.9 | 19.1 | 19.6 | 18.9 | 18.4 |
| AXI: the external cuts, both crossbars, the converters | 171.4 | 174.7 | 154.8 | 156.9 | 155.9 | 154.6 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 10.5 | 10.6 | 10.6 | 10.6 |
| others (what no rule names) | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| total | 394.5 | 403.3 | 322.3 | 323.3 | 357.1 | 318.2 |
| cycles | 305 | 291 | 32 | 11 | 1085 | 77 |
| window nJ | 120.33 | 117.37 | 10.31 | 3.56 | 387.41 | 24.50 |

The span: 1801 cycles, 663.48 nJ.

| group | nJ | share |
|---|---|---|
| TCDM banks (macros) | 31.75 | 4.8 % |
| I-cache macros (data and tag) | 0.43 | 0.1 % |
| accelerator datapath | 16.09 | 2.4 % |
| accelerator control | 0.87 | 0.1 % |
| accelerator csr (with its peripherals) | 1.71 | 0.3 % |
| streamers | 52.57 | 7.9 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 2.75 | 0.4 % |
| TCDM sparse interconnect | 8.36 | 1.3 % |
| TCDM bank logic (AMO shims, muxes) | 45.25 | 6.8 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 123.97 | 18.7 % |
| RISC-V cores (Snitch, with the shared mul/div) | 35.81 | 5.4 % |
| I-cache logic (the hive without its macros and mul/div) | 34.05 | 5.1 % |
| AXI: the external cuts, both crossbars, the converters | 290.83 | 43.8 % |
| cluster peripherals (with the barrier) | 19.02 | 2.9 % |
| others (what no rule names) | 0.03 | 0.0 % |

The run phase, `5_run` (1085 cycles) against the idle `4_acc_config`:

| group | idle pJ/cycle | run pJ/cycle | run nJ | above idle nJ |
|---|---|---|---|---|
| TCDM banks (macros) | 0.0 | 13.5 | 14.65 | 14.65 |
| I-cache macros (data and tag) | 1.0 | 0.1 | 0.09 | -1.05 |
| accelerator datapath | 0.5 | 14.5 | 15.76 | 15.26 |
| accelerator control | 0.5 | 0.5 | 0.53 | 0.01 |
| accelerator csr (with its peripherals) | 1.0 | 1.0 | 1.04 | 0.00 |
| streamers | 28.9 | 29.4 | 31.93 | 0.62 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.8 | 1.6 | 1.70 | -0.26 |
| TCDM sparse interconnect | 1.1 | 7.0 | 7.54 | 6.31 |
| TCDM bank logic (AMO shims, muxes) | 20.6 | 23.3 | 25.28 | 2.97 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 60.7 | 60.9 | 66.03 | 0.15 |
| RISC-V cores (Snitch, with the shared mul/div) | 20.2 | 20.0 | 21.72 | -0.19 |
| I-cache logic (the hive without its macros and mul/div) | 19.6 | 18.9 | 20.55 | -0.75 |
| AXI: the external cuts, both crossbars, the converters | 156.9 | 155.9 | 169.14 | -1.06 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 11.45 | 0.00 |
| others (what no rule names) | 0.0 | 0.0 | 0.02 | 0.00 |

HWCOST's energy (snax-forge `b29bf0c0`, stimulus rand64 seed 0) against the run phase; the shares are each side's of its own five parts:

| part | HWCOST nJ | share | run nJ | share | above idle nJ | share |
|---|---|---|---|---|---|---|
| datapath | 25.31 | 34.9 % | 15.76 | 22.4 % | 15.26 | 41.4 % |
| control | 0.52 | 0.7 % | 0.53 | 0.8 % | 0.01 | 0.0 % |
| streamers | 20.92 | 28.9 % | 31.93 | 45.3 % | 0.62 | 1.7 % |
| crossbar | 11.22 | 15.5 % | 7.54 | 10.7 % | 6.31 | 17.1 % |
| memory | 14.50 | 20.0 % | 14.65 | 20.8 % | 14.65 | 39.7 % |
| the five parts | 72.47 | | 70.40 | | 36.85 | |

The accelerator's shell in the run window against `done/dot/forge3_w2` alone (snax-forge `3c7ea005`, seed 0, X23's busy window):

| | cycles | pJ/cycle | nJ |
|---|---|---|---|
| in the cluster | 1085 | 16.0 | 17.33 |
| alone | 1025 | 25.5 | 26.17 |
### dot3_w32

Per window, pJ per cycle (internal + switching, leakage out):

| group | 1_dma_in | 2_dma_in | 3_streamer_config | 4_acc_config | 5_run | 6_dma_out |
|---|---|---|---|---|---|---|
| TCDM banks (macros) | 27.9 | 29.4 | 0.0 | 0.0 | 77.1 | 0.3 |
| I-cache macros (data and tag) | 0.2 | 0.1 | 2.7 | 0.8 | 0.5 | 2.0 |
| accelerator datapath | 0.5 | 0.5 | 0.5 | 0.5 | 119.1 | 0.5 |
| accelerator control | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| accelerator csr (with its peripherals) | 0.9 | 0.9 | 0.9 | 1.0 | 1.0 | 0.9 |
| streamers | 297.4 | 297.4 | 297.5 | 297.4 | 261.1 | 296.4 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.5 | 1.5 | 1.7 | 1.7 | 1.5 | 1.5 |
| TCDM sparse interconnect | 4.5 | 4.5 | 4.5 | 4.5 | 97.8 | 4.7 |
| TCDM bank logic (AMO shims, muxes) | 29.0 | 29.8 | 20.6 | 20.6 | 32.4 | 20.7 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 83.7 | 86.8 | 60.7 | 60.7 | 61.7 | 59.2 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.4 | 19.5 | 20.2 | 19.7 | 19.7 | 19.1 |
| I-cache logic (the hive without its macros and mul/div) | 18.8 | 18.9 | 19.1 | 19.2 | 18.8 | 18.2 |
| AXI: the external cuts, both crossbars, the converters | 171.4 | 174.7 | 154.7 | 156.7 | 154.9 | 154.1 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 10.5 | 10.6 | 10.6 | 10.6 |
| others (what no rule names) | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| total | 666.3 | 675.1 | 594.1 | 593.8 | 856.6 | 588.8 |
| cycles | 305 | 291 | 33 | 14 | 190 | 90 |
| window nJ | 203.21 | 196.45 | 19.60 | 8.31 | 162.76 | 52.99 |

The span: 923 cycles, 643.33 nJ.

| group | nJ | share |
|---|---|---|
| TCDM banks (macros) | 31.75 | 4.9 % |
| I-cache macros (data and tag) | 0.47 | 0.1 % |
| accelerator datapath | 22.97 | 3.6 % |
| accelerator control | 0.45 | 0.1 % |
| accelerator csr (with its peripherals) | 0.87 | 0.1 % |
| streamers | 267.54 | 41.6 % |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.37 | 0.2 % |
| TCDM sparse interconnect | 21.92 | 3.4 % |
| TCDM bank logic (AMO shims, muxes) | 26.48 | 4.1 % |
| DMA (iDMA, its AXI-to-memory and interconnect) | 70.68 | 11.0 % |
| RISC-V cores (Snitch, with the shared mul/div) | 18.00 | 2.8 % |
| I-cache logic (the hive without its macros and mul/div) | 17.35 | 2.7 % |
| AXI: the external cuts, both crossbars, the converters | 153.72 | 23.9 % |
| cluster peripherals (with the barrier) | 9.75 | 1.5 % |
| others (what no rule names) | 0.01 | 0.0 % |

The run phase, `5_run` (190 cycles) against the idle `4_acc_config`:

| group | idle pJ/cycle | run pJ/cycle | run nJ | above idle nJ |
|---|---|---|---|---|
| TCDM banks (macros) | 0.0 | 77.1 | 14.65 | 14.65 |
| I-cache macros (data and tag) | 0.8 | 0.5 | 0.09 | -0.07 |
| accelerator datapath | 0.5 | 119.1 | 22.63 | 22.55 |
| accelerator control | 0.5 | 0.5 | 0.10 | 0.01 |
| accelerator csr (with its peripherals) | 1.0 | 1.0 | 0.18 | 0.00 |
| streamers | 297.4 | 261.1 | 49.61 | -6.90 |
| SNAX CSR path (the cores' translators, the accelerator wrapper's demux and glue) | 1.7 | 1.5 | 0.29 | -0.04 |
| TCDM sparse interconnect | 4.5 | 97.8 | 18.59 | 17.72 |
| TCDM bank logic (AMO shims, muxes) | 20.6 | 32.4 | 6.15 | 2.25 |
| DMA (iDMA, its AXI-to-memory and interconnect) | 60.7 | 61.7 | 11.72 | 0.18 |
| RISC-V cores (Snitch, with the shared mul/div) | 19.7 | 19.7 | 3.74 | 0.01 |
| I-cache logic (the hive without its macros and mul/div) | 19.2 | 18.8 | 3.57 | -0.08 |
| AXI: the external cuts, both crossbars, the converters | 156.7 | 154.9 | 29.43 | -0.34 |
| cluster peripherals (with the barrier) | 10.6 | 10.6 | 2.01 | 0.00 |
| others (what no rule names) | 0.0 | 0.0 | 0.00 | 0.00 |

HWCOST's energy (snax-forge `b29bf0c0`, stimulus rand64 seed 0) against the run phase; the shares are each side's of its own five parts:

| part | HWCOST nJ | share | run nJ | share | above idle nJ | share |
|---|---|---|---|---|---|---|
| datapath | 24.01 | 34.3 % | 22.63 | 21.4 % | 22.55 | 46.9 % |
| control | 0.03 | 0.0 % | 0.10 | 0.1 % | 0.01 | 0.0 % |
| streamers | 20.17 | 28.8 % | 49.61 | 47.0 % | -6.90 | -14.4 % |
| crossbar | 11.22 | 16.1 % | 18.59 | 17.6 % | 17.72 | 36.9 % |
| memory | 14.50 | 20.7 % | 14.65 | 13.9 % | 14.65 | 30.5 % |
| the five parts | 69.93 | | 105.58 | | 48.03 | |

The accelerator's shell in the run window against `done/dot/forge3_w32` alone (snax-forge `b29bf0c0`, seed 0, X23's busy window):

| | cycles | pJ/cycle | nJ |
|---|---|---|---|
| in the cluster | 190 | 120.6 | 22.91 |
| alone | 65 | 357.4 | 23.23 |

