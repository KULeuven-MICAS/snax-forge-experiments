import re
from pathlib import Path
T = Path("tmp/csyn2-r4")
note = (T / "note_template.md").read_text()
times = (T / "times.md").read_text().strip()
t_tab, c_tab = times.split("\n\n| point | snax-forge-experiments")
bt = (T / "batchtable.md").read_text()
gls = "### gls" + bt.split("### gls")[1].split("### pwr")[0].rstrip() + "\n\nRAMCOUNT as at every R2 point: +1 write on the 4 I-cache macro instances, +1 read on 8 TCDM banks (PITFALLS Q14), 36 lines."
pwr = "### pwr" + bt.split("### pwr")[1].rstrip()
pwr = pwr.replace("### pwr\n", "### pwr\n\nThe program window's cycles against the point's quiet run on the RTL (`windows_ref`, X108) and PT's numbers from `power_pt.csv`: `e_dyn` the dynamic energy per cycle (internal + switching, the macros as PT measures them), the window's nJ `e_win`. The leakage line is the top's `Leak` column of `power_hierarchy.rpt` in the window, beside its dynamic power, never summed.\n", 1)
pwr = re.sub(r"(part 2 PASS, PT threads[^\n]*)\n(PT's macros)", r"\1\n\n\2", pwr)
pwr = re.sub(r"(\nRun windows [^\n]*)\n(PT's top)", r"\1\n\n\2", pwr)
paper = (T / "paperdiff.md").read_text()
tabs = (T / "paperdiff.md").read_text().split("| id | ")[1:]
tabs = ["| id | " + "\n".join(l for i, l in enumerate(t.splitlines()) if i == 0 or l.startswith("|")) for t in tabs]
paper = "forms.csv:\n\n" + tabs[0] + "\n\nlimits.csv:\n\n" + tabs[1]
sub = {"{{COMMITS}}": ("| point | snax-forge-experiments" + c_tab).strip(), "{{PRE}}": (T / "pretable.md").read_text().split("\n\n")[0].strip(),
       "{{TIMES}}": t_tab.strip(), "{{GLS}}": gls, "{{PWR}}": pwr, "{{PAPER}}": paper,
       "{{LOAD_END}}": "3.94", "{{QUOTA_END}}": "1319630 files and 98.0 GB", "{{ARC}}": "arc check: nothing left over"}
for k, v in sub.items():
    assert k in note, k
    note = note.replace(k, v)
assert "{{" not in note
Path("results/cluster/runs/2026-11-27_csyn2_r4b.md").write_text(note)
print(len(note.splitlines()), "lines")
