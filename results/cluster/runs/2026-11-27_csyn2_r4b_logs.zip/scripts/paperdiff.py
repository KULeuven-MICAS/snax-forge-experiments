"""Rows and columns of the paper CSVs that moved; the run columns of the rows asked for, before and after."""
import csv, sys
from pathlib import Path
F = Path("../snax-forge/paper/data")
B = Path("tmp/csyn2-r4/paper_before")
SHOW = ("cycles", "dynamic_nj", "leak_design_nj", "leak_core_nj", "leak_rest_nj", "idle_nj", "passed")
for name, want in (("forms.csv", sys.argv[1].split(",")), ("limits.csv", sys.argv[2].split(","))):
    old = list(csv.DictReader(open(B / name, newline="")))
    new = list(csv.DictReader(open(F / name, newline="")))
    hdr_same = list(old[0]) == list(new[0])
    o, n = {r["id"]: r for r in old}, {r["id"]: r for r in new}
    print(f"== {name}: {len(old)} rows before, {len(new)} after; header same {hdr_same}; order same {[r['id'] for r in old] == [r['id'] for r in new]}")
    moved = {i: sorted(k for k in n[i] if o.get(i, {}).get(k) != n[i][k]) for i in n if o.get(i) != n[i]}
    others = [i for i in moved if i not in want]
    print(f"  rows moved: {len(moved)}; outside the asked ids: {others or 'none'}; asked ids unmoved: {[i for i in want if i not in moved] or 'none'}")
    cols = sorted({c for v in moved.values() for c in v})
    print(f"  columns that moved: {cols}")
    print("| id | " + " | ".join(f"{c} before / after" for c in SHOW) + " |")
    print("|---|" + "---:|" * len(SHOW))
    for i in want:
        print(f"| `{i}` | " + " | ".join(f"{o[i][c]} / {n[i][c]}" if o[i][c] != n[i][c] else f"{n[i][c]} (=)" for c in SHOW) + " |")
