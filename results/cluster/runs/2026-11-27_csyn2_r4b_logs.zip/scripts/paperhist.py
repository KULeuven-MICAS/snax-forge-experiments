import csv, io, subprocess, sys
for rev in ("3c4d4bc0", "b5e16549"):
    t = subprocess.run(["git", "show", f"{rev}:paper/data/forms.csv"], capture_output=True, text=True).stdout
    rows = {r["id"]: r for r in csv.DictReader(io.StringIO(t))}
    for i in ("mvt_column_pipeline", "bicg_two_pass_pipeline", "gesummv_factor_out_pipeline"):
        r = rows.get(i, {})
        print(rev, i, r.get("cycles"), r.get("dynamic_nj"), r.get("dynamic_streamers_nj"), r.get("dynamic_crossbar_nj"))
