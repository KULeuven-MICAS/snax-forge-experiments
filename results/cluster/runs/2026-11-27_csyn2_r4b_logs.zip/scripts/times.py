"""Step times (status.txt of both batches, DC's own elapsed) and the commits per point, as Markdown."""
import csv, json, re, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
pts = sys.argv[1:]
t = {}
for f in ("tmp/csyn2-r4/status.txt",):
    for ln in open(ROOT / f):
        x = ln.split()
        if len(x) == 5 and x[3] in ("PASS", "FAIL"):
            t[(x[1], x[2])] = (x[3], int(x[4]))
rows = {r["point"]: r for r in csv.DictReader(open(ROOT / "results/cluster/nangate45/synth_dc.csv", newline=""))}
print("| point | rtl | syn (DC) | gls | pwr | total |")
print("|---|---:|---:|---:|---:|---:|")
grand = 0
for p in pts:
    cells, tot = [], 0
    for s in ("rtl", "syn", "gls", "pwr"):
        st, sec = t.get((p, s), ("-", 0))
        tot += sec
        c = f"{sec:,}" + ("" if st == "PASS" else f" {st}")
        if s == "syn":
            z = ROOT / "syn/runs/cluster/nangate45" / f"{p}.zip"
            log = arc.read(z, "logs/dc_shell.log").decode(errors="replace") if z.is_file() else ""
            m = re.search(r"Elapsed time for this session (\d+) seconds", log)
            c += f" ({int(m.group(1)):,})" if m else ""
        cells.append(c)
    grand += tot
    print(f"| `{p}` | " + " | ".join(cells) + f" | {tot:,} ({tot / 60:.0f} min) |")
print(f"\nTotal {grand:,} s ({grand / 3600:.2f} h).\n")
print("| point | snax-forge-experiments | snax_cluster (rtl, syn, gls, pwr) | snax-forge (bundle, `dirty`) | forge.elf sha256 | forge_quiet.elf sha256 |")
print("|---|---|---|---|---|---|")
for p in pts:
    z = ROOT / "sim/runs/cluster/nangate45" / f"{p}.zip"
    sc = []
    for m in ("rtl/check.json", "gls/check.json", "pwr/check.json"):
        if arc.has(z, m):
            sc.append(json.loads(arc.read(z, m))["snax_cluster_commit"][:8])
    sc.insert(1, rows.get(p, {}).get("snax_cluster_commit", "")[:8] or "adopted, no DC")
    pw = json.loads(arc.read(z, "pwr/check.json")) if arc.has(z, "pwr/check.json") else {}
    prov = json.loads(arc.read(ROOT / "rtl/cluster" / f"{p}.zip", "provenance.json"))
    print(f"| `{p}` | `{(pw.get('snax_forge_experiments_commit') or '')[:8]}` | {', '.join(f'`{c}`' for c in sc)} | "
          f"`{prov['snax_forge_commit'][:8]}`, {str(prov.get('snax_forge_dirty')).lower()} | `{prov['elf_sha256'][:16]}` | `{prov['quiet_elf_sha256'][:16]}` |")
