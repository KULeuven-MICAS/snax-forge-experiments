| point | rtl | syn (DC) | gls | pwr | total |
|---|---:|---:|---:|---:|---:|
| `mvt_column_pipeline_cg` | 229 | 4 | 202 | 265 | 700 (12 min) |
| `bicg_two_pass_pipeline_cg` | 224 | 2 | 191 | 250 | 667 (11 min) |
| `bicg_pipeline_contiguous_w8_cg` | 249 | 3 | 250 | 410 | 912 (15 min) |

Total 2,279 s (0.63 h).

| point | snax-forge-experiments | snax_cluster (rtl, syn, gls, pwr) | snax-forge (bundle, `dirty`) | forge.elf sha256 | forge_quiet.elf sha256 |
|---|---|---|---|---|---|
| `mvt_column_pipeline_cg` | `cd3ad804` | `baf87858`, `adopted, no DC`, `baf87858`, `baf87858` | `b5e16549`, false | `6b2197d194d72ddc` | `fb7d1640c3311265` |
| `bicg_two_pass_pipeline_cg` | `cd3ad804` | `baf87858`, `adopted, no DC`, `baf87858`, `baf87858` | `b5e16549`, false | `a1c92e4eec63b4b1` | `daa5ebb1518b7be7` |
| `bicg_pipeline_contiguous_w8_cg` | `cd3ad804` | `baf87858`, `adopted, no DC`, `baf87858`, `baf87858` | `b5e16549`, false | `8d9429342a23555f` | `7476f8d5ee6808e9` |
