### syn

| point | status | area µm² | comb µm² | seq µm² | macro µm² | cells | seq cells | slack ns | gated registers | ungated | clock-gating elements | macros | DC s | DC cores |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|
| `mvt_column_pipeline_cg` | adopts `mvt_column_cg`'s netlist (`51e93a2e3682`), no DC | | | | | | | | | | | | | |
| `bicg_two_pass_pipeline_cg` | adopts `bicg_two_pass_cg`'s netlist (`2cc77dc7a969`), no DC | | | | | | | | | | | | | |
| `bicg_pipeline_contiguous_w8_cg` | adopts `bicg_sequential_contiguous_w8_cg`'s netlist (`f7ae6227e725`), no DC | | | | | | | | | | | | | |

The macros' `.db` (X107):


Adoption: `mvt_column_pipeline_cg` → `mvt_column_cg`: {"point": "mvt_column_pipeline_cg", "netlist_of": "mvt_column_cg", "netlist_sha256": "51e93a2e36829f2348c9d606f17bf2356ba228ef571a421670d494e464787b75", "hardware_members": 23, "date": "2026-11-27T12:07:14"}

Adoption: `bicg_two_pass_pipeline_cg` → `bicg_two_pass_cg`: {"point": "bicg_two_pass_pipeline_cg", "netlist_of": "bicg_two_pass_cg", "netlist_sha256": "2cc77dc7a9690e68f102dbd6f85180b5635e9c6862cf6c8b520e175186d97666", "hardware_members": 22, "date": "2026-11-27T12:15:04"}

Adoption: `bicg_pipeline_contiguous_w8_cg` → `bicg_sequential_contiguous_w8_cg`: {"point": "bicg_pipeline_contiguous_w8_cg", "netlist_of": "bicg_sequential_contiguous_w8_cg", "netlist_sha256": "f7ae6227e7259fe62154f42c76aa351976fb7b63f8eba3427c83c2e1ec9bb951", "hardware_members": 20, "date": "2026-11-27T12:22:28"}

### gls

| point | status | data | cycles RTL / netlist (e) | counters RTL / netlist (e) | swap | success | D123 (reported) | RAMCOUNT (reported) | Questa s (vlog netlist, vopt, run) |
|---|---|---|---:|---|---|---|---|---|---|
| `mvt_column_pipeline_cg` | PASS | PASS | 913 / 913 (+0.0 %) | tmp1_mult_mvt 525 / 525 (+0.0 %); tmp4_mult_mac_x2 531 / 531 (+0.0 %) | PASS | PASS | PASS (tmp1_mult_mvt: counter 525 against 531, 3 beyond its fill 3 (0.6 %, NEAR); tmp4_mult_mac_x2: counter 531 against 537, 3 beyond its fill 3 (0.6 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 15, 23, 37 |
| `bicg_two_pass_pipeline_cg` | PASS | PASS | 875 / 875 (+0.0 %) | q_mult_matvec 529 / 529 (+0.0 %); s_mult_mac 534 / 534 (+0.0 %) | PASS | PASS | PASS (q_mult_matvec: counter 529 against 530, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 12, 22, 33 |
| `bicg_pipeline_contiguous_w8_cg` | PASS | PASS | 1,614 / 1,614 (+0.0 %) | q_mult_matvec 844 / 844 (+0.0 %); s_mult_mac 734 / 734 (+0.0 %) | PASS | PASS | PASS (q_mult_matvec: counter 844 against 843, within its fill 3; s_mult_mac: counter 734 against 737, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 17, 30, 83 |

### pwr

`mvt_column_pipeline_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 27.4 cores free (nproc 32, load 4.6))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | run | program window | 891 | 891 | 0 | 74.0 | 65.96 | 100.00 % |

Run windows 65.96 nJ (891 cycles); span 65.96 nJ (891 cycles).
PT's top in `1_run` (power_hierarchy.rpt, units W): leakage 8,833.2 µW; dynamic (int + switch) 7,402.7 µW, kept apart.

`bicg_two_pass_pipeline_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 28.2 cores free (nproc 32, load 3.8))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | run | program window | 850 | 850 | 0 | 72.2 | 61.33 | 100.00 % |

Run windows 61.33 nJ (850 cycles); span 61.33 nJ (850 cycles).
PT's top in `1_run` (power_hierarchy.rpt, units W): leakage 8,118.7 µW; dynamic (int + switch) 7,215.2 µW, kept apart.

`bicg_pipeline_contiguous_w8_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 27.6 cores free (nproc 32, load 4.5))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | run | program window | 1,580 | 1,580 | 0 | 238.0 | 375.97 | 100.00 % |

Run windows 375.97 nJ (1,580 cycles); span 375.97 nJ (1,580 cycles).
PT's top in `1_run` (power_hierarchy.rpt, units W): leakage 13,402.1 µW; dynamic (int + switch) 23,795.8 µW, kept apart.

