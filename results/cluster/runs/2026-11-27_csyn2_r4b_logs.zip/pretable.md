| point | status | data | D123 plain | D123 macro | quiet success | quiet windows worst | quiet span RTL / SNAX-GVSoC / default build plain, macro | SNAX-GVSoC, same_quiet_elf | s |
|---|---|---|---|---|---|---|---|---|---:|
| `mvt_column_pipeline_cg` | PASS | PASS | PASS (tmp1_mult_mvt: counter 525 against 531, 3 beyond its fill 3 (0.6 %, NEAR); tmp4_mult_mac_x2: counter 531 against 537, 3 beyond its fill 3 (0.6 %, NEAR)) | PASS (tmp1_mult_mvt: counter 525 against 531, 3 beyond its fill 3 (0.6 %, NEAR); tmp4_mult_mac_x2: counter 531 against 537, 3 beyond its fill 3 (0.6 %, NEAR)) | True | OK | 891 / 909 / 913, 913 | PASS, True | 221.2 |
| `bicg_two_pass_pipeline_cg` | PASS | PASS | PASS (q_mult_matvec: counter 529 against 530, within its fill 3) | PASS (q_mult_matvec: counter 529 against 530, within its fill 3) | True | OK | 850 / 853 / 875, 875 | PASS, True | 215.8 |
| `bicg_pipeline_contiguous_w8_cg` | PASS | PASS | PASS (q_mult_matvec: counter 844 against 843, within its fill 3; s_mult_mac: counter 734 against 737, within its fill 3) | PASS (q_mult_matvec: counter 844 against 843, within its fill 3; s_mult_mac: counter 734 against 737, within its fill 3) | True | OK | 1580 / 1561 / 1614, 1614 | PASS, True | 241.7 |

| point | mark | kind | RTL | SNAX-GVSoC | gap | verdict |
|---|---:|---|---:|---:|---:|---|

