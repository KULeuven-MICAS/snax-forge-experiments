== forms.csv: 21 rows before, 21 after; header same True; order same True
  rows moved: 2; outside the asked ids: none; asked ids unmoved: ['bicg_two_pass_pipeline']
  columns that moved: ['dynamic_control_nj', 'dynamic_crossbar_nj', 'dynamic_nj', 'dynamic_streamers_nj']
| id | cycles before / after | dynamic_nj before / after | leak_design_nj before / after | leak_core_nj before / after | leak_rest_nj before / after | idle_nj before / after | passed before / after |
|---|---:|---:|---:|---:|---:|---:|---:|
| `mvt_column_pipeline` | 904 (=) | 26.5751 / 26.5645 | 38.2498 (=) | 7.6607 (=) | 36.314 (=) | 21.334 (=) | True (=) |
| `bicg_two_pass_pipeline` | 861 (=) | 25.9283 (=) | 29.2186 (=) | 7.2963 (=) | 34.5867 (=) | 20.3192 (=) | True (=) |
| `gesummv_factor_out_pipeline` | 912 (=) | 32.4001 / 32.401 | 50.1816 (=) | 7.7285 (=) | 36.6353 (=) | 21.5228 (=) | True (=) |
== limits.csv: 36 rows before, 36 after; header same True; order same True
  rows moved: 12; outside the asked ids: none; asked ids unmoved: none
  columns that moved: ['dynamic_control_nj', 'dynamic_crossbar_nj', 'dynamic_nj', 'dynamic_streamers_nj']
| id | cycles before / after | dynamic_nj before / after | leak_design_nj before / after | leak_core_nj before / after | leak_rest_nj before / after | idle_nj before / after | passed before / after |
|---|---:|---:|---:|---:|---:|---:|---:|
| `bicg_pipeline_contiguous_banks16` | 1741 (=) | 291.8958 / 289.8205 | 139.0443 (=) | 14.7536 (=) | 69.9365 (=) | 41.0868 (=) | True (=) |
| `bicg_pipeline_contiguous_banks64` | 1549 (=) | 236.7565 / 240.5044 | 197.5521 (=) | 13.1266 (=) | 62.2238 (=) | 36.5557 (=) | True (=) |
| `bicg_pipeline_contiguous_w16` | 1207 (=) | 248.9916 / 248.1799 | 212.6543 (=) | 10.2284 (=) | 48.4856 (=) | 28.4847 (=) | True (=) |
| `bicg_pipeline_contiguous_w32` | 1099 (=) | 309.65 / 307.6901 | 371.0402 (=) | 9.3132 (=) | 44.1472 (=) | 25.9359 (=) | True (=) |
| `bicg_pipeline_contiguous_w4` | 2143 (=) | 228.719 / 229.0904 | 124.7925 (=) | 18.1603 (=) | 86.085 (=) | 50.5738 (=) | True (=) |
| `bicg_pipeline_contiguous_w8` | 1561 (=) | 241.3506 / 241.4259 | 151.6954 (=) | 13.2283 (=) | 62.7059 (=) | 36.8389 (=) | True (=) |
| `bicg_pipeline_padded_banks16` | 1685 (=) | 278.5577 / 278.5464 | 134.5719 (=) | 14.2791 (=) | 67.687 (=) | 39.7652 (=) | True (=) |
| `bicg_pipeline_padded_banks64` | 1364 (=) | 233.0427 / 231.7765 | 173.9581 (=) | 11.5588 (=) | 54.7923 (=) | 32.1898 (=) | True (=) |
| `bicg_pipeline_padded_w16` | 1222 (=) | 241.7649 / 242.091 | 215.297 (=) | 10.3555 (=) | 49.0881 (=) | 28.8386 (=) | True (=) |
| `bicg_pipeline_padded_w32` | 1108 (=) | 304.3074 / 303.2929 | 374.0787 (=) | 9.3894 (=) | 44.5087 (=) | 26.1483 (=) | True (=) |
| `bicg_pipeline_padded_w4` | 1945 (=) | 221.3349 / 222.0011 | 113.2624 (=) | 16.4824 (=) | 78.1313 (=) | 45.9011 (=) | True (=) |
| `bicg_pipeline_padded_w8` | 1463 (=) | 224.8692 / 224.3951 | 142.1719 (=) | 12.3978 (=) | 58.7692 (=) | 34.5261 (=) | True (=) |
