set -x
cd /users/micas/rantonio/no_backup/kul_main/snax-forge
git config --global --add safe.directory '*'
pixi run test-lower > /users/micas/rantonio/no_backup/kul_main/snax-forge-experiments/tmp/csyn2-r4/test_lower.log 2>&1; echo "rc=$?" >> /users/micas/rantonio/no_backup/kul_main/snax-forge-experiments/tmp/csyn2-r4/test_lower.log
pixi run -e ci pytest -q tests/flow/test_energy.py -m gvsoc > /users/micas/rantonio/no_backup/kul_main/snax-forge-experiments/tmp/csyn2-r4/test_energy.log 2>&1; echo "rc=$?" >> /users/micas/rantonio/no_backup/kul_main/snax-forge-experiments/tmp/csyn2-r4/test_energy.log
