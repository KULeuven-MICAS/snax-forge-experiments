import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "arc"))
import arc
z = Path(sys.argv[1])
if len(sys.argv) == 2:
    print("\n".join(arc.names(z)))
else:
    t = arc.read(z, sys.argv[2]).decode(errors="replace").splitlines()
    a, b = (int(x) for x in sys.argv[3].split(":")) if len(sys.argv) > 3 else (0, 60)
    print("\n".join(t[a:b]))
