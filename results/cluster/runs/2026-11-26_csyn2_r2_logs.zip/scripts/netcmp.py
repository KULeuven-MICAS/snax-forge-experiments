import csv, difflib, hashlib, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
M = "out/snax_forge_cluster_wrapper_mapped.v"
a, b = sys.argv[1:3]
na, nb = (arc.read(ROOT / "syn/runs/cluster/nangate45" / f"{p}.zip", M) for p in (a, b))
print(f"{a}: {len(na):,} bytes sha256 {hashlib.sha256(na).hexdigest()}")
print(f"{b}: {len(nb):,} bytes sha256 {hashlib.sha256(nb).hexdigest()}")
la, lb = na.decode().splitlines(), nb.decode().splitlines()
d = [l for l in difflib.unified_diff(la, lb, a, b, n=0, lineterm="") if not l.startswith(("---", "+++", "@@"))]
print(f"lines {len(la):,} / {len(lb):,}; differing lines {len(d)}")
print("\n".join(d[:10]))
rows = {r["point"]: r for r in csv.DictReader(open(ROOT / "results/cluster/nangate45/synth_dc.csv", newline=""))}
for k in ("area_um2", "comb_area_um2", "seq_area_um2", "cells", "seq_cells", "slack_ns"):
    print(f"{k}: {rows[a][k]} / {rows[b][k]}")
