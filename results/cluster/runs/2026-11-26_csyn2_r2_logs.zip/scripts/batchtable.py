"""Step 8's tables (CG3 R2's layout) from the zips, synth_dc.csv and power_pt.csv; Markdown on stdout."""
import csv, json, re, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
RES = ROOT / "results/cluster/nangate45"
RUNS = ROOT / "sim/runs/cluster/nangate45"
SYN = ROOT / "syn/runs/cluster/nangate45"
pts = sys.argv[1:]
syn_rows = {r["point"]: r for r in csv.DictReader(open(RES / "synth_dc.csv", newline=""))}
pwr_rows = {}
for r in csv.DictReader(open(RES / "power_pt.csv", newline="")):
    pwr_rows.setdefault(r["point"], []).append(r)

def j(z, m):
    return json.loads(arc.read(z, m)) if z.is_file() and arc.has(z, m) else None

def n(x, d=0):
    try:
        return f"{float(x):,.{d}f}"
    except (TypeError, ValueError):
        return str(x)

print("### syn\n")
print("| point | status | area µm² | comb µm² | seq µm² | macro µm² | cells | seq cells | slack ns | gated registers | ungated | clock-gating elements | macros | DC s | DC cores |")
print("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|")
dbs, adopted = {}, {}
for p in pts:
    a = j(RUNS / f"{p}.zip", "syn/adopted.json")
    if a:
        adopted[p] = a
        print(f"| `{p}` | adopts `{a['netlist_of']}`'s netlist (`{a['netlist_sha256'][:12]}`), no DC | | | | | | | | | | | | | |")
        continue
    r = syn_rows.get(p)
    z = SYN / f"{p}.zip"
    if r is None:
        print(f"| `{p}` | no synth_dc.csv row | | | | | | | | | | | | | |"); continue
    cg = arc.read(RES / "reports" / f"{p}.zip", "clock_gating.rpt").decode() if (RES / "reports" / f"{p}.zip").is_file() else ""
    el = re.search(r"Number of Clock gating elements\s*\|\s*(\d+)", cg)
    ga = re.search(r"Number of Gated registers\s*\|\s*(\d+) \(([\d.]+)%\)", cg)
    un = re.search(r"Number of Ungated registers\s*\|\s*(\d+)", cg)
    tot = re.search(r"Total number of registers\s*\|\s*(\d+)", cg)
    log = arc.read(z, "logs/dc_shell.log").decode(errors="replace") if z.is_file() and arc.has(z, "logs/dc_shell.log") else ""
    cores = sorted(set(re.findall(r"maximum of (\d+) cores\. \(OPT-1500\)", log)))
    el_s = re.search(r"Elapsed time for this session (\d+) seconds", log)
    tj = j(z, "tech.json") or {}
    md = (tj.get("cluster") or (tj.get("resolved") or {}).get("cluster") or {}).get("macro_db") or {}
    dbs[p] = md
    m019 = re.search(r"value '(\d+)' for option '-max_cores' not in range", log)
    cores_s = ",".join(cores) or (f"1 (CMD-019: {m019.group(1)} refused, range 1 to 16)" if m019 else "?")
    gated = f"{n(ga.group(1))} of {n(tot.group(1))} ({ga.group(2)} %)" if ga and tot else "?"
    print(f"| `{p}` | {r['status']} | {n(r['area_um2'])} | {n(r['comb_area_um2'])} | {n(r['seq_area_um2'])} | {n(r['macro_um2'])} | "
          f"{n(r['cells'])} | {n(r['seq_cells'])} | {float(r['slack_ns']):+.3f} | {gated} | {un.group(1) if un else '?'} | "
          f"{el.group(1) if el else '?'} | {r['macros']} | {el_s.group(1) if el_s else '?'} | {cores_s} |")
print("\nThe macros' `.db` (X107):\n")
for p, md in dbs.items():
    print(f"- `{p}`: " + "; ".join(f"{m} `{v.get('sha256', '')[:16]}` {'ok' if v.get('ok') else 'MISMATCH'}" for m, v in md.items()))
for p, a in adopted.items():
    print(f"\nAdoption: `{p}` → `{a['netlist_of']}`: {json.dumps(a)}")

print("\n### gls\n")
print("| point | status | data | cycles RTL / netlist (e) | counters RTL / netlist (e) | swap | success | D123 (reported) | RAMCOUNT (reported) | Questa s (vlog netlist, vopt, run) |")
print("|---|---|---|---:|---|---|---|---|---|---|")
for p in pts:
    g = j(RUNS / f"{p}.zip", "gls/check.json")
    if not g:
        print(f"| `{p}` | not run | | | | | | | | |"); continue
    c = g.get("checks", {})
    rows = c.get("cycles", {}).get("rows", [])
    cyc = next((r for r in rows if r["what"] == "cycles"), {})
    ctr = "; ".join(f"{r['what'].replace('counter ', '')} {r['rtl']} / {r['gls']} ({r['diff_pct']:+.1f} %)" for r in rows if r["what"] != "cycles")
    rc = c.get("ramcount", {})
    ram = f"{rc.get('status')}, {rc.get('lines')} lines, +{len(g.get('ram_extra_writes') or [])} writes, +{len(g.get('ram_extra_reads') or [])} reads"
    d123 = c.get("d123", {})
    qe = g.get("questa_elapsed_s", {})
    print(f"| `{p}` | {g['status']}{'' if g['status'] == 'PASS' else ' (' + str(g.get('failed')) + ')'} | {c.get('data', {}).get('status')} | "
          f"{n(cyc.get('rtl'))} / {n(cyc.get('gls'))} ({cyc.get('diff_pct', 0):+.1f} %) | {ctr} | {c.get('swap', {}).get('status')} | "
          f"{c.get('success', {}).get('status')} | {d123.get('status')}{' (' + '; '.join(d123.get('notes', [])) + ')' if d123.get('notes') else ''} | {ram} | "
          f"{qe.get('vlog_netlist')}, {qe.get('vopt')}, {qe.get('run')} |")

print("\n### pwr\n")
for p in pts:
    pw = j(RUNS / f"{p}.zip", "pwr/check.json")
    pt = j(RUNS / f"{p}.zip", "pt/pt_check.json")
    rows = sorted(pwr_rows.get(p, []), key=lambda r: int(r["mark"]))
    if not pw:
        print(f"`{p}`: not run\n"); continue
    wr = pw.get("windows_ref", {})
    ref = {r["mark"]: r for r in wr.get("rows", [])}
    print(f"`{p}`: part 1 {pw['status']}{'' if pw['status'] == 'PASS' else ' (' + str(pw.get('failed')) + ')'}, windows against {wr.get('source')}: {wr.get('status')}; "
          f"part 2 {pt['status'] if pt else 'not run'}{'' if not pt or pt['status'] == 'PASS' else ' (' + str(pt.get('failed')) + ')'}, PT threads {pt.get('threads') if pt else '?'} ({pt.get('threads_why') if pt else ''})")
    mdb = (pt or {}).get("macro_db") or {}
    if mdb:
        print(f"PT's macros' .db: " + "; ".join(f"{m} `{v.get('sha256', '')[:16]}` {'ok' if v.get('ok') else 'MISMATCH'}" for m, v in mdb.items()))
    print()
    print("| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |")
    print("|---:|---|---|---:|---:|---:|---:|---:|---:|")
    span = run = 0.0
    for r in rows:
        f = ref.get(int(r["mark"]), {})
        e = float(r["e_win_pj"]) / 1000 if r["e_win_pj"] else 0.0
        span += e
        if r["kind"] == "run":
            run += e
        print(f"| {r['mark']} | {r['kind']} | {r['label']} | {n(r['cycles'])} | {n(f.get('ref'))} | {f.get('diff')} | {n(r['e_dyn_pj'], 1)} | {e:.2f} | {n(r['ann_pct'], 2)} % |")
    tot_cyc = sum(int(r["cycles"]) for r in rows)
    print(f"\nRun windows {run:.2f} nJ ({sum(int(r['cycles']) for r in rows if r['kind'] == 'run'):,} cycles); span {span:.2f} nJ ({tot_cyc:,} cycles).")
    first_run = next((r for r in rows if r["kind"] == "run"), None)
    pz = RES / "power_reports" / f"{p}.zip"
    if first_run and pz.is_file():
        w = f"{first_run['mark']}_{first_run['kind']}"
        units = arc.read(pz, f"{w}/units.rpt").decode(errors="replace") if arc.has(pz, f"{w}/units.rpt") else ""
        ph = arc.read(pz, f"{w}/power_hierarchy.rpt").decode(errors="replace").splitlines()
        top = next((ln for ln in ph if ln.startswith("snax_forge_cluster_wrapper ")), None)
        if top:
            int_p, sw_p, leak_p, tot_p = (float(x) for x in top.split()[1:5])
            um = re.search(r"Power\s*[:=]?\s*(\S*W)", units)
            print(f"PT's top in `{w}` (power_hierarchy.rpt, units W{' per units.rpt: ' + um.group(1) if um else ''}): leakage {leak_p * 1e6:,.1f} µW; dynamic (int + switch) {(int_p + sw_p) * 1e6:,.1f} µW, kept apart.")
    print()
