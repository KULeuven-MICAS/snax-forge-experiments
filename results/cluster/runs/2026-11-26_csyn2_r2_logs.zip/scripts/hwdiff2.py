import difflib, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
a, b = (arc.read_all(ROOT / "rtl/cluster" / f"{p}.zip") for p in sys.argv[1:3])
for m in sys.argv[3:]:
    print(f"=== {m}")
    d = difflib.unified_diff(a[m].decode().splitlines(), b[m].decode().splitlines(), sys.argv[1], sys.argv[2], n=1, lineterm="")
    print("\n".join(list(d)[:60]))
