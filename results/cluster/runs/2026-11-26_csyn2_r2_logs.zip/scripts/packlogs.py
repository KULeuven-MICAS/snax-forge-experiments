import sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
z = ROOT / "results/cluster/runs/2026-11-26_csyn2_r2_logs.zip"
src = {"pre": ROOT / "tmp/csyn2-pre", "batch": ROOT / "tmp/csyn2", "scripts": ROOT / "tmp/csyn2-scripts"}
members = {f"{k}/{rel}": p.read_bytes() for k, d in src.items() for rel, p in arc.files_of(d).items()}
arc.write(z, members)
bad = [n for n, b in members.items() if arc.read(z, n) != b]
names = arc.names(z)
print(f"{z.relative_to(ROOT)}: {len(names)} members, {z.stat().st_size:,} bytes; test read {'OK' if not bad and sorted(names) == sorted(members) else 'FAILED ' + str(bad)}")
for k in src:
    print(f"  {k}/: {sum(n.startswith(k + '/') for n in names)}")
sys.exit(1 if bad else 0)
