import json, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc")]
import arc
for point in sys.argv[1:]:
    z = ROOT / "sim/runs/cluster/nangate45" / f"{point}.zip"
    r = json.loads(arc.read(z, "rtl/check.json"))
    c = r.get("checks", {})
    print(f"== {point}: {r['status']} failed={r.get('failed')} seconds={r.get('seconds', {}).get('total')}")
    if "--json" in sys.argv[0:1]:
        pass
    for k in ("data", "d123_plain", "d123_macro", "cycles", "srams", "vlog", "success"):
        v = c.get(k, {})
        print(f"  {k}: {json.dumps(v)[:600]}")
    q = c.get("quiet", {})
    print(f"  quiet: status={q.get('status')} success={q.get('success')} program_lines={q.get('program_lines')} "
          f"span={q.get('span_cycles')} check_mark={q.get('check_mark')} err={q.get('windows_error')} why={q.get('why')}")
    for w in q.get("windows", []):
        print(f"    win {w}")
    g = c.get("gvsoc", {})
    print(f"  gvsoc: {json.dumps({k: v for k, v in g.items() if k != 'tail'})}")
    if g.get("tail"):
        print("    tail:", g["tail"][-1500:])
    qw = c.get("quiet_windows", {})
    print(f"  quiet_windows: status={qw.get('status')} worst={qw.get('worst')} quiet_span={qw.get('quiet_span')} "
          f"gvsoc_span={qw.get('gvsoc_span')} default={qw.get('default_cycles')} why={qw.get('why')}")
    for row in qw.get("rows", []):
        print(f"    row {row}")
