import sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc"), str(ROOT / "cluster")]
import arc, check
a, b = (arc.read_all(ROOT / "rtl/cluster" / f"{p}.zip") for p in sys.argv[1:3])
print("hardware members:", len(check.hardware(a)), len(check.hardware(b)))
print("differ:", check.hardware_diff(a, b))
