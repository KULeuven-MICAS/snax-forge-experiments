import re, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "arc"))
import arc
z, m, pat = Path(sys.argv[1]), sys.argv[2], re.compile(sys.argv[3])
for ln in arc.read(z, m).decode(errors="replace").splitlines():
    if pat.search(ln):
        print(ln[:300])
