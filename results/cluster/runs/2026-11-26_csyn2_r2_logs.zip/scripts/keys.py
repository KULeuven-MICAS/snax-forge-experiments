import json, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "arc"))
import arc
z = Path(sys.argv[1]); m = sys.argv[2]
d = json.loads(arc.read(z, m))
def show(d, pre="", depth=0):
    for k, v in d.items():
        if isinstance(v, dict) and depth < 2:
            print(f"{pre}{k}:"); show(v, pre + "  ", depth + 1)
        else:
            s = json.dumps(v); print(f"{pre}{k} = {s[:160]}")
show(d)
