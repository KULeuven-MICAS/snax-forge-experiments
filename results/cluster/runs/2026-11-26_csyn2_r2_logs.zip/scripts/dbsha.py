import hashlib, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc"), str(ROOT / "cluster")]
import arc, check
bad = 0
for name, want in check.LSTP_DB_SHA256.items():
    z = ROOT / "ram" / "runs" / "lib" / f"{name}.zip"
    dbs = [n for n in arc.names(z) if n.endswith(f"{name}.db")]
    got = hashlib.sha256(arc.read(z, dbs[0])).hexdigest()
    ok = got == want
    bad += not ok
    print(f"{name}: member {dbs[0]}, sha256 {got}, want {want}: {'MATCH' if ok else 'MISMATCH'}")
sys.exit(bad)
