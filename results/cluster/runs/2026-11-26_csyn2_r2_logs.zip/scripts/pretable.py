"""The pre-flight tables (steps 5, 6) from each point's rtl/check.json, as Markdown."""
import json, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / "arc"), str(ROOT / "cluster")]
import arc, check

def d123(c):
    v = c or {}
    if v.get("status") == "PASS" and not v.get("notes"):
        return "PASS"
    return f"{v.get('status')} ({'; '.join(v.get('notes', []))})"

rows, issues = [], []
for point in sys.argv[1:]:
    z = ROOT / "sim/runs/cluster/nangate45" / f"{point}.zip"
    if not arc.has(z, "rtl/check.json"):
        rows.append(f"| `{point}` | no rtl/check.json | | | | | | | |"); continue
    r = json.loads(arc.read(z, "rtl/check.json"))
    c = r.get("checks", {})
    q, g, qw, cy = c.get("quiet", {}), c.get("gvsoc", {}), c.get("quiet_windows", {}), c.get("cycles", {})
    st = r["status"] + ("" if r["status"] == "PASS" else f" ({r.get('failed')})")
    qs = f"{q.get('success')}" + (f", {len(q.get('program_lines') or [])} output lines" if q.get("program_lines") else "")
    if q.get("windows_error"):
        qs += f", windows_error: {q['windows_error']}"
    span = f"{qw.get('quiet_span')} / {qw.get('gvsoc_span')} / {cy.get('plain')}, {cy.get('macro')}"
    rows.append(f"| `{point}` | {st} | {c.get('data', {}).get('status')} | {d123(c.get('d123_plain'))} | "
                f"{d123(c.get('d123_macro'))} | {qs} | {qw.get('worst') or qw.get('status')} | {span} | "
                f"{g.get('status')}, {g.get('same_quiet_elf')} | {r.get('seconds', {}).get('total')} |")
    for row in qw.get("rows", []):
        if row["verdict"] in ("WARNING", "INVESTIGATE", "MISSING"):
            dd = "" if row["diff"] is None else f"{row['diff']:+d}"
            pct = "" if row["pct"] is None else f" ({row['pct']:+.1f} %)"
            issues.append(f"| `{point}` | {row['mark']} | {row['kind']} | {row['rtl']} | {row['gvsoc']} | "
                          f"{dd}{pct} | {row['verdict']} |")
print("| point | status | data | D123 plain | D123 macro | quiet success | quiet windows worst | quiet span RTL / SNAX-GVSoC / default build plain, macro | SNAX-GVSoC, same_quiet_elf | s |")
print("|---|---|---|---|---|---|---|---|---|---:|")
print("\n".join(rows))
print()
print("| point | mark | kind | RTL | SNAX-GVSoC | gap | verdict |")
print("|---|---:|---|---:|---:|---:|---|")
print("\n".join(issues))
