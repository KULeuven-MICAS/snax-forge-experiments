| point | status | data | D123 plain | D123 macro | quiet success | quiet windows worst | quiet span RTL / SNAX-GVSoC / default build plain, macro | SNAX-GVSoC, same_quiet_elf | s |
|---|---|---|---|---|---|---|---|---|---:|
| `mvt_column_cg` | PASS | PASS | PASS | PASS | True | INVESTIGATE | 1601 / 1556 / 1646, 1646 | PASS, True | 269.8 |
| `mvt_read_once_cg` | PASS | PASS | PASS (tmp1_mult_mvt: counter 515 against 519, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS (tmp1_mult_mvt: counter 515 against 519, 1 beyond its fill 3 (0.2 %, NEAR)) | True | INVESTIGATE | 1025 / 989 / 922, 922 | PASS, True | 201.0 |
| `bicg_two_pass_cg` | PASS | PASS | PASS | PASS | True | INVESTIGATE | 1504 / 1454 / 1532, 1532 | PASS, True | 214.0 |
| `bicg_read_once_cg` | PASS | PASS | PASS | PASS | True | INVESTIGATE | 933 / 899 / 859, 859 | PASS, True | 196.0 |
| `atax_read_once_cg` | PASS | PASS | PASS (tmp2_mult_atax: counter 523 against 526, within its fill 3) | PASS (tmp2_mult_atax: counter 523 against 526, within its fill 3) | True | INVESTIGATE | 843 / 820 / 825, 825 | PASS, True | 194.7 |
| `atax_column_shared_movers_cg` | PASS | PASS | PASS (y_mult_mac: counter 516 against 514, within its fill 3) | PASS (y_mult_mac: counter 516 against 514, within its fill 3) | True | INVESTIGATE | 1436 / 1409 / 1350, 1350 | PASS, True | 193.8 |
| `gesummv_x_read_once_cg` | PASS | PASS | PASS (tmp2_mult_gesummv: counter 514 against 518, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS (tmp2_mult_gesummv: counter 514 against 518, 1 beyond its fill 3 (0.2 %, NEAR)) | True | INVESTIGATE | 1062 / 1033 / 960, 960 | PASS, True | 218.3 |
| `gesummv_factor_out_cg` | PASS | PASS | PASS (tmp5_mult_matvec_1: counter 517 against 514, within its fill 3) | PASS (tmp5_mult_matvec_1: counter 517 against 514, within its fill 3) | True | INVESTIGATE | 1627 / 1584 / 1433, 1433 | PASS, True | 235.8 |
| `gesummv_literal_cg` | PASS | PASS | PASS (tmp5_mult_matvec_1: counter 514 against 517, within its fill 3) | PASS (tmp5_mult_matvec_1: counter 514 against 517, within its fill 3) | True | INVESTIGATE | 2860 / 2805 / 2496, 2496 | PASS, True | 291.2 |
| `mvt_dma_copy_cg` | PASS | PASS | PASS (tmp1_mult_mvt_1: counter 518 against 514, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS (tmp1_mult_mvt_1: counter 518 against 514, 1 beyond its fill 3 (0.2 %, NEAR)) | True | INVESTIGATE | 12591 / 12518 / 12593, 12593 | PASS, True | 233.2 |
| `atax_dma_copy_cg` | PASS | PASS | PASS (y_mult_matvec_1: counter 527 against 533, 3 beyond its fill 3 (0.6 %, NEAR)) | PASS (y_mult_matvec_1: counter 527 against 533, 3 beyond its fill 3 (0.6 %, NEAR)) | True | INVESTIGATE | 12408 / 12376 / 12420, 12420 | PASS, True | 251.4 |
| `mvt_contiguous_w8_cg` | PASS | PASS | PASS | PASS | True | INVESTIGATE | 4836 / 4777 / 4657, 4657 | PASS, True | 212.3 |
| `mvt_padded_w8_cg` | PASS | PASS | PASS (tmp0_mult_mvt_1: counter 521 against 514, 4 beyond its fill 3 (0.8 %, NEAR)) | PASS (tmp0_mult_mvt_1: counter 521 against 514, 4 beyond its fill 3 (0.8 %, NEAR)) | True | INVESTIGATE | 2107 / 2056 / 1937, 1937 | PASS, True | 210.0 |
| `bicg_sequential_contiguous_w8_cg` | PASS | PASS | PASS | PASS | True | INVESTIGATE | 1983 / 1930 / 2018, 2018 | PASS, True | 231.3 |

| point | mark | kind | RTL | SNAX-GVSoC | gap | verdict |
|---|---:|---|---:|---:|---:|---|
| `mvt_column_cg` | 2 | dma_in | 38 | 32 | +6 (+18.8 %) | WARNING |
| `mvt_column_cg` | 3 | dma_in | 58 | 37 | +21 (+56.8 %) | INVESTIGATE |
| `mvt_column_cg` | 4 | streamer_config | 43 | 61 | -18 (-29.5 %) | INVESTIGATE |
| `mvt_column_cg` | 8 | dma_in | 35 | 24 | +11 (+45.8 %) | INVESTIGATE |
| `mvt_column_cg` | 9 | dma_in | 42 | 37 | +5 (+13.5 %) | WARNING |
| `mvt_column_cg` | 13 | dma_out | 75 | 56 | +19 (+33.9 %) | INVESTIGATE |
| `mvt_read_once_cg` | 2 | dma_in | 35 | 24 | +11 (+45.8 %) | INVESTIGATE |
| `mvt_read_once_cg` | 3 | dma_in | 42 | 37 | +5 (+13.5 %) | WARNING |
| `mvt_read_once_cg` | 4 | dma_in | 38 | 32 | +6 (+18.8 %) | WARNING |
| `mvt_read_once_cg` | 5 | dma_in | 58 | 37 | +21 (+56.8 %) | INVESTIGATE |
| `mvt_read_once_cg` | 6 | streamer_config | 76 | 100 | -24 (-24.0 %) | INVESTIGATE |
| `mvt_read_once_cg` | 9 | dma_out | 24 | 19 | +5 (+26.3 %) | INVESTIGATE |
| `mvt_read_once_cg` | 10 | dma_out | 69 | 53 | +16 (+30.2 %) | INVESTIGATE |
| `bicg_two_pass_cg` | 2 | dma_in | 35 | 24 | +11 (+45.8 %) | INVESTIGATE |
| `bicg_two_pass_cg` | 6 | dma_out | 49 | 33 | +16 (+48.5 %) | INVESTIGATE |
| `bicg_two_pass_cg` | 8 | streamer_config | 35 | 40 | -5 (-12.5 %) | WARNING |
| `bicg_two_pass_cg` | 11 | dma_out | 85 | 65 | +20 (+30.8 %) | INVESTIGATE |
| `bicg_read_once_cg` | 2 | dma_in | 35 | 25 | +10 (+40.0 %) | INVESTIGATE |
| `bicg_read_once_cg` | 3 | dma_in | 37 | 33 | +4 (+12.1 %) | WARNING |
| `bicg_read_once_cg` | 4 | streamer_config | 72 | 82 | -10 (-12.2 %) | WARNING |
| `bicg_read_once_cg` | 8 | dma_out | 71 | 47 | +24 (+51.1 %) | INVESTIGATE |
| `atax_read_once_cg` | 2 | dma_in | 29 | 24 | +5 (+20.8 %) | INVESTIGATE |
| `atax_read_once_cg` | 3 | streamer_config | 45 | 52 | -7 (-13.5 %) | WARNING |
| `atax_read_once_cg` | 6 | dma_out | 91 | 67 | +24 (+35.8 %) | INVESTIGATE |
| `atax_column_shared_movers_cg` | 2 | dma_in | 38 | 32 | +6 (+18.8 %) | WARNING |
| `atax_column_shared_movers_cg` | 6 | streamer_config | 47 | 65 | -18 (-27.7 %) | INVESTIGATE |
| `atax_column_shared_movers_cg` | 9 | dma_out | 71 | 57 | +14 (+24.6 %) | INVESTIGATE |
| `gesummv_x_read_once_cg` | 2 | dma_in | 44 | 34 | +10 (+29.4 %) | INVESTIGATE |
| `gesummv_x_read_once_cg` | 4 | streamer_config | 59 | 69 | -10 (-14.5 %) | WARNING |
| `gesummv_x_read_once_cg` | 7 | streamer_config | 45 | 63 | -18 (-28.6 %) | INVESTIGATE |
| `gesummv_x_read_once_cg` | 9 | run | 44 | 34 | +10 (+29.4 %) | INVESTIGATE |
| `gesummv_x_read_once_cg` | 10 | dma_out | 91 | 67 | +24 (+35.8 %) | INVESTIGATE |
| `gesummv_factor_out_cg` | 3 | streamer_config | 34 | 39 | -5 (-12.8 %) | WARNING |
| `gesummv_factor_out_cg` | 12 | run | 40 | 25 | +15 (+60.0 %) | INVESTIGATE |
| `gesummv_factor_out_cg` | 13 | dma_out | 71 | 57 | +14 (+24.6 %) | INVESTIGATE |
| `gesummv_literal_cg` | 2 | streamer_config | 43 | 48 | -5 (-10.4 %) | WARNING |
| `gesummv_literal_cg` | 5 | dma_in | 46 | 36 | +10 (+27.8 %) | INVESTIGATE |
| `gesummv_literal_cg` | 6 | streamer_config | 46 | 52 | -6 (-11.5 %) | WARNING |
| `gesummv_literal_cg` | 13 | streamer_config | 47 | 55 | -8 (-14.6 %) | WARNING |
| `gesummv_literal_cg` | 16 | streamer_config | 43 | 50 | -7 (-14.0 %) | WARNING |
| `gesummv_literal_cg` | 18 | run | 45 | 34 | +11 (+32.4 %) | INVESTIGATE |
| `gesummv_literal_cg` | 19 | dma_out | 79 | 48 | +31 (+64.6 %) | INVESTIGATE |
| `mvt_dma_copy_cg` | 2 | dma_in | 37 | 33 | +4 (+12.1 %) | WARNING |
| `mvt_dma_copy_cg` | 3 | dma_in | 43 | 36 | +7 (+19.4 %) | WARNING |
| `mvt_dma_copy_cg` | 9 | dma_in | 51 | 37 | +14 (+37.8 %) | INVESTIGATE |
| `mvt_dma_copy_cg` | 11 | streamer_config | 45 | 52 | -7 (-13.5 %) | WARNING |
| `mvt_dma_copy_cg` | 14 | dma_out | 74 | 46 | +28 (+60.9 %) | INVESTIGATE |
| `atax_dma_copy_cg` | 2 | dma_in | 38 | 32 | +6 (+18.8 %) | WARNING |
| `atax_dma_copy_cg` | 10 | dma_out | 69 | 48 | +21 (+43.8 %) | INVESTIGATE |
| `mvt_contiguous_w8_cg` | 2 | dma_in | 48 | 40 | +8 (+20.0 %) | WARNING |
| `mvt_contiguous_w8_cg` | 3 | dma_in | 63 | 41 | +22 (+53.7 %) | INVESTIGATE |
| `mvt_contiguous_w8_cg` | 4 | streamer_config | 43 | 61 | -18 (-29.5 %) | INVESTIGATE |
| `mvt_contiguous_w8_cg` | 8 | dma_in | 45 | 30 | +15 (+50.0 %) | INVESTIGATE |
| `mvt_contiguous_w8_cg` | 9 | dma_in | 47 | 41 | +6 (+14.6 %) | WARNING |
| `mvt_contiguous_w8_cg` | 13 | dma_out | 85 | 69 | +16 (+23.2 %) | INVESTIGATE |
| `mvt_padded_w8_cg` | 2 | dma_in | 63 | 40 | +23 (+57.5 %) | INVESTIGATE |
| `mvt_padded_w8_cg` | 3 | dma_in | 34 | 40 | -6 (-15.0 %) | WARNING |
| `mvt_padded_w8_cg` | 4 | streamer_config | 45 | 52 | -7 (-13.5 %) | WARNING |
| `mvt_padded_w8_cg` | 7 | dma_out | 43 | 48 | -5 (-10.4 %) | WARNING |
| `mvt_padded_w8_cg` | 8 | dma_in | 47 | 40 | +7 (+17.5 %) | WARNING |
| `mvt_padded_w8_cg` | 9 | dma_in | 49 | 41 | +8 (+19.5 %) | WARNING |
| `mvt_padded_w8_cg` | 13 | dma_out | 74 | 50 | +24 (+48.0 %) | INVESTIGATE |
| `bicg_sequential_contiguous_w8_cg` | 2 | dma_in | 45 | 30 | +15 (+50.0 %) | INVESTIGATE |
| `bicg_sequential_contiguous_w8_cg` | 7 | dma_in | 45 | 31 | +14 (+45.2 %) | INVESTIGATE |
| `bicg_sequential_contiguous_w8_cg` | 11 | dma_out | 85 | 69 | +16 (+23.2 %) | INVESTIGATE |
