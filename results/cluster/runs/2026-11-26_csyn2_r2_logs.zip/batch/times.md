| point | rtl | syn (DC) | gls | pwr | total |
|---|---:|---:|---:|---:|---:|
| `mvt_column_cg` | 275 | 2,309 (2,243) | 199 | 600 | 3,383 (56 min) |
| `mvt_read_once_cg` | 205 | 2,191 (2,142) | 178 | 469 | 3,043 (51 min) |
| `bicg_two_pass_cg` | 221 | 1,890 (1,831) | 183 | 489 | 2,783 (46 min) |
| `bicg_read_once_cg` | 203 | 1,868 (1,823) | 164 | 395 | 2,630 (44 min) |
| `atax_read_once_cg` | 201 | 1,771 (1,727) | 163 | 342 | 2,477 (41 min) |
| `atax_column_shared_movers_cg` | 200 | 1,733 (1,689) | 165 | 414 | 2,512 (42 min) |
| `gesummv_x_read_once_cg` | 226 | 2,337 (2,277) | 195 | 528 | 3,286 (55 min) |
| `gesummv_factor_out_cg` | 243 | 2,423 (2,345) | 215 | 630 | 3,511 (59 min) |
| `gesummv_literal_cg` | 298 | 3,069 (2,959) | 279 | 987 | 4,633 (77 min) |
| `mvt_dma_copy_cg` | 240 | 1,788 (1,738) | 217 | 673 | 2,918 (49 min) |
| `atax_dma_copy_cg` | 258 | 1,954 (1,892) | 227 | 628 | 3,067 (51 min) |
| `mvt_contiguous_w8_cg` | 220 | 2,372 (2,320) | 232 | 756 | 3,580 (60 min) |
| `mvt_padded_w8_cg` | 216 | 2,452 (2,403) | 222 | 745 | 3,635 (61 min) |
| `bicg_sequential_contiguous_w8_cg` | 238 | 3,333 (3,264) | 258 | 779 | 4,608 (77 min) |

Total 46,066 s (12.80 h).

| point | snax-forge-experiments | snax_cluster (rtl, syn, gls, pwr) | snax-forge (bundle, `dirty`) | forge.elf sha256 | forge_quiet.elf sha256 |
|---|---|---|---|---|---|
| `mvt_column_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `368b14eda61fc940` | `8200b071980de9a4` |
| `mvt_read_once_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `6b3734ded019a1e0` | `f16e8acd7ce7b351` |
| `bicg_two_pass_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `bb20bc0f7817cd46` | `7c35e927cd8fe70c` |
| `bicg_read_once_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `0769e8e8debe693d` | `313a205544c0c906` |
| `atax_read_once_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `e5f585ccd15cbb69` | `97ce5241a6578690` |
| `atax_column_shared_movers_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `d4a8451fe3dfc313` | `0206c6fe48540e2b` |
| `gesummv_x_read_once_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `b0f9ea3e8bb7446c` | `49e9f7375e344edc` |
| `gesummv_factor_out_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `f83c684858e8eac8` | `be07363c24e168be` |
| `gesummv_literal_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `fe21c3b03386a123` | `b59d8e04ec3a785f` |
| `mvt_dma_copy_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `860579a7efece8ef` | `3bfac384401af180` |
| `atax_dma_copy_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `bae97206709963f8` | `1150f8633c7df91a` |
| `mvt_contiguous_w8_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `52f2d61a18b477b3` | `b227136d164d7805` |
| `mvt_padded_w8_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `d123be5bff6e9b60` | `06121811b3a91db7` |
| `bicg_sequential_contiguous_w8_cg` | `cdaf350e` | `baf87858`, `baf87858`, `baf87858`, `baf87858` | `3c4d4bc0`, false | `5a6bfafb043eae93` | `91c848cb80596b78` |
