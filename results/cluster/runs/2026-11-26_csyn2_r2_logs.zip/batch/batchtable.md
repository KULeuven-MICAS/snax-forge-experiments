### syn

| point | status | area µm² | comb µm² | seq µm² | macro µm² | cells | seq cells | slack ns | gated registers | ungated | clock-gating elements | macros | DC s | DC cores |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|
| `mvt_column_cg` | ok | 961,370 | 207,777 | 278,401 | 475,193 | 225,000 | 55,139 | +1.659 | 52,777 of 53,496 (98.66 %) | 719 | 1643 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2243 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `mvt_read_once_cg` | ok | 966,659 | 207,888 | 283,579 | 475,193 | 225,521 | 56,012 | +1.676 | 53,680 of 54,385 (98.70 %) | 705 | 1627 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2142 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `bicg_two_pass_cg` | ok | 924,503 | 189,252 | 260,058 | 475,193 | 205,611 | 51,168 | +1.846 | 48,970 of 49,642 (98.65 %) | 672 | 1526 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1831 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `bicg_read_once_cg` | ok | 928,667 | 188,956 | 264,518 | 475,193 | 206,470 | 51,904 | +1.614 | 49,742 of 50,400 (98.69 %) | 658 | 1504 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1823 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `atax_read_once_cg` | ok | 917,540 | 183,903 | 258,445 | 475,193 | 199,218 | 50,539 | +1.744 | 48,432 of 49,081 (98.68 %) | 649 | 1458 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1727 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `atax_column_shared_movers_cg` | ok | 899,431 | 179,301 | 244,937 | 475,193 | 192,630 | 48,006 | +1.659 | 45,923 of 46,572 (98.61 %) | 649 | 1434 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1689 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `gesummv_x_read_once_cg` | ok | 1,010,069 | 247,294 | 287,582 | 475,193 | 251,634 | 57,158 | +1.614 | 54,718 of 55,457 (98.67 %) | 739 | 1701 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2277 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `gesummv_factor_out_cg` | ok | 1,020,815 | 252,156 | 293,466 | 475,193 | 257,073 | 58,372 | +1.679 | 55,880 of 56,633 (98.67 %) | 753 | 1739 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2345 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `gesummv_literal_cg` | ok | 1,143,327 | 315,727 | 352,407 | 475,193 | 321,351 | 71,094 | +1.618 | 68,116 of 68,975 (98.75 %) | 859 | 2119 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2959 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `mvt_dma_copy_cg` | ok | 878,713 | 165,579 | 237,941 | 475,193 | 181,517 | 46,492 | +1.613 | 44,448 of 45,094 (98.57 %) | 646 | 1398 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1738 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `atax_dma_copy_cg` | ok | 930,031 | 194,252 | 260,586 | 475,193 | 208,650 | 51,268 | +1.663 | 49,043 of 49,734 (98.61 %) | 691 | 1534 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 1892 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `mvt_contiguous_w8_cg` | ok | 1,025,570 | 268,576 | 281,802 | 475,193 | 261,958 | 56,157 | +1.663 | 53,698 of 54,467 (98.59 %) | 769 | 1690 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2320 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `mvt_padded_w8_cg` | ok | 1,025,570 | 268,576 | 281,802 | 475,193 | 261,958 | 56,157 | +1.663 | 53,698 of 54,467 (98.59 %) | 769 | 1690 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 2403 | 1 (CMD-019: 24 refused, range 1 to 16) |
| `bicg_sequential_contiguous_w8_cg` | ok | 1,196,199 | 382,598 | 338,409 | 475,193 | 355,419 | 68,432 | +1.656 | 65,514 of 66,385 (98.69 %) | 871 | 2047 | sram_d128_w256_m8=2;sram_d128_w39=2;sram_d512_w64_m8=32 | 3264 | 1 (CMD-019: 24 refused, range 1 to 16) |

The macros' `.db` (X107):

- `mvt_column_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `mvt_read_once_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `bicg_two_pass_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `bicg_read_once_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `atax_read_once_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `atax_column_shared_movers_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `gesummv_x_read_once_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `gesummv_factor_out_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `gesummv_literal_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `mvt_dma_copy_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `atax_dma_copy_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `mvt_contiguous_w8_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `mvt_padded_w8_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok
- `bicg_sequential_contiguous_w8_cg`: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

### gls

| point | status | data | cycles RTL / netlist (e) | counters RTL / netlist (e) | swap | success | D123 (reported) | RAMCOUNT (reported) | Questa s (vlog netlist, vopt, run) |
|---|---|---|---:|---|---|---|---|---|---|
| `mvt_column_cg` | PASS | PASS | 1,646 / 1,646 (+0.0 %) | tmp1_mult_mvt 518 / 518 (+0.0 %); tmp4_mult_mac_x2 516 / 516 (+0.0 %) | PASS | PASS | PASS | PASS, 36 lines, +4 writes, +8 reads | 14, 23, 37 |
| `mvt_read_once_cg` | PASS | PASS | 922 / 922 (+0.0 %) | tmp1_mult_mvt 515 / 515 (+0.0 %) | PASS | PASS | PASS (tmp1_mult_mvt: counter 515 against 519, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 13, 24, 32 |
| `bicg_two_pass_cg` | PASS | PASS | 1,532 / 1,532 (+0.0 %) | q_mult_matvec 517 / 517 (+0.0 %); s_mult_mac 516 / 516 (+0.0 %) | PASS | PASS | PASS | PASS, 36 lines, +4 writes, +8 reads | 13, 21, 32 |
| `bicg_read_once_cg` | PASS | PASS | 859 / 859 (+0.0 %) | q_mult_bicg_types 517 / 517 (+0.0 %) | PASS | PASS | PASS | PASS, 36 lines, +4 writes, +8 reads | 11, 20, 30 |
| `atax_read_once_cg` | PASS | PASS | 825 / 825 (+0.0 %) | tmp2_mult_atax 523 / 523 (+0.0 %) | PASS | PASS | PASS (tmp2_mult_atax: counter 523 against 526, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 11, 21, 30 |
| `atax_column_shared_movers_cg` | PASS | PASS | 1,350 / 1,350 (+0.0 %) | tmp2_mult_matvec 517 / 517 (+0.0 %); y_mult_mac 516 / 516 (+0.0 %) | PASS | PASS | PASS (y_mult_mac: counter 516 against 514, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 10, 20, 30 |
| `gesummv_x_read_once_cg` | PASS | PASS | 960 / 960 (+0.0 %) | tmp2_mult_gesummv 514 / 514 (+0.0 %); add_axpby 11 / 11 (+0.0 %) | PASS | PASS | PASS (tmp2_mult_gesummv: counter 514 against 518, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 14, 23, 37 |
| `gesummv_factor_out_cg` | PASS | PASS | 1,433 / 1,433 (+0.0 %) | tmp2_mult_matvec 533 / 533 (+0.0 %); tmp5_mult_matvec_1 517 / 517 (+0.0 %); add_axpby 11 / 11 (+0.0 %) | PASS | PASS | PASS (tmp5_mult_matvec_1: counter 517 against 514, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 12, 25, 41 |
| `gesummv_literal_cg` | PASS | PASS | 2,496 / 2,496 (+0.0 %) | mult_scale_a 528 / 528 (+0.0 %); tmp2_mult_matvec 534 / 534 (+0.0 %); mult_1_scale_b 528 / 528 (+0.0 %); tmp5_mult_matvec_1 514 / 514 (+0.0 %); add_acc 11 / 11 (+0.0 %) | PASS | PASS | PASS (tmp5_mult_matvec_1: counter 514 against 517, within its fill 3) | PASS, 36 lines, +4 writes, +8 reads | 16, 31, 59 |
| `mvt_dma_copy_cg` | PASS | PASS | 12,593 / 12,593 (+0.0 %) | tmp1_mult_mvt_1 518 / 518 (+0.0 %); tmp4_mult_mvt_1 517 / 517 (+0.0 %) | PASS | PASS | PASS (tmp1_mult_mvt_1: counter 518 against 514, 1 beyond its fill 3 (0.2 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 12, 21, 74 |
| `atax_dma_copy_cg` | PASS | PASS | 12,420 / 12,420 (+0.0 %) | tmp2_mult_matvec 517 / 517 (+0.0 %); y_mult_matvec_1 527 / 527 (+0.0 %) | PASS | PASS | PASS (y_mult_matvec_1: counter 527 against 533, 3 beyond its fill 3 (0.6 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 11, 22, 73 |
| `mvt_contiguous_w8_cg` | PASS | PASS | 4,657 / 4,657 (+0.0 %) | tmp0_mult_mvt_1 518 / 518 (+0.0 %); tmp2_mult_mvt_1 3248 / 3248 (+0.0 %) | PASS | PASS | PASS | PASS, 36 lines, +4 writes, +8 reads | 14, 24, 74 |
| `mvt_padded_w8_cg` | PASS | PASS | 1,937 / 1,937 (+0.0 %) | tmp0_mult_mvt_1 521 / 521 (+0.0 %); tmp2_mult_mvt_1 521 / 521 (+0.0 %) | PASS | PASS | PASS (tmp0_mult_mvt_1: counter 521 against 514, 4 beyond its fill 3 (0.8 %, NEAR)) | PASS, 36 lines, +4 writes, +8 reads | 14, 25, 73 |
| `bicg_sequential_contiguous_w8_cg` | PASS | PASS | 2,018 / 2,018 (+0.0 %) | q_mult_matvec 517 / 517 (+0.0 %); s_mult_mac 532 / 532 (+0.0 %) | PASS | PASS | PASS | PASS, 36 lines, +4 writes, +8 reads | 17, 34, 80 |

### pwr

`mvt_column_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 27.9 cores free (nproc 32, load 4.1))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 116 | 116 | 0 | 109.2 | 12.67 | 100.00 % |
| 2 | dma_in | dma load_y1 | 38 | 38 | 0 | 34.8 | 1.32 | 100.00 % |
| 3 | dma_in | dma load_x1 | 58 | 58 | 0 | 40.8 | 2.36 | 100.00 % |
| 4 | streamer_config | streamer config mvt | 43 | 43 | 0 | 35.2 | 1.51 | 100.00 % |
| 5 | acc_config | acc config mvt | 3 | 3 | 0 | 36.4 | 0.11 | 100.00 % |
| 6 | run | run mvt | 550 | 550 | 0 | 57.5 | 31.63 | 100.00 % |
| 7 | dma_out | dma store_x1 | 35 | 35 | 0 | 51.7 | 1.81 | 100.00 % |
| 8 | dma_in | dma load_y2 | 35 | 35 | 0 | 35.7 | 1.25 | 100.00 % |
| 9 | dma_in | dma load_x2 | 42 | 42 | 0 | 45.6 | 1.92 | 100.00 % |
| 10 | streamer_config | streamer config mac_x2 | 48 | 48 | 0 | 34.3 | 1.65 | 100.00 % |
| 11 | acc_config | acc config mac_x2 | 9 | 9 | 0 | 34.7 | 0.31 | 100.00 % |
| 12 | run | run mac_x2 | 549 | 549 | 0 | 48.3 | 26.54 | 100.00 % |
| 13 | dma_out | dma store_x2 | 75 | 75 | 0 | 40.5 | 3.04 | 100.00 % |

Run windows 58.18 nJ (1,099 cycles); span 86.13 nJ (1,601 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 8,770.1 µW; dynamic (int + switch) 5,751.3 µW, kept apart.

`mvt_read_once_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 28.6 cores free (nproc 32, load 3.4))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 122 | 122 | 0 | 105.3 | 12.85 | 100.00 % |
| 2 | dma_in | dma load_y1 | 35 | 35 | 0 | 35.4 | 1.24 | 100.00 % |
| 3 | dma_in | dma load_x1 | 42 | 42 | 0 | 44.9 | 1.89 | 100.00 % |
| 4 | dma_in | dma load_y2 | 38 | 38 | 0 | 34.7 | 1.32 | 100.00 % |
| 5 | dma_in | dma load_x2 | 58 | 58 | 0 | 40.7 | 2.36 | 100.00 % |
| 6 | streamer_config | streamer config mvt | 76 | 76 | 0 | 34.4 | 2.62 | 100.00 % |
| 7 | acc_config | acc config mvt | 12 | 12 | 0 | 35.9 | 0.43 | 100.00 % |
| 8 | run | run mvt | 549 | 549 | 0 | 77.4 | 42.50 | 100.00 % |
| 9 | dma_out | dma store_x1 | 24 | 24 | 0 | 60.3 | 1.45 | 100.00 % |
| 10 | dma_out | dma store_x2 | 69 | 69 | 0 | 41.9 | 2.89 | 100.00 % |

Run windows 42.50 nJ (549 cycles); span 69.53 nJ (1,025 cycles).
PT's top in `8_run` (power_hierarchy.rpt, units W): leakage 8,946.9 µW; dynamic (int + switch) 7,740.7 µW, kept apart.

`bicg_two_pass_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.2 cores free (nproc 32, load 2.8))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 108 | 108 | 0 | 114.0 | 12.32 | 100.00 % |
| 2 | dma_in | dma load_p | 35 | 35 | 0 | 34.8 | 1.22 | 100.00 % |
| 3 | streamer_config | streamer config matvec | 42 | 42 | 0 | 33.6 | 1.41 | 100.00 % |
| 4 | acc_config | acc config matvec | 3 | 3 | 0 | 41.1 | 0.12 | 100.00 % |
| 5 | run | run matvec | 551 | 551 | 0 | 55.1 | 30.33 | 100.00 % |
| 6 | dma_out | dma store_q | 49 | 49 | 0 | 43.4 | 2.13 | 100.00 % |
| 7 | dma_in | dma load_r | 30 | 30 | 0 | 36.9 | 1.11 | 100.00 % |
| 8 | streamer_config | streamer config mac | 35 | 35 | 0 | 34.1 | 1.19 | 100.00 % |
| 9 | acc_config | acc config mac | 9 | 9 | 0 | 32.9 | 0.30 | 100.00 % |
| 10 | run | run mac | 557 | 557 | 0 | 46.4 | 25.87 | 100.00 % |
| 11 | dma_out | dma store_s | 85 | 85 | 0 | 37.7 | 3.20 | 100.00 % |

Run windows 56.20 nJ (1,108 cycles); span 79.20 nJ (1,504 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 8,090.4 µW; dynamic (int + switch) 5,505.3 µW, kept apart.

`bicg_read_once_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.9 cores free (nproc 32, load 2.1))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 118 | 118 | 0 | 107.9 | 12.73 | 100.00 % |
| 2 | dma_in | dma load_p | 35 | 35 | 0 | 34.4 | 1.20 | 100.00 % |
| 3 | dma_in | dma load_r | 37 | 37 | 0 | 34.2 | 1.27 | 100.00 % |
| 4 | streamer_config | streamer config bicg_types | 72 | 72 | 0 | 33.2 | 2.39 | 100.00 % |
| 5 | acc_config | acc config bicg_types | 12 | 12 | 0 | 32.8 | 0.39 | 100.00 % |
| 6 | run | run bicg_types | 556 | 556 | 0 | 71.5 | 39.77 | 100.00 % |
| 7 | dma_out | dma store_q | 32 | 32 | 0 | 52.0 | 1.66 | 100.00 % |
| 8 | dma_out | dma store_s | 71 | 71 | 0 | 39.6 | 2.81 | 100.00 % |

Run windows 39.77 nJ (556 cycles); span 62.23 nJ (933 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 8,205.0 µW; dynamic (int + switch) 7,152.9 µW, kept apart.

`atax_read_once_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.4 cores free (nproc 32, load 2.6))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 104 | 104 | 0 | 117.2 | 12.18 | 100.00 % |
| 2 | dma_in | dma load_x | 29 | 29 | 0 | 35.5 | 1.03 | 100.00 % |
| 3 | streamer_config | streamer config atax | 45 | 45 | 0 | 32.8 | 1.47 | 100.00 % |
| 4 | acc_config | acc config atax | 11 | 11 | 0 | 31.0 | 0.34 | 100.00 % |
| 5 | run | run atax | 563 | 563 | 0 | 76.6 | 43.14 | 100.00 % |
| 6 | dma_out | dma store_y | 91 | 91 | 0 | 36.6 | 3.33 | 100.00 % |

Run windows 43.14 nJ (563 cycles); span 61.50 nJ (843 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 8,015.1 µW; dynamic (int + switch) 7,661.7 µW, kept apart.

`atax_column_shared_movers_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.7 cores free (nproc 32, load 2.3))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 116 | 116 | 0 | 107.1 | 12.42 | 100.00 % |
| 2 | dma_in | dma load_x | 38 | 38 | 0 | 32.8 | 1.25 | 100.00 % |
| 3 | streamer_config | streamer config atax | 46 | 46 | 0 | 32.3 | 1.49 | 100.00 % |
| 4 | acc_config | acc config matvec | 3 | 3 | 0 | 30.7 | 0.09 | 100.00 % |
| 5 | run | run matvec | 556 | 556 | 0 | 60.8 | 33.83 | 100.00 % |
| 6 | streamer_config | streamer config atax | 47 | 47 | 0 | 32.6 | 1.53 | 100.00 % |
| 7 | acc_config | acc config mac | 14 | 14 | 0 | 33.2 | 0.47 | 100.00 % |
| 8 | run | run mac | 545 | 545 | 0 | 62.3 | 33.94 | 100.00 % |
| 9 | dma_out | dma store_y | 71 | 71 | 0 | 39.8 | 2.82 | 100.00 % |

Run windows 67.77 nJ (1,101 cycles); span 87.84 nJ (1,436 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 7,699.3 µW; dynamic (int + switch) 6,084.8 µW, kept apart.

`gesummv_x_read_once_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.4 cores free (nproc 32, load 2.6))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 118 | 118 | 0 | 108.2 | 12.77 | 100.00 % |
| 2 | dma_in | dma load_x | 44 | 44 | 0 | 36.6 | 1.61 | 100.00 % |
| 3 | dma_in | dma load_B | 89 | 89 | 0 | 134.5 | 11.97 | 100.00 % |
| 4 | streamer_config | streamer config gesummv | 59 | 59 | 0 | 35.6 | 2.10 | 100.00 % |
| 5 | acc_config | acc config gesummv | 11 | 11 | 0 | 34.4 | 0.38 | 100.00 % |
| 6 | run | run gesummv | 549 | 549 | 0 | 75.6 | 41.48 | 100.00 % |
| 7 | streamer_config | streamer config axpby | 45 | 45 | 0 | 36.2 | 1.63 | 100.00 % |
| 8 | acc_config | acc config axpby | 12 | 12 | 0 | 38.6 | 0.46 | 100.00 % |
| 9 | run | run axpby | 44 | 44 | 0 | 62.5 | 2.75 | 100.00 % |
| 10 | dma_out | dma store_out | 91 | 91 | 0 | 39.4 | 3.59 | 100.00 % |

Run windows 44.23 nJ (593 cycles); span 78.74 nJ (1,062 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 9,635.7 µW; dynamic (int + switch) 7,556.0 µW, kept apart.

`gesummv_factor_out_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.2 cores free (nproc 32, load 2.8))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 132 | 132 | 0 | 100.5 | 13.26 | 100.00 % |
| 2 | dma_in | dma load_x | 30 | 30 | 0 | 39.3 | 1.18 | 100.00 % |
| 3 | streamer_config | streamer config matvec | 34 | 34 | 0 | 36.5 | 1.24 | 100.00 % |
| 4 | acc_config | acc config matvec | 9 | 9 | 0 | 34.4 | 0.31 | 100.00 % |
| 5 | run | run matvec | 549 | 549 | 0 | 57.4 | 31.53 | 100.00 % |
| 6 | dma_in | dma load_B | 101 | 101 | 0 | 122.6 | 12.39 | 100.00 % |
| 7 | streamer_config | streamer config matvec_1 | 49 | 49 | 0 | 35.4 | 1.73 | 100.00 % |
| 8 | acc_config | acc config matvec_1 | 14 | 14 | 0 | 35.0 | 0.49 | 100.00 % |
| 9 | run | run matvec_1 | 536 | 536 | 0 | 59.4 | 31.82 | 100.00 % |
| 10 | streamer_config | streamer config axpby | 47 | 47 | 0 | 35.7 | 1.68 | 100.00 % |
| 11 | acc_config | acc config axpby | 15 | 15 | 0 | 40.4 | 0.61 | 100.00 % |
| 12 | run | run axpby | 40 | 40 | 0 | 67.1 | 2.68 | 100.00 % |
| 13 | dma_out | dma store_out | 71 | 71 | 0 | 43.3 | 3.07 | 100.00 % |

Run windows 66.04 nJ (1,125 cycles); span 102.00 nJ (1,627 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 9,770.3 µW; dynamic (int + switch) 5,743.3 µW, kept apart.

`gesummv_literal_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 30.1 cores free (nproc 32, load 1.9))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 115 | 115 | 0 | 114.2 | 13.14 | 100.00 % |
| 2 | streamer_config | streamer config scale_a | 43 | 43 | 0 | 39.3 | 1.69 | 100.00 % |
| 3 | acc_config | acc config scale_a | 3 | 3 | 0 | 44.4 | 0.13 | 100.00 % |
| 4 | run | run scale_a | 548 | 548 | 0 | 92.0 | 50.42 | 100.00 % |
| 5 | dma_in | dma load_x | 46 | 46 | 0 | 39.3 | 1.81 | 100.00 % |
| 6 | streamer_config | streamer config matvec | 46 | 46 | 0 | 40.1 | 1.85 | 100.00 % |
| 7 | acc_config | acc config matvec | 11 | 11 | 0 | 38.4 | 0.42 | 100.00 % |
| 8 | run | run matvec | 549 | 549 | 0 | 106.7 | 58.59 | 100.00 % |
| 9 | dma_in | dma load_B | 101 | 101 | 0 | 125.9 | 12.72 | 100.00 % |
| 10 | streamer_config | streamer config scale_b | 46 | 46 | 0 | 39.0 | 1.80 | 100.00 % |
| 11 | acc_config | acc config scale_b | 11 | 11 | 0 | 41.1 | 0.45 | 100.00 % |
| 12 | run | run scale_b | 557 | 557 | 0 | 91.0 | 50.68 | 100.00 % |
| 13 | streamer_config | streamer config matvec_1 | 47 | 47 | 0 | 38.8 | 1.82 | 100.00 % |
| 14 | acc_config | acc config matvec_1 | 14 | 14 | 0 | 37.1 | 0.52 | 100.00 % |
| 15 | run | run matvec_1 | 549 | 549 | 0 | 105.8 | 58.07 | 100.00 % |
| 16 | streamer_config | streamer config acc | 43 | 43 | 0 | 39.1 | 1.68 | 100.00 % |
| 17 | acc_config | acc config acc | 7 | 7 | 0 | 37.1 | 0.26 | 100.00 % |
| 18 | run | run acc | 45 | 45 | 0 | 60.0 | 2.70 | 100.00 % |
| 19 | dma_out | dma store_out | 79 | 79 | 0 | 44.7 | 3.53 | 100.00 % |

Run windows 220.46 nJ (2,248 cycles); span 262.28 nJ (2,860 cycles).
PT's top in `4_run` (power_hierarchy.rpt, units W): leakage 12,138.8 µW; dynamic (int + switch) 9,200.9 µW, kept apart.

`mvt_dma_copy_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 30.2 cores free (nproc 32, load 1.8))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 114 | 114 | 0 | 108.3 | 12.34 | 100.00 % |
| 2 | dma_in | dma load_y1 | 37 | 37 | 0 | 33.2 | 1.23 | 100.00 % |
| 3 | dma_in | dma load_x1 | 43 | 43 | 0 | 42.3 | 1.82 | 100.00 % |
| 4 | streamer_config | streamer config mvt_1 | 49 | 49 | 0 | 31.9 | 1.56 | 100.00 % |
| 5 | acc_config | acc config mvt_1 | 9 | 9 | 0 | 31.8 | 0.29 | 100.00 % |
| 6 | run | run mvt_1 | 565 | 565 | 0 | 52.4 | 29.59 | 100.00 % |
| 7 | dma_out | dma store_x1 | 34 | 34 | 0 | 46.8 | 1.59 | 100.00 % |
| 8 | dma_copy | dma transpose_A_T | 10,976 | 10,976 | 0 | 93.5 | 1025.95 | 100.00 % |
| 9 | dma_in | dma load_y2 | 51 | 51 | 0 | 32.2 | 1.64 | 100.00 % |
| 10 | dma_in | dma load_x2 | 34 | 34 | 0 | 48.0 | 1.63 | 100.00 % |
| 11 | streamer_config | streamer config mvt_1 | 45 | 45 | 0 | 32.9 | 1.48 | 100.00 % |
| 12 | acc_config | acc config mvt_1 | 3 | 3 | 0 | 31.5 | 0.09 | 100.00 % |
| 13 | run | run mvt_1 | 557 | 557 | 0 | 52.7 | 29.37 | 100.00 % |
| 14 | dma_out | dma store_x2 | 74 | 74 | 0 | 38.3 | 2.83 | 100.00 % |

Run windows 58.96 nJ (1,122 cycles); span 1111.43 nJ (12,591 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 7,273.4 µW; dynamic (int + switch) 5,237.4 µW, kept apart.

`atax_dma_copy_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 30.3 cores free (nproc 32, load 1.7))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 116 | 116 | 0 | 108.4 | 12.57 | 100.00 % |
| 2 | dma_in | dma load_x | 38 | 38 | 0 | 34.1 | 1.30 | 100.00 % |
| 3 | streamer_config | streamer config matvec | 45 | 45 | 0 | 33.8 | 1.52 | 100.00 % |
| 4 | acc_config | acc config matvec | 3 | 3 | 0 | 33.5 | 0.10 | 100.00 % |
| 5 | run | run matvec | 554 | 554 | 0 | 54.3 | 30.10 | 100.00 % |
| 6 | dma_copy | dma transpose_A_T | 10,957 | 10,957 | 0 | 96.0 | 1052.31 | 100.00 % |
| 7 | streamer_config | streamer config matvec_1 | 57 | 57 | 0 | 33.3 | 1.90 | 100.00 % |
| 8 | acc_config | acc config matvec_1 | 3 | 3 | 0 | 36.1 | 0.11 | 100.00 % |
| 9 | run | run matvec_1 | 566 | 566 | 0 | 84.7 | 47.96 | 100.00 % |
| 10 | dma_out | dma store_y | 69 | 69 | 0 | 41.3 | 2.85 | 100.00 % |

Run windows 78.06 nJ (1,120 cycles); span 1150.72 nJ (12,408 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 8,206.0 µW; dynamic (int + switch) 5,433.2 µW, kept apart.

`mvt_contiguous_w8_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.8 cores free (nproc 32, load 2.2))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 561 | 561 | 0 | 160.6 | 90.07 | 100.00 % |
| 2 | dma_in | dma load_y1 | 48 | 48 | 0 | 56.6 | 2.72 | 100.00 % |
| 3 | dma_in | dma load_x1 | 63 | 63 | 0 | 50.3 | 3.17 | 100.00 % |
| 4 | streamer_config | streamer config mvt_1 | 43 | 43 | 0 | 35.2 | 1.51 | 100.00 % |
| 5 | acc_config | acc config mvt_1 | 3 | 3 | 0 | 36.1 | 0.11 | 100.00 % |
| 6 | run | run mvt_1 | 550 | 550 | 0 | 264.7 | 145.60 | 100.00 % |
| 7 | dma_out | dma store_x1 | 40 | 40 | 0 | 66.2 | 2.65 | 100.00 % |
| 8 | dma_in | dma load_y2 | 45 | 45 | 0 | 58.1 | 2.62 | 100.00 % |
| 9 | dma_in | dma load_x2 | 47 | 47 | 0 | 57.2 | 2.69 | 100.00 % |
| 10 | streamer_config | streamer config mvt_1 | 49 | 49 | 0 | 34.8 | 1.71 | 100.00 % |
| 11 | acc_config | acc config mvt_1 | 9 | 9 | 0 | 33.0 | 0.30 | 100.00 % |
| 12 | run | run mvt_1 | 3,293 | 3,293 | 0 | 73.2 | 241.12 | 100.00 % |
| 13 | dma_out | dma store_x2 | 85 | 85 | 0 | 47.8 | 4.06 | 100.00 % |

Run windows 386.72 nJ (3,843 cycles); span 498.32 nJ (4,836 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 10,203.4 µW; dynamic (int + switch) 26,473.1 µW, kept apart.

`mvt_padded_w8_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.9 cores free (nproc 32, load 2.1))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 573 | 573 | 0 | 159.7 | 91.51 | 100.00 % |
| 2 | dma_in | dma load_y1 | 63 | 63 | 0 | 50.2 | 3.16 | 100.00 % |
| 3 | dma_in | dma load_x1 | 34 | 34 | 0 | 68.4 | 2.33 | 100.00 % |
| 4 | streamer_config | streamer config mvt_1 | 45 | 45 | 0 | 35.4 | 1.59 | 100.00 % |
| 5 | acc_config | acc config mvt_1 | 3 | 3 | 0 | 33.3 | 0.10 | 100.00 % |
| 6 | run | run mvt_1 | 557 | 557 | 0 | 263.4 | 146.71 | 100.00 % |
| 7 | dma_out | dma store_x1 | 43 | 43 | 0 | 63.6 | 2.74 | 100.00 % |
| 8 | dma_in | dma load_y2 | 47 | 47 | 0 | 56.9 | 2.68 | 100.00 % |
| 9 | dma_in | dma load_x2 | 49 | 49 | 0 | 56.1 | 2.75 | 100.00 % |
| 10 | streamer_config | streamer config mvt_1 | 59 | 59 | 0 | 34.7 | 2.05 | 100.00 % |
| 11 | acc_config | acc config mvt_1 | 3 | 3 | 0 | 33.4 | 0.10 | 100.00 % |
| 12 | run | run mvt_1 | 557 | 557 | 0 | 265.1 | 147.66 | 100.00 % |
| 13 | dma_out | dma store_x2 | 74 | 74 | 0 | 50.6 | 3.74 | 100.00 % |

Run windows 294.37 nJ (1,114 cycles); span 407.11 nJ (2,107 cycles).
PT's top in `6_run` (power_hierarchy.rpt, units W): leakage 10,215.2 µW; dynamic (int + switch) 26,338.7 µW, kept apart.

`bicg_sequential_contiguous_w8_cg`: part 1 PASS, windows against the point's quiet run on the RTL (rtl/check.json, X108): PASS; part 2 PASS, PT threads 24 (--cores 24: 29.8 cores free (nproc 32, load 2.2))
PT's macros' .db: sram_d128_w256_m8 `d5015ed6be916ffd` ok; sram_d128_w39 `f4b2ebfe8f5f4c08` ok; sram_d512_w64_m8 `334f95820c102c41` ok

| mark | kind | label | cycles netlist | quiet RTL | diff | pJ/cycle (e_dyn) | window nJ | annotated |
|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | dma_in | dma load_A | 553 | 553 | 0 | 165.5 | 91.53 | 100.00 % |
| 2 | dma_in | dma load_p | 45 | 45 | 0 | 61.3 | 2.76 | 100.00 % |
| 3 | streamer_config | streamer config matvec | 42 | 42 | 0 | 37.7 | 1.58 | 100.00 % |
| 4 | acc_config | acc config matvec | 3 | 3 | 0 | 44.9 | 0.13 | 100.00 % |
| 5 | run | run matvec | 549 | 549 | 0 | 280.4 | 153.93 | 100.00 % |
| 6 | dma_out | dma store_q | 42 | 42 | 0 | 68.5 | 2.88 | 100.00 % |
| 7 | dma_in | dma load_r | 45 | 45 | 0 | 61.4 | 2.76 | 100.00 % |
| 8 | streamer_config | streamer config mac | 35 | 35 | 0 | 38.3 | 1.34 | 100.00 % |
| 9 | acc_config | acc config mac | 9 | 9 | 0 | 36.1 | 0.32 | 100.00 % |
| 10 | run | run mac | 575 | 575 | 0 | 202.2 | 116.25 | 100.00 % |
| 11 | dma_out | dma store_s | 85 | 85 | 0 | 51.0 | 4.34 | 100.00 % |

Run windows 270.18 nJ (1,124 cycles); span 377.82 nJ (1,983 cycles).
PT's top in `5_run` (power_hierarchy.rpt, units W): leakage 13,333.6 µW; dynamic (int + switch) 28,038.0 µW, kept apart.

